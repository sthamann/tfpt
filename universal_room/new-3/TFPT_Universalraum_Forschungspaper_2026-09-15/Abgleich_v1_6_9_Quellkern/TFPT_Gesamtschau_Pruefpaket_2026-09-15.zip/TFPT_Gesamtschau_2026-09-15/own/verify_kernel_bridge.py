"""Exact source-kernel countermodels and elementary cross-checks of v1.6.9.

These are explicitly new composition rules, not compiler outputs.
The finite kernel-to-CAR theorem is proved in the accompanying report.
"""
from pathlib import Path
import ast, contextlib, io, hashlib, itertools, json, math
from collections import Counter
import numpy as np
import sympy as s
H=Path(__file__).resolve().parent;inp=H/'kernel_inputs';checks=[];guards=[]
def need(ok,label):
    if not bool(ok):raise RuntimeError(label)
    checks.append(label)
def require(ok,label):
    if not bool(ok):raise RuntimeError(label)
    guards.append(label)
adapter=inp/'context_instrument.py'
need(hashlib.sha256(adapter.read_bytes()).hexdigest()=='ba1da93102e553631b71e320d2d53883bb67dedb6d9132fc7e0311afe49e3995',
     'Frozen source adapter pin')
body=[n for n in ast.parse(adapter.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='source_prefix']
env={'ast':ast,'hashlib':hashlib,'contextlib':contextlib,'io':io,'require':require,'SOURCE':inp/'ray_source.py','PIN':'8f4851634b83f61671b04f3a6211059c40758d21caaf1f779302c799e1e9d6c4'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(adapter),'exec'),env)
d=env['source_prefix']()
z=np.array([[complex(a,b) for a,b in d['Z240'][k]] for k in d['line_reps']])
need(z.shape==(60,4) and np.array_equal(np.sum(z.real**2+z.imag**2,axis=1),4*np.ones(60)),
     'Sixty original Gaussian rays have squared norm four')
# Gaussian integer arithmetic is represented by exact integer real/imaginary arrays.
zr,zi=z.real.astype(np.int64),z.imag.astype(np.int64)
gr=zr@zr.T+zi@zi.T;gi=zi@zr.T-zr@zi.T
numerator=gr**2+gi**2
need(np.all(numerator%4==0),'Ray fidelity scaled by four is integer')
T=numerator//4 # K = T / 4.
need(np.array_equal(T,T.T) and np.all(T.diagonal()==4),'Source fidelity kernel normalized and symmetric')
need(all(Counter(row)=={0:15,1:32,2:12,4:1} for row in T),'Exact overlap distribution for every source ray')
P4=[]
for r,i in zip(zr,zi):
    P4.append((np.outer(r,r)+np.outer(i,i),np.outer(i,r)-np.outer(r,i)))
Fr=np.stack([r.ravel() for r,i in P4],axis=1)
Fi=np.stack([i.ravel() for r,i in P4],axis=1)
need(np.array_equal(Fr.T@Fr+Fi.T@Fi,4*T) and not np.any(Fr.T@Fi-Fi.T@Fr),
     'K is the exact Hilbert-Schmidt Gram of original projectors')
Tr=[];Ti=[]
for r,i in P4:
    Tr.append((np.kron(r,r)-np.kron(i,i)).ravel())
    Ti.append((np.kron(r,i)+np.kron(i,r)).ravel())
Tr=np.stack(Tr,axis=1);Ti=np.stack(Ti,axis=1)
need(np.array_equal(Tr.T@Tr+Ti.T@Ti,16*T**2) and not np.any(Tr.T@Ti-Ti.T@Tr),
     'Entrywise K squared is an exact Gram of tensor-square features')
expected={1:{0:44,12:15,60:1},2:{0:5,8:30,16:9,32:15,96:1},4:{168:5,224:30,280:9,320:15,480:1}}
spectra={}
for power,ev in expected.items():
    M=T**power;eye=np.eye(60,dtype=np.int64);roots=list(ev);bound=int(np.max(np.sum(abs(M),axis=1)))
    need(60*math.prod(bound+abs(x) for x in roots)<2**63,
         f'Integer polynomial and projector traces cannot overflow for power {power}')
    p=eye.copy()
    for lam in roots:p=p@(M-lam*eye)
    need(not np.any(p),f'Exact annihilating polynomial for kernel power {power}')
    multiplicities={}
    for lam in roots:
        p=eye.copy();den=1
        for other in roots:
            if other!=lam:p=p@(M-other*eye);den*=lam-other
        trace=int(np.trace(p));need(trace%den==0,f'Integral spectral multiplicity for power {power} eigenvalue {lam}')
        multiplicities[lam]=trace//den
    need(multiplicities==ev,f'Complete certified spectrum of scaled kernel power {power}')
    spectra[power]={str(s.Rational(lam,4**power)):mult for lam,mult in ev.items()}
need(sum(mult for lam,mult in expected[1].items() if lam)!=sum(mult for lam,mult in expected[2].items() if lam),
     'Source-preserving scalar-kernel prescriptions require different minimal copy dimensions 16 and 55')
Wfile=inp/'native_tensor.npz'
need(hashlib.sha256(Wfile.read_bytes()).hexdigest()=='3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763','Same native W as both preceding studies')
raw=np.load(Wfile)['W'];need(not np.any(raw.imag),'Native W real')
W=raw.real.astype(np.int64)
need(np.array_equal(W@W.T,8*np.eye(60,dtype=np.int64)),'Original local pair Gram unchanged')
# Each full construction has 60 source-labelled charts and one 60-channel boson bank per chart.
I4_1=s.Rational(int(np.sum(T[0]**4)),4**4)
I4_2=s.Rational(int(np.sum(T[0]**8)),4**8)
need(I4_1==s.Rational(15,8) and I4_2==s.Rational(2145,2048),
     'Single-port fourth moments distinguish the two full sixty-chart prescriptions')
need(all(np.sum(row**4)==480 and np.sum(row**8)==68640 for row in T),
     'Fourth-moment distinction independent of chosen source label')
need(16*s.Rational(1,2)**4==1 and 16*s.Rational(1,4)**4==s.Rational(1,16),
     'Transfer coefficient differs by factor sixteen at source fidelity one-half')

# Independent symbolic check of the worker's two-chart moment inversion.
c,g,D=s.symbols('c g Delta',real=True)
B=8*s.Matrix([[1,c**2],[c**2,1]])
J=s.BlockMatrix([[s.zeros(2),g*s.eye(2)],[g*B,D*s.eye(2)]]).as_explicit()
mu=[s.expand((J**k)[2,2]) for k in range(1,5)]
need(s.simplify((mu[3]-3*mu[0]**2*mu[1]+2*mu[0]**4)/(mu[1]-mu[0]**2)**2-(1+c**4))==0,
     'Independent symbolic two-chart I4 inversion')

# Gram positivity is a global compatibility requirement, not a pairwise range check.
bad=s.Matrix([[1,s.Rational(9,10),s.Rational(9,10)],[s.Rational(9,10),1,s.Rational(1,10)],[s.Rational(9,10),s.Rational(1,10),1]])
need(all(1-bad[i,j]**2>0 for i,j in itertools.combinations(range(3),2)) and bad.det()==-s.Rational(117,250),
     'Pairwise allowed overlaps can fail the three-chart global CAR Gram condition')

# The controller needs an energy reference for an exact universal pulse, not just energy.
X=s.Matrix([[0,0,-1],[0,0,s.sqrt(7)],[-1,s.sqrt(7),0]])
Nb=s.diag(0,0,1);Z=s.eye(3)-2*Nb;Hs=D*Nb+g*X
need(Z*Hs*Z-Hs==-2*g*X,'Native boson phase is not energy-time covariant for nonzero g')
need(s.Rational(1,54)/2==s.Rational(1,108),'Worker recorder work equals half of pulse work')

# Retain the original marked source's phase information before scalarizing it.
P=[s.Matrix(r.tolist())/4+s.I*s.Matrix(i.tolist())/4 for r,i in P4[:3]]
triple=s.simplify(s.trace(P[0]*P[1]*P[2]))
need(triple==s.Rational(1,4)-s.I/4,'Original source labels 0,1,2 have complex triple trace (1-i)/4')
need(all(s.trace(P[i]*P[j])==s.Rational(1,2) for i,j in itertools.combinations(range(3),2)),
     'All three marked pair fidelities are one-half despite non-real triple trace')
need(s.simplify(s.trace(P[0].conjugate()*P[1].conjugate()*P[2].conjugate()))==s.conjugate(triple) and triple!=s.conjugate(triple),
     'Complex conjugation preserves every pair fidelity but changes the ordered triple')
need(np.array_equal(sum(r for r,i in P4),60*np.eye(4,dtype=np.int64)) and not np.any(sum(i for r,i in P4)),
     'Equal mixture of all sixty source projectors is exactly I4/4, hence has trivial modular flow on source M4')

result={'status':'PASS','exact_checks':len(checks),'checks':checks,'inherited_ray_guards_separate':len(guards),
 'source_kernel_spectra':spectra,'minimal_copy_dimensions':[16,55],
 'global_fermion_dimensions':[1024,3520],
 'single_port_I4':[str(I4_1),str(I4_2)],
 'same_source_rays':True,'full_original_word_algebra_preserved':'NOT_PROVED',
 'marked_source_triple_0_1_2':str(triple),'uniform_source_density':'I4/4',
 'kernel_choice_derived_from_compiler':False,'native_controller_derived':False,
 'relativistic_physics_derived':False,
 'scope':'Exact finite source-kernel candidates. Kernel construction and moment response are conditional composition theorems, not a TOE or a selection of the correct kernel.'}
(H/'kernel_certificate.json').write_text(json.dumps({'T':T.tolist(),'spectra':spectra},sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True,indent=2))
