"""An exact two-dimensional invariant N=4 oscillator in the pinned native bank."""
from pathlib import Path
from collections import defaultdict
from itertools import combinations
import json, hashlib
import numpy as np
import sympy as s
from scipy.sparse import coo_matrix, csr_matrix
H = Path(__file__).resolve().parent
checks=[]
def need(ok,label):
    if not bool(ok): raise RuntimeError(label)
    checks.append(label)
p=H/'inputs/native_tensor.npz'
need(hashlib.sha256(p.read_bytes()).hexdigest()=='3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763','Pinned original native W')
raw=np.load(p)['W'];need(np.all(raw.imag==0),'Real W')
W=raw.real.astype(np.int64);Ws=csr_matrix(W)
pairs=list(combinations(range(64),2));pi={p:i for i,p in enumerate(pairs)}
colors=list(combinations(range(4),2))
J6=np.zeros((6,6),dtype=np.int64)
for a,pair in enumerate(colors):
    other=tuple(x for x in range(4) if x not in pair);t=pair+other
    J6[a,colors.index(other)]=(-1)**sum(t[i]>t[j] for i in range(4) for j in range(i+1,4))
J10=np.block([[np.zeros((5,5),dtype=np.int64),np.eye(5,dtype=np.int64)],
              [np.eye(5,dtype=np.int64),np.zeros((5,5),dtype=np.int64)]])
J=np.kron(J10,J6)
need(np.array_equal(J,J.T) and np.array_equal(J@J,np.eye(60,dtype=np.int64)), 'Native invariant form candidate is symmetric and orthogonal')
# All Lie generators, using the same independent construction as the 1.1 replay.
def sign(mask,i):return -1 if (mask&((1<<i)-1)).bit_count()%2 else 1
even=[m for m in range(32) if m.bit_count()%2==0]
ann=[]
for j in range(5):
    a=np.zeros((32,32),dtype=np.int64)
    for m in range(32):
        if (m>>j)&1:a[m^(1<<j),m]=sign(m,j)
    ann.append(a)
gamma=[a+a.T for a in ann]+[1j*(a.T-a) for a in ann]
gens=[np.kron((gamma[i]@gamma[j])[np.ix_(even,even)],np.eye(4,dtype=np.int64)) for i,j in combinations(range(10),2)]
for i,j in combinations(range(4),2):
    a=np.zeros((4,4),dtype=np.int64);a[i,j]=1;a[j,i]=-1;gens.append(np.kron(np.eye(16,dtype=np.int64),a))
    a=np.zeros((4,4),dtype=np.int64);a[i,j]=a[j,i]=1;gens.append(np.kron(np.eye(16,dtype=np.int64),a))
for i in range(3):
    a=np.zeros((4,4),dtype=np.int64);a[i,i]=1;a[i+1,i+1]=-1;gens.append(np.kron(np.eye(16,dtype=np.int64),a))
need(len(gens)==60,'Complete 45 plus 15 Lie generating set')
for n,T in enumerate(gens):
    need(not (np.any(T.imag) and np.any(T.real)),f'Pure integer generator up to scalar {n}')
    T=(T.imag if np.any(T.imag) else T.real).astype(np.int64)
    rr=[];cc=[];vv=[]
    support=[[(int(r),int(T[r,i])) for r in np.flatnonzero(T[:,i])] for i in range(64)]
    for col,(i,j) in enumerate(pairs):
        for k,a in support[i]:
            if k!=j:rr.append(pi[tuple(sorted((k,j)))]);cc.append(col);vv.append(a*(1 if k<j else -1))
        for k,a in support[j]:
            if k!=i:rr.append(pi[tuple(sorted((i,k)))]);cc.append(col);vv.append(a*(1 if i<k else -1))
    L=coo_matrix((vv,(rr,cc)),shape=(2016,2016),dtype=np.int64).tocsr()
    T8=(Ws@L@Ws.T).toarray()
    defect=csr_matrix(T8)@Ws-8*Ws@L;defect.eliminate_zeros()
    need(defect.nnz==0,f'Native pair covariance {n}')
    need(not np.any(T8@J+J@T8.T),f'J is invariant under native Lie generator {n}')

# Braw=sum J_ab b_a^dag b_b^dag |0>, Fraw=sum J_ab P_a^dag b_b^dag |0>.
Braw={(a,b):int(2*J[a,b]) for a,b in combinations(range(60),2) if J[a,b]}
Fraw=J.T@W # rows: one remaining boson; columns: fermion pair.
normB=sum(v*v for v in Braw.values());normF=int(np.sum(Fraw**2))
need(normB==120 and normF==480,'Exact norms of the two raw singlets')
# First conversion: annihilating either of the two bosons.
BF=np.zeros_like(Fraw)
for (a,b),v in Braw.items():
    BF[b]+=v*W[a];BF[a]+=v*W[b]
need(np.array_equal(BF,2*Fraw),'X Braw = 2 Fraw')
# Return conversion from pair to boson, with correct occupation factors.
returnB=defaultdict(int)
for b in range(60):
    for a,amp in enumerate(W@Fraw[b]):
        if amp:
            need(a!=b,'No same-mode boson output in this singlet')
            returnB[tuple(sorted((a,b)))]+=int(amp)
need(dict(returnB)=={k:8*v for k,v in Braw.items()},'Return part of X Fraw = 8 Braw')
# Four-fermion branch: retain CAR signs before cancellations.
four=defaultdict(int)
for b in range(60):
    for u in np.flatnonzero(Fraw[b]):
        for v in np.flatnonzero(W[b]):
            inds=pairs[v]+pairs[u]
            if len(set(inds))<4:continue
            inv=sum(inds[i]>inds[j] for i in range(4) for j in range(i+1,4))
            four[tuple(sorted(inds))]+=int(W[b,v]*Fraw[b,u]*(-1)**inv)
need(len(four)==960 and all(a==0 for a in four.values()),'Entire four-fermion branch cancels exactly on 960 configurations')
for r in range(64):
    idx=[j for j,pair in enumerate(pairs) if r in pair]
    need(int(np.sum(Fraw[:,idx]**2))==15,f'Erasure distinguishes F from B at mode {r}')
g,D=s.symbols('g Delta',real=True)
h=s.Matrix([[2*D,4*g],[4*g,D]])
z=s.symbols('z')
need(s.expand(h.charpoly(z).as_expr())==z**2-3*D*z+2*D**2-16*g**2,'Exact invariant two-level Hamiltonian characteristic polynomial')
eta=s.symbols('eta',real=True)
h_eta=h+s.diag(2*eta,0)
need(s.expand(h_eta.charpoly(z).as_expr()-(z**2-(3*D+2*eta)*z+2*D**2+2*D*eta-16*g**2))==0,
     'Quartic invariant changes the same native singlet block without changing N2')
need(s.expand(s.Rational(4,3)*g**2*((D+2*eta)**2-D**2)-s.Rational(16,3)*g**2*eta*(D+eta))==0,
     'Neutral boson readout distinguishes the quartic term at fourth order in time')
np.savez(H/'native_singlet_certificate.npz',J=J,Fraw=Fraw,
         B_keys=np.array(list(Braw)),B_values=np.array(list(Braw.values())))
print(json.dumps({'status':'PASS','explicit_checks':len(checks),'checks':checks,
 'source_status':'Independent replay of the N4 block already reported in S048 v1.6.2; not a first discovery',
 'native_invariant_sector':{'N':4,'dimension':2,'basis':['Braw/sqrt(120)','Fraw/sqrt(480)'],
 'H':[['2 Delta','4 g'],['4 g','Delta']],
 'spectrum':'(3 Delta +/- sqrt(Delta^2 + 64 g^2))/2',
 'Nb_from_initial_B':'2 - 64 g^2/(Delta^2+64 g^2) sin^2(sqrt(Delta^2+64 g^2) t/2)',
 'inner_G_singlet':True,'quartic_fermion_branch':'identically zero by exact CAR cancellation',
 'known_single_fermion_mode_erasure_correctable_as_qubit':False,
 'compressed_nr':[['0','0'],['0','1/32']],
 'autonomous_preparation_derived':False,'physical_time_emergence_derived':False,
 'full_N4_singlet_space_classified':False},
 'scope':'An exact native invariant oscillator; no claim of a physical vacuum, autonomous clock initialization, protected record, or complete theory.'},indent=2,sort_keys=True))
