from pathlib import Path
import subprocess,sys,json,hashlib
H=Path(__file__).resolve().parent
manifest=H/'manifest.json'
if manifest.exists():
    for item in json.loads(manifest.read_text())['files']:
        p=H/item['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
            raise RuntimeError('Manifest mismatch: '+item['path'])
report=[]
for name,expected in [('verify_foundations.py',37),('verify_native_singlet.py',315)]:
    outputs=[]
    for flags in [[],['-OO']]:
        p=subprocess.run([sys.executable,*flags,str(H/name)],cwd=H,capture_output=True,check=True)
        d=json.loads(p.stdout)
        if d['status']!='PASS' or d['explicit_checks']!=expected:raise RuntimeError('Bad result '+name)
        outputs.append(p.stdout)
    if outputs[0]!=outputs[1]:raise RuntimeError('Optimization mismatch '+name)
    report.append({'checker':name,'status':'PASS','explicit_checks':expected,'normal_optimized_identical':True})
print(json.dumps({'status':'PASS','checks':352,'reports':report},indent=2))
