# TFPT Grundlagenprüfung 1.3

Prüfung: `python3 run_all.py` mit NumPy, SciPy und SymPy.
Das ausführliche Paper steht in `documents/`.

Erwartet: PASS, 352 explizite Bedingungen und identische normale/optimierte Ausgaben.
Die Inputs und historischen Bezugspunkte sind eingefroren. Das Manifest dient der
Integritätsprüfung dieses Pakets, nicht als externer mathematischer Beweis.
Der bereits bekannte N=4-Block ist ausdrücklich als erneute Prüfung gekennzeichnet.
