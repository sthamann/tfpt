"""Exact finite certificates for the foundational TFPT audit.

The analytical arguments and their hypotheses are in the companion paper.
No Monte Carlo integration, physical gauge assumption, or vacuum selection
is inferred from these checks.
"""
from pathlib import Path
import hashlib, itertools, json
import numpy as np
import sympy as s

HERE = Path(__file__).resolve().parent
checks = []
def need(ok, label):
    if not bool(ok):
        raise RuntimeError(label)
    checks.append(label)

inputs = HERE / 'inputs'
raw = inputs / 'native_tensor.npz'
need(hashlib.sha256(raw.read_bytes()).hexdigest() ==
     '3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763',
     'Pinned native tensor matches previous construction')
Wraw = np.load(raw)['W']
need(np.all(Wraw.imag == 0), 'Native W is real')
W = Wraw.real.astype(np.int64)
need(np.array_equal(W @ W.T, 8 * np.eye(60, dtype=np.int64)),
     'Native pair vacuum Gram is 8 I60')
C2 = np.load(inputs / 'optimal_code15.npz')['C2'].astype(np.int64)
need(np.array_equal(C2.T @ C2, 4 * np.eye(15, dtype=np.int64)),
     'Original 15 dimensional inner encoder is isometric')

# Spin(10) vector weights and SU(4) exterior-square weights.
vweights = np.vstack([np.eye(5, dtype=int), -np.eye(5, dtype=int)])
fweights = np.vstack([np.eye(3, dtype=int), -np.ones((1, 3), dtype=int)])
colors = list(itertools.combinations(range(4), 2))
cweights = [fweights[a] + fweights[b] for a, b in colors]
weights = [tuple(np.r_[v, c] % 7) for v in vweights for c in cweights]
need(len(set(weights)) == 60, 'A finite Cartan average separates all 60 weights')
vorbit = set()
for perm in itertools.permutations(range(5)):
    for signs in itertools.product([-1, 1], repeat=5):
        if np.prod(signs) != 1:
            continue
        v = np.zeros(5, dtype=int)
        v[perm[0]] = signs[0]
        vorbit.add(tuple(v))
corbit = {tuple(sorted((p[0], p[1]))) for p in itertools.permutations(range(4))}
need(len(vorbit) == 10 and len(corbit) == 6,
     'Product Weyl action is transitive on all 60 weight labels')
# Dephase in the weight basis, then average the transitive Weyl group.
# Both operations consist of actual inner-group transformations.
for a, b in [(0, 1), (3, 14), (7, 11)]:
    rho_a4 = np.outer(C2[:, a], C2[:, a])
    rho_b4 = np.outer(C2[:, b], C2[:, b])
    need(np.trace(rho_a4) == np.trace(rho_b4) == 4 and
         np.trace(rho_a4 @ rho_b4) == 0,
         f'Orthogonal reference-dependent messages {a} and {b}')
    need(np.array_equal(np.full(60, np.trace(rho_a4)),
                        np.full(60, np.trace(rho_b4))),
         f'Inner reference average makes messages {a} and {b} identical')

# Center action on creation operators: f^dag -> i f^dag, b^dag -> -b^dag.
for N in [0, 1, 2, 3, 4, 8, 64]:
    phases = {s.simplify(s.I**nf * (-1)**nb)
              for nb in range(N // 2 + 1) for nf in [N - 2 * nb]}
    need(phases == {s.I**N}, f'SU4 center acts uniformly as i^N in sector {N}')
need(sum((-1)**j for j in range(4)) == 0,
     'Center projector onto invariant vectors vanishes on all of N2')
need((-s.eye(6)) * (s.eye(6)/6) * (-s.eye(6)) == s.eye(6)/6,
     'Invariant density under center is distinct from invariant-vector constraint')

# SU(4)'s 6 is real: epsilon defines a symmetric nondegenerate bilinear form.
J6 = s.zeros(6)
for a, p in enumerate(colors):
    q = tuple(x for x in range(4) if x not in p)
    perm = p + q
    inversions = sum(perm[i] > perm[j] for i in range(4) for j in range(i+1,4))
    J6[a, colors.index(q)] = (-1)**inversions
need(J6.T == J6 and J6 * J6 == s.eye(6), 'SU4 exterior square has real structure')
Ucols = []
for a, b in [(0, 5), (1, 4), (2, 3)]:
    ea, eb = s.eye(6)[:,a], s.eye(6)[:,b]
    sign = J6[a,b]
    Ucols.extend([(ea+sign*eb)/s.sqrt(2), s.I*(ea-sign*eb)/s.sqrt(2)])
U = s.Matrix.hstack(*Ucols)
need(U.conjugate().T*U == s.eye(6) and J6*U.conjugate() == U,
     'Explicit orthonormal real basis for the SU4 six')

# Four distinguishable boson banks. Three invariant pairings for each factor.
pairings = [((0,1),(2,3)), ((0,2),(1,3)), ((0,3),(1,2))]
grams = {}
for d in [6, 10]:
    idx = np.indices((d,)*4)
    tensors = [((idx[a] == idx[b]) & (idx[c] == idx[e])).astype(np.int64)
               for ((a,b),(c,e)) in pairings]
    T = np.stack([a.ravel() for a in tensors])
    Gram = s.Matrix((T @ T.T).tolist()) / d**2
    expected = (1-s.Rational(1,d))*s.eye(3)+s.ones(3)/d
    need(Gram == expected, f'Exact normalized pairing Gram in dimension {d}')
    invariant = True
    for i,j in itertools.combinations(range(d),2):
        for tensor in tensors:
            result = np.zeros_like(tensor)
            for axis in range(4):
                dst_i, dst_j = [slice(None)]*4, [slice(None)]*4
                dst_i[axis], dst_j[axis] = i,j
                result[tuple(dst_i)] += tensor[tuple(dst_j)]
                result[tuple(dst_j)] -= tensor[tuple(dst_i)]
            invariant &= not np.any(result)
    need(invariant, f'All SO({d}) generators annihilate each pairing tensor')
    grams[d] = Gram
G9 = s.kronecker_product(grams[10], grams[6])
evals = G9.eigenvals()
need(G9.rank() == 9 and all(e > 0 for e in evals),
     'Nine independent globally invariant relational states on four boson banks')
need(evals == {s.Rational(8,5):1, s.Integer(1):2,
               s.Rational(6,5):2, s.Rational(3,4):4},
     'Exact nine-state Gram spectrum')

# A quartic invariant invisible to every N <= 3 experiment confined to that sector.
for N in range(4):
    need(all(nb*(nb-1) == 0 for nb in range(N//2+1)),
         f'Boson self-interaction vanishes identically in sector N={N}')
need(2*(2-1) == 2, 'The same interaction shifts a double-boson N4 state by 2 eta')

# Infinite prescribed chain, exact bright-sector dispersion.
k, g, delta = s.symbols('k g delta', real=True, positive=True)
B = 8+4*s.cos(k)
Em = (delta-s.sqrt(delta**2+4*g**2*B))/2
curvature = s.simplify(s.diff(Em,k,2).subs(k,0)/2)
need(s.simplify(curvature-2*g**2/s.sqrt(delta**2+48*g**2)) == 0,
     'Prescribed-chain lower-band excitation has quadratic leading dispersion')
need(s.simplify(s.diff(Em,k).subs(k,0)) == 0,
     'No linear crossing at lower-band minimum in this sector')

# Check the general trace rearrangement used by the finite boost obstruction.
H = s.Matrix([[1,2+s.I,0],[2-s.I,3,1],[0,1,-2]])
P = s.Matrix([[0,s.I,2],[-s.I,2,0],[2,0,1]])
K = s.Matrix([[2,1,1-s.I],[1,-1,2],[1+s.I,2,0]])
need(s.simplify(s.trace(H*(K*P-P*K))-s.trace((H*K-K*H)*P)) == 0,
     'Trace cyclicity identity underlying the analytical finite-boost obstruction')

report = {
    'status':'PASS', 'explicit_checks':len(checks), 'checks':checks,
    'claims': {
        'reference_free_old_inner_code':'All logical density matrices have identical inner group average I60/60',
        'scope_of_reference_loss':'No retained correlated inner reference; same external multiplicity state',
        'N2_SU4_singlet_vectors':0,
        'center_necessary_singlet_condition':'N divisible by 4; not sufficient',
        'relational_candidate':'Nine independent singlet vectors; four distinct native boson banks; N=8',
        'relational_candidate_Gram_eigenvalues':{str(e):int(m) for e,m in evals.items()},
        'relational_candidate_dynamically_closed':False,
        'relational_candidate_loss_protection_after_evolution':'NOT_ESTABLISHED',
        'quartic_invariant_excluded_by_symmetry':False,
        'quartic_invariant_visible_in_N2':False,
        'chain_excitation_k2_coefficient':str(curvature),
        'spacetime_or_gauge_dynamics_derived':False,
        'universal_vacuum_or_TOE_solved':False,
    },
    'verification_boundary':'Finite certificates support analytical arguments; they do not prove Haar integration, relativistic emergence, a native measuring device, or universality.'
}
print(json.dumps(report,indent=2,sort_keys=True))
