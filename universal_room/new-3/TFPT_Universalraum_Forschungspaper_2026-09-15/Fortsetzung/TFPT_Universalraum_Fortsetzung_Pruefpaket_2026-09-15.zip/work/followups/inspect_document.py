from pathlib import Path
import fitz,json
from PIL import Image,ImageDraw
H=Path(__file__).resolve().parent;out=H.parent.parent/'outputs/fortsetzung';p=out/'TFPT_Universalraum_Sechs_Followups_2026-09-15.pdf';d=fitz.open(p);qa=H/'qa';qa.mkdir(exist_ok=True)
issues=[];pages=[]
for i,page in enumerate(d):
 text=page.get_text();pages.append({'page':i+1,'characters':len(text),'images':len(page.get_images())})
 for b in page.get_text('dict')['blocks']:
  for l in b.get('lines',[]):
   for s in l['spans']:
    x0,y0,x1,y1=s['bbox']
    if x0<0 or x1>page.rect.width+.5 or y0<0 or y1>page.rect.height+.5:issues.append([i+1,'out-of-page',s['text']])
 if '\ufffd' in text:issues.append([i+1,'replacement character'])
 if len(text)<100:issues.append([i+1,'little text'])
 pix=page.get_pixmap(matrix=fitz.Matrix(.45,.45));pix.save(qa/f'page_{i+1:02d}.png')
for start in range(0,len(d),12):
 sheet=Image.new('RGB',(1200,1750),'#cbd3d7');dr=ImageDraw.Draw(sheet)
 for j in range(start,min(start+12,len(d))):
  im=Image.open(qa/f'page_{j+1:02d}.png');im.thumbnail((280,520));x=10+(j-start)%4*300;y=25+(j-start)//4*575;sheet.paste(im,(x,y));dr.text((x,y-18),str(j+1),fill='black')
 sheet.save(qa/f'contact_{start//12+1}.png')
report={'pages':len(d),'issues':issues,'page_stats':pages};(qa/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
