"""Independent exact audit of the user's fundamental-reduction note.
Finite replay and logical examples; no rerun of the large native ground theorem.
"""
from pathlib import Path
import hashlib,itertools,json
import numpy as np
import sympy as s
H=Path(__file__).resolve().parent;checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
p=H/'native_tensor.npz'
need(hashlib.sha256(p.read_bytes()).hexdigest()=='3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763','pinned native tensor')
raw=np.load(p)['W'];need(np.all(raw.imag==0) and np.all(raw.real==np.rint(raw.real)),'integer tensor')
W=raw.real.astype(int);pairs=list(itertools.combinations(range(64),2));edges=[];adj=[set() for _ in range(64)]
rows=[];bits=[]
for A,c in zip(*np.nonzero(W)):
 i,j=pairs[c];edges.append((int(A),i,j));adj[i].add(j);adj[j].add(i)
 r=[0]*124;r[i]=r[j]=1;r[64+A]=-1;rows.append(r);bits.append((1<<i)|(1<<j))
need(len(edges)==480 and len(set((i,j) for A,i,j in edges))==480,'480 distinct native pair edges')
need(all(len(a)==15 for a in adj),'degree fifteen at every fermion mode')
seen={0};stack=[0]
while stack:
 i=stack.pop()
 for j in adj[i]-seen:seen.add(j);stack.append(j)
need(len(seen)==64,'one connected fermion pair component')
piv={}
for b in bits:
 while b:
  k=b.bit_length()-1
  if k not in piv:piv[k]=b;break
  b^=piv[k]
need(len(piv)==63,'F2 parity constraint rank63')
M=s.Matrix(rows);rank=M.to_DM().rank()
need(rank==115 and M.cols-rank==9,'rational occupation-charge rank115 and nullity9')
q=s.Matrix([1]*64+[2]*60)
need(M*q==s.zeros(480,1),'total native charge belongs to diagonal kernel')
need(all((b.bit_count()%2)==0 for b in bits),'global fermion parity preserved with unchanged bosons')
# Symmetry multiplicity example: an irreducible two-dimensional factor, two copies.
I=s.eye(2);X=s.Matrix([[0,1],[1,0]]);Z=s.diag(1,-1)
h=s.Matrix([[1,2],[2,3]]);HH=s.kronecker_product(I,h);T=s.kronecker_product(I,s.Matrix([1,0]))
need(HH*s.kronecker_product(X,I)==s.kronecker_product(X,I)*HH and HH*s.kronecker_product(Z,I)==s.kronecker_product(Z,I)*HH,'nontrivial multiplicity dynamics commutes with internal generators')
for k in range(5):
 B=T.T*HH**k*T;need(B==B[0,0]*I,'Schur scalar response illustrative moment '+str(k))
need((T.T*HH*T)[0,1]==0 and (HH**2)[0,0]!=(HH[0,0])**2,'extra spectral multiplicity does not create internal off-diagonal response')
# Neutral process equivalence needs neutral instruments as well as neutral readout.
N=s.diag(0,1);hn=s.diag(2,3);O=s.diag(1,4);mu=s.symbols('mu',real=True)
need((hn+mu*N)*O-O*(hn+mu*N)==hn*O-O*hn,'neutral Heisenberg observable unchanged')
need(N*X-X*N!=s.zeros(2),'charge changing instrument invalidates neutral-only process contract')
# Ramsey: initial |0>, granted Hadamard, free time, Hadamard, neutral |0> projector.
t=s.symbols('t',real=True);U=s.diag(1,s.exp(-s.I*mu*t));R=s.Matrix([[1,1],[1,-1]])/s.sqrt(2)
amp=(R*U*R)[0,0]
prob=s.expand_complex(amp*s.conjugate(amp)).simplify()
need(s.simplify(prob-(1+s.cos(mu*t))/2)==0,'neutral final measurement can detect chemical potential with granted charge-changing interventions')
# Imported full-Fock Casimir bound A <=15 Nf/2, independently check its scalar consequence.
g=s.Rational(1,20);m=s.Rational(1,50);cf=m-s.Rational(15,2)*g*g
need(cf==s.Rational(1,800) and 2*m>=2*cf,'source Casimir bound implies H_mu >= Delta N/800')
need((1-s.sqrt(1+32*g*g))/2<0,'mu0 already has negative bright N2 energy; global comparison needs no large ground theorem')
# Vanishing linear response does not imply no finite response.
# H=0, state |0>, even qubit observables A=X, B=|0><0|: cos(eps)^2.
B=s.diag(1,0);need((s.I*(X*B-B*X))[0,0]==0 and (X*(X*B-B*X)-(X*B-B*X)*X)[0,0]==2,'zero linear response can hide a nonzero second-order intervention')
u=H/'sources/Nutzer_Nachtrag_4.txt';old=H/'sources/S003_TFPT_Fundamentale_Reduktion_2026-09-15.md'
need(u.read_bytes().startswith(old.read_bytes()),'new attachment begins byte-for-byte with already included S003')
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'pair_graph':{'vertices':64,'edges':480,'degree':15,'components':1,'fermion_only_parity_rank_F2':63},'diagonal_charge_constraints':{'variables':124,'rank_Q':115,'dimension':9},'neutral_process_caveat':'All interventions, preparations and reference accesses must be within the declared neutral contract; a neutral final readout alone is insufficient.','large_ground_and_pole_replayed':False,'source_Casimir_identity_assumed_for_vacuum_bound':True,'attachment_main_text_already_in_original_paper':True},indent=2,sort_keys=True))
