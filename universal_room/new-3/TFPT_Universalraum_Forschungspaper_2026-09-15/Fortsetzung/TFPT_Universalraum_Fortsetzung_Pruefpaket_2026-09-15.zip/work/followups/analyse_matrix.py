from pathlib import Path
import json,sympy as s
H=Path(__file__).resolve().parent;r=json.loads((H/'matrix_contraction.json').read_text());checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
G=s.Matrix(r['seed_gram_scaled']).applyfunc(s.Integer)/14400
M=s.Matrix(r['mixed_gram_scaled']).applyfunc(s.Integer)/14400
UG=s.Matrix(r['contracted_gram_scaled']).applyfunc(s.Integer)/14400
C=G.inv()*M
need(G==s.diag(17280,7680,241920,172800),'native four orthogonal projected norms')
need(M==M.T,'mixed moments Hermitian')
need(all(M[:k,:k].det()>0 for k in range(1,5)),'raising block rank four and positive Gram')
need(UG-M.T*G.inv()*M==s.zeros(4),'exact contraction closes on full second-level singlet space')
need(sum(M)==575078400,'sum agrees with independent historical third-level norm')
legacy=json.loads((H/'sources/old_contraction.json').read_text())
need(sum(UG)==legacy['u_norm2'],'sum agrees with independent contracted norm')
need(sum(UG)-sum(M)**2/sum(G)==s.Rational(5001523200,229),'independent old transverse norm reproduced')
# Conservative arithmetic bounds for every accumulator, no cancellation assumed.
coef_bound=r['seed_states']*480*3*8*3*r['maximum_seed_coefficient']
need(coef_bound<2**63,'int64 accumulation safe by a priori transition bound')
need(r['contracted_states']*2*coef_bound**2<2**127,'int128 Gram safe by a priori bound')
z=s.symbols('z');cp=s.Poly(C.charpoly(z).as_expr(),z);ints=cp.intervals(eps=s.Rational(1,10**8))
need(len(ints)==4 and all(a>0 and mult==1 for ((a,b),mult) in ints),'four simple positive raising singular values squared')
need(cp.count_roots(1308,1309)==1 and cp.count_roots(1309,s.oo)==0,'largest raising square below 1309')
# Rational generalized Hamiltonian compression for 1+1+4+4 states.
gx=s.symbols('g',real=True);J=s.diag(0,1,*([2]*4),*([3]*4))
J[1,0]=gx;J[0,1]=480*gx
for i in range(4):
 J[2+i,1]=gx;J[1,2+i]=gx*G[i,i]/480
 J[6+i,2+i]=gx
 for j in range(4):J[2+i,6+j]=gx*C[i,j]
metric=s.diag(1,480,G,M)
need(J.T*metric==metric*J,'ten-state Hamiltonian is selfadjoint in exact positive Gram')
J20=J.subs(gx,s.Rational(1,20));char=s.Poly((z*s.eye(10)-J20).det(method='domain-ge'),z)
roots=char.intervals(eps=s.Rational(1,10**11));lowest=roots[0][0]
need(char.count_roots(-s.oo,lowest[0])==0,'lowest Ritz root isolated')
# Moments up through seven cannot visit level four from the filled state.
f=s.eye(10)[:,0];mom=[]
for n in range(8):mom.append(s.expand(f[0]));f=J*f
old=json.loads((H.parent/'connections_normal.json').read_text()) if (H.parent/'connections_normal.json').exists() else None
expected=[1,0,480*gx**2,480*gx**2,480*gx**2+670080*gx**4,480*gx**2+2219520*gx**4,480*gx**2+5527680*gx**4+1510510080*gx**6,480*gx**2+12353280*gx**4+10437173760*gx**6]
need(mom==expected,'eight exact filled-state moments match original independent scalar chain')
out={'status':'PASS','exact_checks':len(checks),'checks':checks,'labels':['54,1','1,20prime','54,20prime','45,15'],'seed_gram':G.tolist(),'mixed_gram':M.tolist(),'coefficient_matrix':C.tolist(),'characteristic_polynomial':str(cp.as_expr()),'eigenvalue_squared_intervals':[[str(a),str(b)] for ((a,b),mult) in ints],'max_eigenvalue_squared_numerical':float(ints[-1][0][1]),'ten_state_Ritz_interval':[str(x) for x in lowest],'ten_state_Ritz_numerical':float(lowest[1]),'ten_state_compression_dimension':10,'cutoff_two_exact_residual_squared':'g^2 times largest eigenvalue of C','F_moments_0_7':[str(x) for x in mom],'arithmetic_bounds':{'int64':coef_bound,'int128':r['contracted_states']*2*coef_bound**2},'full_3_boson_space_enumerated':False,'full_ground_state_solved':False}
print(json.dumps(out,default=str,indent=2,sort_keys=True))
