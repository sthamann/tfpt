"""Reproduce the scoped follow-up results in this extracted package.
Requires Python3, numpy, scipy, sympy and a C++17 compiler with __int128.
Run in a disposable extracted copy: seed and encoder files are regenerated.
"""
from pathlib import Path
import subprocess,sys,shutil,json,hashlib
H=Path(__file__).resolve().parent;R=H/'replay';R.mkdir(exist_ok=True)
def run(args,name):
 print(name,flush=True)
 p=subprocess.run(args,cwd=H,capture_output=True)
 (R/(name+'.stderr')).write_bytes(p.stderr)
 if p.returncode:sys.stderr.buffer.write(p.stderr);raise RuntimeError(name+' failed')
 return p.stdout
def equal(a,b,label):
 if a!=b:raise RuntimeError(label+' mismatch')
# Fail closed on all recorded scientific inputs, independent of live sources.
manifest=H/'inputs_manifest.json'
for x in json.loads(manifest.read_text()):
 q=H/x['relative_path'];equal(hashlib.sha256(q.read_bytes()).hexdigest(),x['sha256'],'input '+x['relative_path'])
run([sys.executable,str(H/'build_matrix_seeds.py')],'projected_seeds')
cc=shutil.which('clang++') or shutil.which('g++')
if not cc:raise RuntimeError('C++17 compiler required')
cpp=[]
for mode,opt in [('optimized','-O2'),('unoptimized','-O0')]:
 binary=R/('contract_'+mode)
 run([cc,'-std=c++17',opt,str(H/'matrix_contract.cpp'),'-o',str(binary)],'compile_'+mode)
 b=run([str(binary),str(H/'matrix_input.txt')],'contract_'+mode);(R/('contraction_'+mode+'.json')).write_bytes(b)
 equal(b,(H/'matrix_contraction.json').read_bytes(),'new native contraction '+mode);cpp.append(b)
equal(*cpp,'C++ modes')
checks=0
for script,prefix in [('verify_code15.py','code15'),('verify_selection_process.py','selection'),('verify_native_reference.py','reference'),('verify_wick.py','wick'),('analyse_matrix.py','matrix'),('verify_control_audit.py','controls'),('verify_reduction_audit.py','reduction')]:
 results=[]
 for mode,flags in [('normal',[]),('optimized',['-OO'])]:
  b=run([sys.executable,*flags,str(H/script)],prefix+'_'+mode)
  (R/(prefix+'_'+mode+'.json')).write_bytes(b)
  equal(b,(H/(prefix+'_normal.json')).read_bytes(),prefix+' replay '+mode)
  result=json.loads(b)
  if result['status']!='PASS':raise RuntimeError(prefix+' nonPASS')
  results.append(b)
 equal(*results,prefix+' modes');checks+=result['exact_checks']
report={'status':'PASS','exact_conditions':checks,'python_checks_normal_and_optimized_byte_identical':True,'native_cpp_contraction_both_compiler_modes_byte_identical':True,'matches_packaged_results':True,'large_native_ground_proof_rerun':False,'T1_T8_closed':[]}
(R/'replay_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
