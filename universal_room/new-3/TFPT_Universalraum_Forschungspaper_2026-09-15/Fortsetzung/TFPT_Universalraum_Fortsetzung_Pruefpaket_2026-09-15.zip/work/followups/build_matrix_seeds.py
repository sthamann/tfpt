from pathlib import Path
from collections import defaultdict
from itertools import combinations
import numpy as np,json
H=Path(__file__).resolve().parent
raw=np.load(H/'native_tensor.npz')['W']
if np.any(raw.imag) or not np.all(raw.real==np.rint(raw.real)):raise RuntimeError('nonintegral W')
W=raw.real.astype('int64');pairs=list(combinations(range(64),2));support=[(int(A),*pairs[int(c)],int(W[A,c])) for A,c in zip(*np.nonzero(W))]
def sign(mask,i):return -1 if (mask&((1<<i)-1)).bit_count()%2 else 1
v=defaultdict(int)
for A,i,j,w in support:
 mask=(1<<i)|(1<<j)
 for B,k,l,z in support:
  if mask&((1<<k)|(1<<l)):continue
  v[(mask|(1<<k)|(1<<l),min(A,B),max(A,B))]+=w*z*sign(mask,l)*sign(mask|(1<<l),k)
v={k:a for k,a in v.items() if a};R={}
for (mask,A,B),a in v.items():
 if A==B:R[(mask,A,B)]=2*a
 else:R[(mask,A,B)]=R[(mask,B,A)]=a
colors=list(combinations(range(4),2));cb=[];ce=[]
for a,b in colors:
 c,d=[x for x in range(4) if x not in [a,b]];p=[a,b,c,d]
 cb.append(colors.index((c,d)));ce.append((-1)**sum(p[i]>p[j] for i in range(4) for j in range(i+1,4)))
sp=defaultdict(int);co=defaultdict(int)
for (m,A,B),a in R.items():
 k,c=divmod(A,6);l,d=divmod(B,6)
 if l==(k+5)%10:sp[m,c,d]+=a
 if d==cb[c]:co[m,k,l]+=ce[c]*a
vec=defaultdict(lambda:[0,0,0,0])
# ordered tensors, all components scaled by 120.
for (m,A,B),a in R.items():
 k,c=divmod(A,6);l,d=divmod(B,6)
 vec[m,A,B][2]+=60*a;vec[m,6*l+c,6*k+d][2]+=60*a
 vec[m,A,B][3]+=60*a;vec[m,6*l+c,6*k+d][3]-=60*a
for (m,k,l),a in co.items():
 if a:
  for c in range(6):
   key=(m,6*k+c,6*l+cb[c]);v0=20*ce[c]*a
   vec[key][0]+=v0;vec[key][2]-=v0
for (m,c,d),a in sp.items():
 if a:
  for k in range(10):
   key=(m,6*k+c,6*((k+5)%10)+d);v1=12*a
   vec[key][1]+=v1;vec[key][2]-=v1
phys={}
for (m,A,B),a in vec.items():
 if A>B:continue
 if not any(a):continue
 if a!=vec[m,B,A]:raise RuntimeError('boson symmetry')
 if A==B:
  if any(x%2 for x in a):raise RuntimeError('diagonal normalization')
  a=[x//2 for x in a]
 phys[m,A,B]=a
norm=np.zeros((4,4),dtype=object)
for (m,A,B),a in phys.items():
 if sum(a)!=120*v.get((m,A,B),0):raise RuntimeError('projectors sum')
 for i in range(4):
  for j in range(4):norm[i,j]+=a[i]*a[j]*(2 if A==B else 1)
expected=[17280,7680,241920,172800]
if norm.tolist()!=np.diag([x*14400 for x in expected]).tolist():raise RuntimeError(str(norm))
with (H/'matrix_input.txt').open('w') as f:
 f.write('480\n')
 for line in support:f.write(' '.join(map(str,line))+'\n')
 f.write(str(len(phys))+'\n')
 for (m,A,B),a in sorted(phys.items()):f.write(' '.join(map(str,[m,A,B,*a]))+'\n')
(H/'seed_report.json').write_text(json.dumps({'states':len(phys),'scale':120,'labels':['54,1','1,20prime','54,20prime','45,15'],'norms':expected,'all_projector_cross_grams_zero':True,'sum_is_original_v2':True},indent=2))
print('Four projected seeds:',len(phys),'configurations; exact orthogonal norms:',expected)
