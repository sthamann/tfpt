from pathlib import Path
import json,itertools
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent
OUT=H.parent.parent/'outputs/fortsetzung/figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
r=json.loads((H/'matrix_normal.json').read_text());G=np.array(r['seed_gram'],float);M=np.array(r['mixed_gram'],float);d=np.sqrt(np.diag(G));B=M/d[:,None]/d[None,:]
fig,ax=plt.subplots(figsize=(6.4,4.9),layout='constrained');im=ax.imshow(B,cmap='Blues',vmin=0,vmax=1000)
labels=['(54, 1)',"(1, 20′)","(54, 20′)",'(45, 15)'];ax.set_xticks(range(4),labels,rotation=0);ax.set_yticks(range(4),labels)
for i in range(4):
 for j in range(4):ax.text(j,i,f'{B[i,j]:.2f}',ha='center',va='center',color='white' if B[i,j]>530 else '#17344a')
ax.set_title('Gemeinsame Rückwirkung auf vier Singuletts',loc='left',fontweight='bold',pad=18);fig.colorbar(im,ax=ax,label='Matrixelement in normierter Basis',shrink=.82)
fig.savefig(OUT/'matrixmomente.pdf');fig.savefig(OUT/'matrixmomente.png',dpi=180);plt.close(fig)
z=np.load(H/'optimal_code15.npz');print(z.files)
E=z['encoded_integer'];pairs=list(itertools.combinations(range(64),2));partners=[]
for a in range(15):
 js=[j for j in np.flatnonzero(E[:,a]) if 0 in pairs[j]]
 if len(js)!=1:raise RuntimeError('not matching')
 j=js[0];partners.append((pairs[j][1],int(E[j,a])))
fig,ax=plt.subplots(figsize=(6.8,5.6),layout='constrained');ax.set_aspect('equal');ax.axis('off')
for a,(p,sgn) in enumerate(partners):
 angle=np.pi/2-2*np.pi*a/15;x,y=np.cos(angle),np.sin(angle)
 ax.plot([0,x],[0,y],color='#6ab0b5',linewidth=1.8)
 ax.scatter([x],[y],s=450,facecolor='#e4f2f2',edgecolor='#20768a',zorder=3)
 ax.text(x,y,str(p),ha='center',va='center',fontsize=11,color='#17344a')
 ax.text(1.26*x,1.26*y,f'{a}: {"+" if sgn>0 else "−"}',ha='center',va='center',fontsize=9,color='#17344a')
ax.scatter([0],[0],s=1200,color='#17344a',zorder=4);ax.text(0,0,'Mode\n0',color='white',ha='center',va='center',zorder=5)
ax.set_xlim(-1.53,1.53);ax.set_ylim(-1.43,1.55);ax.set_title('15 unterscheidbare Partner nach bekanntem Verlust',loc='left',fontweight='bold',pad=8)
fig.text(.5,.018,'Kreis: verbleibende Mode · außen: logischer Kanal und Vorzeichen',ha='center',fontsize=9,color='#425563')
fig.savefig(OUT/'code15_partner.pdf');fig.savefig(OUT/'code15_partner.png',dpi=180);plt.close(fig)
