"""Finite faithful algebra audit of the user-supplied binary-control claim."""
import sympy as s,json
checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
X=s.diag(*[s.Matrix([[0,l],[1,0]]) for l in [7,10,12]],0,0,0,0)
Nb=s.diag(0,1,0,1,0,1,1,0,0,0)
Cs=s.diag(85,85,85,85,45,45,45,165,141,117)
P=s.diag(0,0,0,0,0,0,0,1,0,0)
def algebra(gens):
 basis=[s.eye(10)];vec=s.eye(10).reshape(100,1);cursor=0
 while cursor<len(basis):
  b=basis[cursor];cursor+=1
  for g in gens:
   a=g*b;v=a.reshape(100,1);test=vec.row_join(v)
   if test.rank()>len(basis):basis.append(a);vec=test
 return len(basis)
dims=[algebra([X,Nb]),algebra([X,Nb,P]),algebra([X,Nb,Cs])]
need(dims==[14,15,16],'intermediate and single Casimir control algebras exist')
need(Cs*X==X*Cs and Cs*Nb==Nb*Cs,'extra Casimir remains G-invariant central control')
bright=2880**2+576**2+320**2
comm=[37888**2+64**2+bright,2688**2+35200**2+64**2+bright,2688**2+24000**2+11200**2+64**2+bright]
need(comm[0]==1444233216,'narrow control commutant matches native source')
need(comm[0]>comm[1]>comm[2]>7,'operational ambiguity does not collapse to universal yes/no choice')
need((165+15)==(141+39)==(117+63)==180,'three dark total Casimirs coincide')
need(len(set([165,141,117]))==3,'one separated Casimir distinguishes three dark types')
# A positive symmetry-invariant number Hamiltonian may have a non-singlet lowest sector.
energies=[(n-1)**2 for n in range(65)]
need(energies[1]==0 and all(e>0 for n,e in enumerate(energies) if n!=1),'symmetry alone does not restrict ground-sector competition to singlets')
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'operator_algebra_dimensions':dims,'commutant_dimensions':comm,'with_full_inner_group_commutant_dimension':7,'already_established_in_source':'S033 v1.6.6; independently replayed here to check new user texts','nonsinglet_counterexample':'H=(N-1)^2 on the finite fermionic Fock space: G-invariant, positive, N=1 ground sector of dimension64. Outside the cubic ansatz; a counterexample to the general logical inference, not to the native ground theorem.','claim_binary_control_choice_valid':False,'claim_two_separate_Casimirs_required_valid':False},indent=2,sort_keys=True))
