#include <array>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <string>
#include <stdexcept>
using I=__int128_t; using V=std::array<int64_t,4>;
struct Key {uint64_t m;int code; bool operator==(const Key&o)const{return m==o.m&&code==o.code;}};
struct Hash {size_t operator()(const Key&k)const{return std::hash<uint64_t>{}(k.m)^(size_t(k.code)*0x9e3779b97f4a7c15ULL);}};
struct Pair{int a,i,j,w;uint64_t m;};
using State=std::unordered_map<Key,V,Hash>;
int sign(uint64_t m,int i){return __builtin_popcountll(m&((uint64_t(1)<<i)-1))%2?-1:1;}
int up(uint64_t m,const Pair&p){return sign(m,p.j)*sign(m|(uint64_t(1)<<p.j),p.i);}
int down(uint64_t m,const Pair&p){return sign(m,p.i)*sign(m^(uint64_t(1)<<p.i),p.j);}
std::string str(I n){if(n==0)return "0";bool neg=n<0;if(neg)n=-n;std::string s;while(n){s.push_back('0'+n%10);n/=10;}if(neg)s.push_back('-');std::reverse(s.begin(),s.end());return s;}
void matrix(const std::array<std::array<I,4>,4>&M){std::cout<<"[";for(int i=0;i<4;i++){if(i)std::cout<<",";std::cout<<"[";for(int j=0;j<4;j++){if(j)std::cout<<",";std::cout<<"\""<<str(M[i][j])<<"\"";}std::cout<<"]";}std::cout<<"]";}
int main(int argc,char**argv){
 if(argc!=2)throw std::runtime_error("input required");std::ifstream in(argv[1]);int n;in>>n;if(n!=480)throw std::runtime_error("480 vertices required");
 std::vector<Pair> ps;std::array<std::vector<Pair>,60>channels;
 for(int t=0;t<n;t++){Pair p;in>>p.a>>p.i>>p.j>>p.w;p.m=(uint64_t(1)<<p.i)|(uint64_t(1)<<p.j);ps.push_back(p);channels[p.a].push_back(p);}
 State S,U;in>>n;S.reserve(n*2);U.reserve(n*3);int64_t maxseed=0,maxu=0;
 for(int t=0;t<n;t++){uint64_t m;int a,b;V v;in>>m>>a>>b;for(auto&x:v){in>>x;maxseed=std::max(maxseed,int64_t(std::abs(x)));}S[{m,a*60+b}]=v;}
 if(!in)throw std::runtime_error("input parse failed");uint64_t raise=0,lower=0;
 for(const auto&[key,v]:S){
  for(const auto&p:ps)if(!(key.m&p.m)){
   raise++;uint64_t m3=key.m|p.m;int s1=p.w*up(key.m,p);std::array<int,3>bs{key.code/60,key.code%60,p.a};std::sort(bs.begin(),bs.end());
   for(int k=0;k<3;k++){
    if(k&&bs[k]==bs[k-1])continue;int B=bs[k],mult=0;for(int x:bs)mult+=(x==B);int a=-1,b=-1;for(int j=0;j<3;j++)if(j!=k){if(a<0)a=bs[j];else b=bs[j];}
    for(const auto&q:channels[B])if((m3&q.m)==q.m){
     lower++;int fac=s1*mult*q.w*down(m3,q);auto&dest=U[{m3^q.m,a*60+b}];for(int i=0;i<4;i++)dest[i]+=fac*v[i];
    }
   }
  }
 }
 std::array<std::array<I,4>,4>G{},M{},UG{};
 for(const auto&[key,v]:S){int f=(key.code/60==key.code%60)?2:1;auto it=U.find(key);for(int i=0;i<4;i++)for(int j=0;j<4;j++){G[i][j]+=I(f)*v[i]*v[j];if(it!=U.end())M[i][j]+=I(f)*v[i]*it->second[j];}}
 for(const auto&[key,v]:U){int f=(key.code/60==key.code%60)?2:1;for(auto x:v)maxu=std::max(maxu,int64_t(std::abs(x)));for(int i=0;i<4;i++)for(int j=0;j<4;j++)UG[i][j]+=I(f)*v[i]*v[j];}
 std::cout<<"{\"scale\":120,\"seed_states\":"<<S.size()<<",\"contracted_states\":"<<U.size()<<",\"raising_transitions\":"<<raise<<",\"lowering_transitions\":"<<lower<<",\"maximum_seed_coefficient\":"<<maxseed<<",\"maximum_contracted_coefficient\":"<<maxu<<",\"seed_gram_scaled\":";matrix(G);std::cout<<",\"mixed_gram_scaled\":";matrix(M);std::cout<<",\"contracted_gram_scaled\":";matrix(UG);std::cout<<"}\n";
}
