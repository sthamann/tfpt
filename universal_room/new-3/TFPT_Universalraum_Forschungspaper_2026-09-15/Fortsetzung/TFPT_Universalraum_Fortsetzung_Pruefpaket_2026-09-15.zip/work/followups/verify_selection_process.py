"""Symbolic normal form, operational obstruction, and composition witnesses."""
import sympy as s,json
checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
def eq(a,b,label):need(s.simplify(a-b)==0,label)
c,h=s.symbols('c h',real=True);delta,kap=s.symbols('Delta kappa',real=True)
gr,gi,lr,li=s.symbols('gr gi lr li',real=True)
g=gr+s.I*gi;lam=lr+s.I*li
# Gauge kappa real and nonnegative; use c=cosh r, h=sinh r and algebraic reduction.
gp=c*g-h*s.conjugate(lam);lp=c*lam-h*s.conjugate(g)
U=s.expand(abs(g)**2-abs(lam)**2)
expr=s.expand(gp*s.conjugate(gp)-lp*s.conjugate(lp)-(c*c-h*h)*U)
eq(expr,0,'complex coupling difference preserved by canonical squeezing')
S=s.expand(abs(g)**2+abs(lam)**2);Re=s.re(g*lam)
eq(s.expand(gp*s.conjugate(gp)+lp*s.conjugate(lp)),(c*c+h*h)*S-4*c*h*Re,'complex coupling sum in bosonic normal frame')
# c²+h²=Delta/Omega, 2ch=kappa/Omega. Original complex kappa restored by gauge covariance.
x=s.symbols('x',real=True)
Dp=(delta*(1+x*x)-2*kap*x)/(1-x*x);Kp=(kap*(1+x*x)-2*delta*x)/(1-x*x)
eq(Dp**2-Kp**2,delta**2-kap**2,'positive oscillator frequency invariant')
U0,V0=s.symbols('U0 V0',real=True)
# The two remaining phases independently remove both nonzero coupling phases.
phase_map=s.Matrix([[-1,2],[-1,-2]])
need(phase_map.det()==4,'remaining boson and fermion phases independently fix both cubic phases')
# Explicit complex nonzero phases: Delta=5, kappa=3, cosh r=3/sqrt8, sinh r=1/sqrt8.
vals={c:3/s.sqrt(8),h:1/s.sqrt(8),gr:1,gi:1,lr:2,li:-1}
a=s.simplify(gp.subs(vals));b=s.simplify(lp.subs(vals))
G2=s.simplify(a*s.conjugate(a));L2=s.simplify(b*s.conjugate(b));K=5*7-2*3*3
need((G2,L2)==(s.Rational(5,8),s.Rational(29,8)),'complex normal form example')
eq(G2+L2,s.Rational(K,4),'normal form invariant K/Omega')
eq(G2-L2,-3,'normal form invariant U')
# Non-real kappa: independent phase-sensitive normal-form example.
u=3/s.sqrt(8);vv=-s.I/s.sqrt(8);kc=3*s.I
kp=2*5*u*vv+kc*u*u+s.conjugate(kc)*vv*vv
dp=5*(u*u+vv*s.conjugate(vv))+kc*u*s.conjugate(vv)+s.conjugate(kc)*u*vv
eq(kp,0,'nonreal anomalous boson coefficient eliminated')
eq(dp,4,'nonreal kappa leaves positive frequency four')
ag=(1+s.I)*u+(2+s.I)*vv;al=(2-s.I)*u+(1-s.I)*vv
need((s.simplify(ag*s.conjugate(ag)),s.simplify(al*s.conjugate(al)))==(s.Rational(17,8),s.Rational(41,8)),'phase-sensitive canonical cubic magnitudes')
# Exact noninteracting growth intertwiner: append an eigenstate, retain all existing dynamics.
hnative=s.Matrix([[0,s.sqrt(8)],[s.sqrt(8),2]])
vref=s.Matrix([s.sqrt(2),-1])/s.sqrt(3)
emb=s.kronecker_product(s.eye(2),vref)
hpair=s.kronecker_product(hnative,s.eye(2))+s.kronecker_product(s.eye(2),hnative)
need(emb.T*emb==s.eye(2),'exact growth embedding is isometric')
need(s.simplify(hpair*emb-emb*(hnative-2*s.eye(2)))==s.zeros(4,2),'growth preserves existing dynamics up to appended reference energy')
# Native physical dimensionless distinction, already known, embedded into composable families.
R=lambda x:1+1396*x*x
need(R(s.Rational(1,20))!=R(s.Rational(1,40)),'two stable native dynamics retain dimensionless response difference')
X=s.Matrix([[0,1],[1,0]]);Z=s.diag(1,-1);P=s.diag(0,1);I=s.eye(2)
need(len(s.Matrix.hstack(*(s.Matrix(a).reshape(4,1) for a in [I,X,P,X*P])).columnspace())==4,'native bright controls generate M2')
# Same controls preserve every inner logical label. Algebra closure cannot create an independent noncommuting second factor.
A=s.kronecker_product(X,I);B=s.kronecker_product(P,I)
need(A*B-B*A!=s.zeros(4),'conversion and occupancy fail to commute')
need(A*s.kronecker_product(I,X)==s.kronecker_product(I,X)*A,'formal multiplicity controls would commute but are extra')
# A G invariant source/target scalar tensor moves the multiplicity and not the irreducible label.
a0,b0,J=s.symbols('a0 b0 J',real=True)
H4=s.Matrix([[0,a0,0,0],[a0,b0,J,0],[0,J,b0,a0],[0,0,a0,0]])
eq((H4**3)[3,0],a0*a0*J,'two-copy transition requires explicit inter-copy coupling')
need(H4.subs(J,0)[:2,2:]==s.zeros(2),'no inter-copy transport from local Hamiltonians alone')
# Measurement-assisted native pair/boson conversion: finite success cost.
p=s.Rational(2,27)
eq(1/p,s.Rational(27,2),'mean attempts with supplied unresolved occupancy measurement')
eq(p+(1-p),1,'instrument branch probabilities normalized')
# Coarse-graining an interacting pair: reduced state does not fix its derivative.
H=s.kronecker_product(X,X);OB=s.kronecker_product(Z,I)
ket0=s.Matrix([1,0]);plus=s.Matrix([1,1])/s.sqrt(2);minus=s.Matrix([1,-1])/s.sqrt(2)
# rho_A=+y makes derivative of Z nonzero with sign set by B.
yp=s.Matrix([1,s.I])/s.sqrt(2);rhoA=yp*yp.H
rhos=[s.kronecker_product(rhoA,v*v.H) for v in [plus,minus]]
derivs=[s.simplify(s.I*s.trace(r*(H*OB-OB*H))) for r in rhos]
need(derivs==[2,-2],'identical retained state different discarded memory changes future derivative')
# Exact finite network example for observed action.
t=s.symbols('t',real=True);state=s.Matrix([0,1,0,0]) # |01> on two hard-core sites
XX=(s.kronecker_product(X,X)+s.kronecker_product(s.Matrix([[0,-s.I],[s.I,0]]),s.Matrix([[0,-s.I],[s.I,0]])))/2
need(XX*state==s.Matrix([0,0,1,0]),'explicit added edge exchanges one excitation')
# Exact orthogonal block-average compression on a 4-chain.
Lap=s.Matrix([[1,-1,0,0],[-1,2,-1,0],[0,-1,2,-1],[0,0,-1,1]])
E=s.Matrix([[1,0],[1,0],[0,1],[0,1]])/s.sqrt(2);hsmall=E.T*Lap*E;Rr=Lap*E-E*hsmall
need(hsmall==s.Matrix([[1,-1],[-1,1]])/2,'exact block-average compression')
need(Rr.T*Rr==s.Matrix([[1,-1],[-1,1]])/2,'nonzero exact decimation leakage')
need(Rr!=s.zeros(4,2),'small Hamiltonian is not an exact closed coarse-grained dynamics')
# Number-conserving vacuum source cannot bootstrap particles with its own two controls.
N2=s.diag(0,1,1);X2=s.Matrix([[0,0,0],[0,0,1],[0,1,0]]);vac=s.Matrix([1,0,0])
need(X2*vac==s.zeros(3,1) and N2*vac==s.zeros(3,1),'vacuum remains invariant under number-conserving primitive controls')
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'stable_complex_normal_form':{'Omega':'sqrt(Delta^2-|kappa|^2)','U':'|g|^2-|lambda|^2','K':'Delta*(|g|^2+|lambda|^2)-2*Re(conj(kappa)*g*lambda)','G_squared':'(K/Omega+U)/2','L_squared':'(K/Omega-U)/2','free_dimensionless_parameters':['epsilon/Omega','G/Omega','L/Omega'],'scope':'Uniform G-compatible bosonic Bogoliubov transformations and global fermion/boson phases; Delta>|kappa|; no nonuniform nonlinear equivalence claim.'},'complex_example':{'Delta':5,'kappa':3,'g':'1+i','lambda':'2-i','Omega':4,'G_squared':str(G2),'L_squared':str(L2)},'composition_does_not_select_unique_coupling':True,'native_reference_preparation_from_vacuum_under_X_Nb':False,'same_retained_state_derivatives':list(map(str,derivs)),'coarse_graining_leakage_norm':1,'physical_spatial_graph_selected':False,'T1_T8_closed':[]},indent=2,sort_keys=True))
