"""Mixed word coefficients from formal trace networks, checked against independent Fock enumeration."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
import numpy as np,json
H=Path(__file__).resolve().parent;checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
def direct_pair_word(matrices):
 d=matrices[0].shape[0];state={0:1}
 for A in matrices:
  new=defaultdict(int)
  for m,v in state.items():
   for i,j in combinations(range(d),2):
    if not A[i,j] or (m>>i)&1 or (m>>j)&1:continue
    sg=(-1)**((m&((1<<j)-1)).bit_count()+((m|(1<<j))&((1<<i)-1)).bit_count())
    new[m|(1<<i)|(1<<j)]+=v*int(A[i,j])*sg
  state={m:v for m,v in new.items() if v}
 return state
def trace_word_overlap(left,right):
 k=len(left);d=left[0].shape[0];Q={}
 for i,A in enumerate(left):
  for j,B in enumerate(right):Q[(1<<i)|(1<<(k+j))]=A.T@B
 power=Q;log={}
 for n in range(1,k+1):
  for mask,A in power.items():
   value=F((-1)**(n+1)*int(np.trace(A)),2*n)
   if value:log[mask]=log.get(mask,F(0))+value
  if n<k:
   nextpower={}
   for ma,A in power.items():
    for mb,B in Q.items():
     if not ma&mb:
      mask=ma|mb;product=A@B
      if mask in nextpower:nextpower[mask]+=product
      else:nextpower[mask]=product
   power=nextpower
 exponential={0:F(1)};term={0:F(1)}
 for n in range(1,k+1):
  new=defaultdict(F)
  for a,x in term.items():
   for b,y in log.items():
    if not a&b:new[a|b]+=x*y/n
  term=dict(new)
  for a,x in term.items():exponential[a]=exponential.get(a,F(0))+x
 return exponential.get((1<<(2*k))-1,F(0))
def test(left,right,label):
 a=direct_pair_word(left);b=direct_pair_word(right)
 exact=sum(v*b.get(m,0) for m,v in a.items());network=trace_word_overlap(left,right)
 need(network==exact,label)
 return exact
raw=np.load(H/'native_tensor.npz')['W'];need(np.all(raw.imag==0) and np.all(raw.real==np.rint(raw.real)),'real integral tensor')
W=raw.real.astype(np.int64);pairs=list(combinations(range(64),2));native=[]
for row in W:
 a=np.zeros((64,64),dtype=np.int64)
 for val,(i,j) in zip(row,pairs):a[i,j]=val;a[j,i]=-val
 native.append(a)
# Guaranteed nonzero norms, mixed projections and zeros all tested; no random-only acceptance.
nonzero=zero=0
for j in range(16):
 ids=[j,(7*j+5)%60];other=ids if j%2==0 else [ids[1],ids[0]]
 v=test([native[i] for i in ids],[native[i] for i in other],'native four-pair mixed trace '+str(j))
 nonzero+=v!=0;zero+=v==0
for j in range(16):
 ids=[j,(11*j+3)%60];other=[(j+7)%60,(3*j+2)%60]
 v=test([native[i] for i in ids],[native[i] for i in other],'native off-diagonal trace '+str(j));nonzero+=v!=0;zero+=v==0
# Arbitrary integer skew forms probe sixth-order mixed coefficients and CAR signs.
rng=np.random.default_rng(731)
for j in range(12):
 mats=[]
 for k in range(6):
  a=rng.integers(-2,3,size=(8,8),dtype=np.int64);mats.append(a-a.T)
 v=test(mats[:3],mats[3:],'sixth-order mixed Wick coefficient '+str(j));nonzero+=v!=0;zero+=v==0
need(nonzero>10 and zero>0,'test set includes nonzero interference and zero controls')
# Integer a priori bound for the tested dimensions, word lengths and entries.
need(64**6*4**12<2**63,'conservative tested trace/Fock integer bounds')
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'native_k2_tests':32,'arbitrary_k3_tests':12,'nonzero_results':nonzero,'zero_results':zero,'method':'square-free coefficient of exp[sum_n (-1)^(n+1) Tr((A^dag B)^n)/(2n)]','branch':'formal power series with constant coefficient one','full_native_k3_projector_network_evaluated':False,'scope':'Reusable mixed-pair-word trace engine. Native k2 and eight-mode k3 compared with independent occupation enumeration. Higher full native observable words require additional operator insertions.'},indent=2,sort_keys=True))
