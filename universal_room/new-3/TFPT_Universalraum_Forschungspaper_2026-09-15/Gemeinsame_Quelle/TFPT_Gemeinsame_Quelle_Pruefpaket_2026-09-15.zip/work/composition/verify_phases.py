"""Exact source-phase and doubled overlap-loop tests; no emergent gauge dynamics claimed."""
from pathlib import Path
import sympy as s,json
H=Path(__file__).resolve().parent;checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
results={};Bs={}
for name,z in [('zero',s.Integer(1)),('pi_over_two',s.I),('pi',s.Integer(-1))]:
 V=s.Matrix([[1,1,0],[0,1,1],[z,0,1]])
 S=V*V.conjugate().T/2;G=S.applyfunc(lambda x:x*x);B=8*G;Bs[name]=B
 need(B==B.conjugate().T,name+' induced pair response Hermitian')
 need(all(B[:k,:k].det()>0 for k in range(1,4)),name+' positive pair Gram')
 need(s.simplify(B[0,1]*B[1,2]*B[2,0]-8*z*z)==0,name+' induced loop phase is twice the source phase')
 results[name]={'source_rows_without_sqrt2':V.tolist(),'source_rank':V.rank(),'backreaction':B.tolist(),'eigenvalues':{str(k):m for k,m in B.eigenvals().items()},'loop_product':str(B[0,1]*B[1,2]*B[2,0])}
need(Bs['zero']==Bs['pi'],'complete boson-only N2 response cannot distinguish source flux zero from pi')
need(results['zero']['source_rank']==3 and results['pi']['source_rank']==2,'identical bosonic response hides different fermionic dark directions')
need(results['pi_over_two']['eigenvalues']=={'4':1,'10':2},'half-pi source phase changes the neutral bosonic spectrum')
V=s.Matrix([[1,1,0],[0,1,1],[-1,0,1]]);dark=s.Matrix([1,-1,1])
need(V*dark==s.zeros(3,1),'pi flux creates one decoupled canonical fermion combination')
D=s.diag(1,s.I,-1);B=Bs['pi_over_two'];Bnew=D*B*D.conjugate().T
need(Bnew[0,1]*Bnew[1,2]*Bnew[2,0]==B[0,1]*B[1,2]*B[2,0],'loop product invariant under independent boson phase conventions')
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'cases':results,'spacetime_gauge_field_derived':False,'phase_selection_derived':False,'scope':'Three chosen normalized pair-source vectors; full boson-source/readout response in N=2. Boson Gram equality does not imply equality of marked fermion instruments or the full Fock process.'},default=str,indent=2,sort_keys=True))
