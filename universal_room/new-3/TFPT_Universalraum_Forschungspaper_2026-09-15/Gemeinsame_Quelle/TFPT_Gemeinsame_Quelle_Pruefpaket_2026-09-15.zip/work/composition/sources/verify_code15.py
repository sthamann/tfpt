"""Optimal subcode inside the pinned native W; exact known-mode erasure tests."""
from pathlib import Path
import hashlib,itertools,json
import numpy as np
H=Path(__file__).resolve().parent;checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
p=H/'native_tensor.npz';need(hashlib.sha256(p.read_bytes()).hexdigest()=='3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763','pinned W')
raw=np.load(p)['W'];need(np.all(raw.imag==0) and np.all(raw.real==np.rint(raw.real)),'real integer W')
W=raw.real.astype(np.int64);pairs=list(itertools.combinations(range(64),2));colors=list(itertools.combinations(range(4),2))
matchings=[[(0,1),(2,3)],[(0,2),(1,3)],[(0,3),(1,2)]]
C2=np.zeros((60,15),dtype=np.int64)
for k in range(5):
 for a,matching in enumerate(matchings):
  for kk in [k,k+5]:
   for pair in matching:C2[6*kk+colors.index(pair),3*k+a]=1
need(np.array_equal(C2.T@C2,4*np.eye(15,dtype=np.int64)),'C=C2/2 is isometry')
E=W.T@C2 # physical encoder E/sqrt32
need(np.array_equal(E.T@E,32*np.eye(15,dtype=np.int64)),'physical encoder Q=E/sqrt32 is isometry')
Ds=[]
for r in range(64):
 idx=[j for j,pair in enumerate(pairs) if r in pair];notidx=[j for j,pair in enumerate(pairs) if r not in pair]
 D=W[:,idx]@W[:,idx].T;Ds.append(D)
 need(np.array_equal(D,np.diag(np.diag(D))) and np.count_nonzero(np.diag(D)==1)==15 and np.count_nonzero(np.diag(D)==0)==45,'rank15 mode compression '+str(r))
 need(np.array_equal(C2.T@D@C2,np.eye(15,dtype=np.int64)),'Knill Laflamme occupied branch '+str(r))
 # Retained two-particle sector and one-particle sector on the 63 remaining modes.
 A0=E[notidx];A1=np.zeros((64,15),dtype=np.int64)
 for j in idx:
  i,k=pairs[j];remaining=k if r==i else i;sign=1 if r==i else -1
  A1[remaining]+=sign*E[j]
 need(np.array_equal(A0.T@A0,31*np.eye(15,dtype=np.int64)),'empty erasure branch Gram '+str(r))
 need(np.array_equal(A1.T@A1,np.eye(15,dtype=np.int64)),'occupied erasure branch Gram '+str(r))
 # Each decoder returns the logical state, independently of the label and its entanglement with a reference.
 need(np.array_equal(A0.T@A0+A1.T@A1,32*np.eye(15,dtype=np.int64)),'trace-preserving recovered code channel '+str(r))
need(np.array_equal(sum(Ds),16*np.eye(60,dtype=np.int64)),'all ranks and positive total occupancy imply universal subcode upper bound 15')
col=pairs.index((0,29));v=E[col];need(np.count_nonzero(v)==1 and np.dot(v,v)==1,'two-mode erasure counterexample at modes zero and twenty-nine')
# Any unknown loss location also requires off-diagonal f_r^dagger f_s conditions; one failure suffices.
loss=[]
for r in range(64):
 A=np.zeros((64,15),dtype=np.int64)
 for j,(i,k) in enumerate(pairs):
  if i==r:A[k]+=E[j]
  if k==r:A[i]-=E[j]
 loss.append(A)
unknown=None
for r in range(64):
 for s in range(r+1,64):
  A=loss[r].T@loss[s]
  if not np.array_equal(15*A,np.trace(A)*np.eye(15,dtype=np.int64)):
   unknown=[r,s,int(np.count_nonzero(A))];break
 if unknown:break
need(unknown is not None,'unknown mode loss counterexample found')
# One Cartan already takes the selected positive combinations out of the code.
q=np.diag([1 if A//6==0 else -1 if A//6==5 else 0 for A in range(60)])
need(np.any(4*q@C2-C2@(C2.T@q@C2)),'selected subcode is not invariant under full inner group')
need(np.max(np.abs(E))<=2,'integer product bounds far below int64 overflow')
# The 15 codewords are signed perfect matchings of the native 15-regular graph.
need(set(np.unique(E))=={-1,0,1},'matching amplitudes are exactly plus or minus one')
for a in range(15):
 selected=[pairs[j] for j in np.flatnonzero(E[:,a])]
 counts=np.zeros(64,dtype=np.int64)
 for i,j in selected:counts[i]+=1;counts[j]+=1
 need(len(selected)==32 and np.all(counts==1),'perfect matching codeword '+str(a))
need(np.all(np.count_nonzero(E,axis=1)<=1) and np.count_nonzero(E)==480,'fifteen disjoint perfect matchings cover all native edges')
# Add the corresponding one-boson states: a native invariant 2 x 15 subsystem.
need(np.array_equal(W@E,8*C2),'native conversion sends encoded pair to matching boson with exact factor')
need(np.array_equal(W.T@C2,E),'native reverse conversion closes the same 30 dimensional subsystem')
need(np.array_equal(C2.T@C2,4*np.eye(15,dtype=np.int64)),'boson logical embedding normalized')
# On the normalized combined space, n_r=diag(1/32,0) tensor I15 after compression.
# Odd local operators change total N and have zero code compression.
need(all(np.array_equal(C2.T@D@C2,np.eye(15,dtype=np.int64)) for D in Ds),'operator-QEC gauge-only occupation for all modes')
np.savez(H/'optimal_code15.npz',C2=C2,encoded_integer=E)
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'code_dimension':15,'optimal_dimension_within_native_bright_code':15,'encoder':'C2/2 in logical 60 space; encoded_integer/sqrt(32) in pair space','known_mode_erasure_probabilities':['31/32','1/32'],'all_64_known_single_mode_erasures_corrected':True,'two_mode_failure':[0,29],'unknown_mode_loss_counterexample':unknown,'full_G_invariant_subcode':False,'native_invariant_subsystem_dimension':30,'protected_logical_subsystem_dimension':15,'conversion_gauge_dimension':2,'logical_subsystem_erasure_correctable_at_any_known_conversion_time':True,'physical_encoding_and_recovery_derived':False,'scope':'Known position, one erased fermion mode, encoded fixed Nf=2 state. Does not certify unknown-position loss, two erased modes, noise during conversion, or a native apparatus.'},indent=2,sort_keys=True))
