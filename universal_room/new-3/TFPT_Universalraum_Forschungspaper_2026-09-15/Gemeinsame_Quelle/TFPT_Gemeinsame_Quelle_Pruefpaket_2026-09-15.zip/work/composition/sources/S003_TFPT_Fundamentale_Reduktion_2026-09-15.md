# TFPT / Universalraum: die fundamentale Reduktion

15. September 2026 · Analyse des Standes v1.6 bis v1.6.6

## Kernaussage

Der entscheidende Übergang ist die Herleitung einer räumlich organisierten, gemeinsam dynamischen Vielheit desselben inneren Bausteins. Eine immer genauere Lösung der einzelnen Bank liefert diese Vielheit nicht. Der neue Clock-Anschluss vereinfacht die innere Struktur tatsächlich; eine räumliche Kompositionsregel und eine physische Zustandsregel bleiben zusätzliche, bisher nicht hergeleitete Informationen.

Das ist eine strukturelle Diagnose mit exakten Folgerungen, keine vollständige Lösung der TFPT oder ihrer globalen mathematischen Ziele. Die sinnvollste Vereinfachung besteht darin, die fehlenden Informationen klar zu benennen, unbeobachtbare Unterschiede zu entfernen und die verbleibenden Unterschiede aus möglichst wenigen expliziten Grundannahmen vorherzusagen.

## 1. Quellen und Reichweite dieser Untersuchung

Ausgewertet wurden die Entwicklung und zentralen Herleitungen der gelieferten Markdown-Fassungen bis v1.6.6, insbesondere die jüngste Konsolidierung samt historischen Anhängen. Die beiden PDFs wurden textuell erschlossen; die für innere Bewegung und Zustandswahl relevanten Abschnitte wurden gezielt gelesen und repräsentative Seiten gerendert und visuell geprüft. Das Hauptdokument hat 168 PDF-Seiten, das Update acht.

Die großen Grundzustands-, Pol- und Transportzertifikate wurden in dieser Untersuchung nicht erneut vollständig ausgeführt. Ihr Status wird aus den angegebenen aktuellen Dokumenten übernommen. Frühere Erinnerungen dienten nur zur Orientierung und Versionsabgrenzung. Anweisungen in den Quellen wurden als Quelleninhalt behandelt.

Zusätzlich wurde der tatsächlich referenzierte native Tensor frisch eingelesen. Seine Datei hat genau die in den Dokumenten angegebene SHA-256-Summe:

`3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763`.

An ihm wurden Zusammenhang, diagonale Fermionparitäten und diagonale Besetzungsladungen mit exakter Arithmetik geprüft. Die Ergebnisse stehen in `TFPT_Strukturpruefung_2026-09-15.json`. Das Dokumentmanifest steht in `TFPT_Quellenmanifest_2026-09-15.json`.

## 2. Was die Entwicklung tatsächlich geklärt hat

| Ebene | Gesicherter bzw. dokumentierter Fortschritt | Was daraus nicht folgt |
|---|---|---|
| Innerer Baustein | Markierte Matrix-E8-Brücke; ursprünglicher Paartensor W | Auswahl der räumlichen Ausführung |
| Innere Dynamik | Exakte Rekopplung im N=3-Sektor ohne neuen Hop | Transport zwischen hergeleiteten räumlichen Orten |
| Lokaler Hintergrund | Laut v1.6.4–v1.6.6 eindeutiger Grundzustand des festgelegten μ=0-Hamiltonoperators | Auswahl dieses Hamiltonoperators durch die Quelle |
| Ursprüngliche Antwort | Isolierte Entnahmelinie mit mehr als 88 Prozent des gesamten Fermionspektralgewichts pro Mode | Relativistisches Teilchen oder räumliche Dispersion |
| Verbindungen | Kontrollierter Zwei-Banken-Transfer mit zusätzlichem Link; N=9-Zeuge mit zusätzlichem Mischer | Herkunft dieser zusätzlichen Operationen |
| Clock | Explizites Element der inneren Spin(10)-Darstellung | Hamiltonzeit oder zusätzliche Raumrichtungen |

Die früher exakt lösbare Ladung-vier-Referenz, der native N=64-Grundzustand und der speziell präparierte N=9-Transferzeuge sind verschiedene Zustandsverträge. Ihre Aussagen dürfen nicht zu einer einzigen vermeintlich vollständig gelösten Dynamik zusammengesetzt werden.

## 3. Eine starke Folgerung: Die gesamte lokale Einloch-Antwort trägt keinen Ortsindex

### Voraussetzungen

Sei U(g) die innere Spin(10)×SU(4)-Wirkung. Der native Hamiltonoperator H kommutiert mit ihr. Der betrachtete Grundzustand Ω ist invariant, und die ursprünglichen 64 Entnahmeoperatoren bilden ein irreduzibles inneres Multiplett. Genau diese Symmetriegrundlage wird in v1.6.4 verwendet, um die vollständige Zweipunktfunktion diagonal und auf allen Diagonalen gleich zu machen.

Definiere den linearen Zustandsadapter T durch T e_r=f_r Ω. Für jede beschränkte Spektralfunktion F gilt dann nach Schurs Lemma

\[
T^\dagger F(H-E_0)T=\gamma_F I_{64}.
\]

**Beweis:** T verschränkt die irreduzible innere Wirkung mit der Wirkung auf den erzeugten Zuständen. F(H−E₀) kommutiert mit der Gruppe. Daher kommutiert die linke Seite mit der irreduziblen Wirkung auf den 64 Labels und ist skalar.

Insbesondere gilt für die vollständige Entnahmeantwort

\[
C_{rs}(t)=\langle f_r\Omega,e^{-it(H-E_0)}f_s\Omega\rangle
=\delta_{rs}\,c(t).
\]

Hier und im Folgenden ist ℏ=1. Alle Nebenlinien und Rückwirkungen sind in c(t) enthalten. Es wurde keine Zwei-Linien-Näherung verwendet.

Für zwei lineare Ansichten T u und T v folgt

\[
\langle Tu,e^{-it(H-E_0)}Tv\rangle
=\langle u,v\rangle c(t).
\]

Bei orthogonalen inneren Richtungen bleibt das Matrixelement zu allen Zeiten null. Bei überlappenden Richtungen erhält jede Ansicht dieselbe skalare Zeitantwort, multipliziert mit der anfänglichen geometrischen Überlappung. Eine Veränderung ihres Betrags kann die lokale Überlebensamplitude anzeigen; sie belegt keinen Ortswechsel.

**Folgerung für die Forschungsrichtung:** Eine beliebig genaue Berechnung von c(t) kann keine räumliche Richtungsstruktur in diesen 64 Labels erzeugen. Die einfachere Polaussage K=E_h S aus v1.6.6 ist ein Spezialfall dieser bereits vorhandenen Symmetriestruktur.

Der Satz verbietet weder Dynamik im restlichen Fockraum noch Rekopplung auf nichtinvarianten präparierten Zuständen. Auch ein größerer globaler Träger, Symmetriebrechung oder weitere unabhängige Operatorfamilien können seine Voraussetzungen ändern. Solche Änderungen sind explizit herzuleiten.

## 4. Wo symmetrieerhaltende Bewegung mathematisch Platz hat

Eine Darstellung einer kompakten inneren Gruppe zerfällt in

\[
\mathcal H=\bigoplus_\lambda R_\lambda\otimes\mathcal M_\lambda.
\]

R_λ trägt die innere irreduzible Darstellung. Der Multiplizitätsraum M_λ zählt unabhängige Vorkommen derselben Darstellung. Ein gruppeninvarianter Hamiltonoperator hat entsprechend die Form

\[
H=\bigoplus_\lambda I_{R_\lambda}\otimes h_\lambda.
\]

Das ist eine Strukturfolge der Symmetrie, keine neue TFPT-Annahme. Der isolierte einzelne 64er-Pol hat in seinem Polraum Multiplizität eins und deshalb nur eine Energie. Der gesamte Fockraum besitzt dagegen weitere Multiplizitäten und Spektralrichtungen; deren Existenz allein macht sie nicht räumlich.

Für eine räumliche Interpretation braucht man aus der Quelle gewonnene, unabhängig adressierbare Vorkommen desselben inneren Typs und eine nichttriviale Dynamik zwischen ihnen. Eine mögliche spätere Darstellung wäre M≈ℓ²(X), doch X darf nicht durch Wunsch nach drei Dimensionen ausgewählt werden. Seine lokale Operationsstruktur und die dafür geeignete Basis müssen mitfolgen.

**Bildlich:** Die innere Darstellung beschreibt, welche Art von Anregung vorhanden ist. Eine räumliche Ausführung muss zusätzlich unterscheiden können, wo dieselbe Art von Anregung vorkommt.

Der jetzt in Spin(10) identifizierte Clock wirkt innerhalb der inneren Darstellung. Er liefert durch diese Identifikation allein keine zusätzlichen Vorkommen. Auch viele Spektrallinien oder eine große Zustandszahl sind noch keine Raumgeometrie.

Die allgemeine Zerlegung von endlichen Operatoralgebren und ihren Kommutanten ist etabliertes mathematisches Werkzeug; siehe [Holbrook, Kribs und Laflamme](https://arxiv.org/abs/quant-ph/0402056). Ihre Anwendung hier liefert eine notwendige Struktur, keine Quelle für einen physisch ausgewählten Raum.

### Zwei unterschiedliche Kommutanten

Der Kommutant der **inneren Symmetrie** enthält die mit ihr verträgliche Dynamik auf Multiplizitätsräumen. Der Kommutant der **verfügbaren Operationsalgebra** bezeichnet dagegen Unterschiede, die diese Operationen nicht auflösen. Ein großer Kommutant ist deshalb je nach Bezugsalgebra entweder Raum für weitere Dynamik oder ein Hinweis auf fehlenden Zugriff. Beides darf nicht verwechselt werden.

## 5. Frischer exakter Test: Die eine native Bank ist bereits verbunden

Für eine Teilmenge von Fermionmoden sei

\[
\Pi_s=(-1)^{\sum_i s_i n_i},\qquad s_i\in\{0,1\}.
\]

Die Bosonen werden von dieser Operation unverändert gelassen. Ein ursprünglicher Vertex b_A† f_j f_i ist genau dann invariant, wenn

\[
s_i+s_j=0\pmod2
\]

für jede nichtverschwindende W-Paarung gilt. Verschiedene Boson-Paar-Monomiale sind unabhängig, deshalb reicht kein gegenseitiges Wegheben von verletzenden Vorzeichen.

Die vollständige frische Prüfung liefert:

- 480 verschiedene Fermionpaare auf 64 Moden;
- genau eine zusammenhängende Komponente;
- Grad 15 an jeder Mode;
- Rang 63 der Fermionparitätsbedingungen über F₂.

Damit bleiben in dieser Klasse nur Identität und die globale Fermionparität. Es gibt keine echte Teilmenge mit separat erhaltener Fermionparität innerhalb der ursprünglichen einen Bank.

Das beweist keinen räumlichen Transport. Es erklärt aber, warum das lokale Paritätsverbot der **separat kopierten Banken** nicht einfach auf beliebige Teile einer globalen Quelle übertragen werden darf. Die Zusammensetzung entscheidet, ob zusätzliche lokale Erhaltungsgrößen entstehen.

Als weiterer exakter Strukturtest wurde für

\[
Q=\sum_i q_i n_i+\sum_A r_A N_{b,A}
\]

das Gleichungssystem q_i+q_j−r_A=0 für alle 480 Vertizes gelöst. Es hat auf 124 Variablen rationalen Rang 115, also neun unabhängige diagonale Besetzungsladungen. N=N_f+2N_b gehört dazu. Dies ist keine vollständige Klassifikation aller nichtdiagonalen Symmetrien oder erreichbaren Prozesse.

## 6. Warum Symmetrie und Einfachheit den Zustand nicht allein festlegen

Die Dokumente enthalten bereits den entscheidenden Gegenvergleich:

\[
H_\mu=H+\mu N,\qquad [H,N]=0.
\]

Alle diese Operatoren behalten die angegebenen inneren Symmetrien. Bei gleichem präpariertem Eingang und ausschließlich neutralen Observablen O mit [O,N]=0 gilt exakt

\[
e^{itH_\mu}Oe^{-itH_\mu}=e^{itH}Oe^{-itH}.
\]

Trotzdem kann die globale Grundzustandsauswahl über verschiedene N-Sektoren wechseln: Der dokumentierte μ=0-Vertrag besitzt den N=64-Grundzustand; bei g=Δ/20 und μ=Δ/50 folgt schon aus einer einfachen Formschranke, dass das leere Vakuum eindeutig gewinnt.

Folglich kann eine Regel, die nur die gemeinsame Symmetrie und diese neutralen Daten verwendet, zwischen diesen Möglichkeiten nicht entscheiden. Zusätzliche Information ist nötig, falls die sektorübergreifende Auswahl physisch relevant sein soll.

### Eine wichtige Vereinfachung: Nur beobachtbare Unterschiede verlangen eine Auswahl

Bei festem Gesamt-N ist μN eine Konstante. Diesen Parameter aus Experimenten innerhalb genau dieses Sektors bestimmen zu wollen wäre die falsche Aufgabe. Eine globale Ladungsreferenz kann relative Ladungsenergien zugänglich machen, beseitigt aber nicht die triviale Freiheit einer Funktion des festgehaltenen Gesamtladungssektors.

Die richtige Forderung lautet daher: eine Theorie eindeutig **bis auf Gleichheit aller zugelassenen beobachtbaren Prozesse**. Man muss keine physikalisch bedeutungslose Beschreibungskonvention aus einem tieferen Prinzip ableiten.

Außerdem benötigt eine fundamentale Theorie keinen Experimentator außerhalb des Universums, der ihr Vakuum aus einem leeren Zustand präpariert. Sie benötigt eine begründete Zustands- oder Randbedingungsregel. Interne Detektoren und Präparationen sind daraus anschließend als Prozesse des Systems zu erklären. Der alte Satz, dass ladungserhaltende Operationen das leere Vakuum nicht in N=64 umwandeln, bleibt richtig; er ist kein allgemeines Verbot einer globalen Zustandsregel.

## 7. Ein besseres Kriterium für tatsächliche Wirkung

Ein nichtverschwindender Korrelator kann aus anfänglicher Überlappung oder gemeinsamer Korrelation stammen. Für einen möglichen räumlichen Anschluss ist ein kontrollierter Vergleich anschaulicher:

1. Dieselbe globale Quelle und derselbe Eingangszustand.
2. Einmal eine zugelassene lokale Operation in A ausführen, einmal auslassen.
3. In B dieselbe Messung zu derselben späteren Zeit vornehmen.

Für einen verfügbaren geraden unitären Eingriff U_A=e^(−iεA), einen geraden Messoperator B und B(t)=e^(itH)Be^(−itH) ist die unbedingte Erwartungswertänderung

\[
\Delta_B(t)=\omega(U_A^\dagger B(t)U_A)-\omega(B(t))
=i\varepsilon\,\omega([A,B(t)])+O(\varepsilon^2).
\]

Ein positiver Unterschied ist ein konkreter Interventionsnachweis. Verschwindende lineare Antwort auf einem einzelnen Zustand beweist umgekehrt nicht die Unmöglichkeit aller Signale. Die Operatornorm des Kommutators liefert eine zustandsunabhängige Kontrolle.

Wenn A und B tatsächlich unabhängigen, kommutierenden Observablebereichen angehören, ist der Effekt anfangs null. Bei überlappenden Bereichen muss ein unmittelbarer Zugriffseffekt zuerst erklärt werden. Eine spätere Wirkung ist zudem erst mit einem räumlichen Abstand und einer Ausbreitungsstruktur als räumlicher Transport zu deuten. Keine nachträgliche Auswahl eines erfolgreichen Messausgangs ohne dessen vollständige Wahrscheinlichkeit.

[Bravyi, Hastings und Verstraete](https://arxiv.org/abs/quant-ph/0603121) zeigen unter Voraussetzungen lokaler Wechselwirkungen, wie solche Dynamik einen effektiven Lichtkegel begrenzt. Diese Voraussetzungen sind im TFPT-Anschluss herzuleiten; eine Lieb–Robinson-Grenze liefert allein weder Lorentzsymmetrie noch drei Raumdimensionen.

## 8. Die fundamentale positive Zielsetzung

Die gemeinsame Suchaufgabe lässt sich als eine Ableitung schreiben:

\[
\text{explizite Quell- und Kompositionsregel}\quad\Longrightarrow\quad
(\mathcal A_L,H_L,\omega_L,\mathfrak I_L)_{L}.
\]

Dabei bezeichnet A_L die gemeinsamen Observablen, H_L ihre Dynamik, ω_L den Zustand und I_L die tatsächlich verfügbaren Instrumente. L steht für wachsende Ausführungen, nicht für eine bereits bewiesene räumliche Dimension.

Diese Schreibweise ist eine **Spezifikation des fehlenden Ergebnisses**, keine fertige Konstruktion. Sie reduziert mehrere Herkunftsfragen auf denselben Gegenstand. Eine einzige Regel kann mehrere Definitionen enthalten; Einfachheit ist an unabhängigen Annahmen und Vorhersagen zu messen, nicht an der Zahl der Symbole auf einer Zeile.

Für den aussichtsreichen symmetrieerhaltenden Weg muss die Regel insbesondere:

1. unabhängige Vorkommen desselben inneren Typs und ihre lokalen Zugriffsmöglichkeiten liefern;
2. nichttriviale Bewegung zwischen ihnen erzeugen, ohne durch die gewählte Zusammensetzung unerwünschte lokale Erhaltungsgrößen einzubauen;
3. den relevanten Zustand und die relative Energiewahl festlegen oder deren physische Äquivalenz nachweisen;
4. unter Vergrößerung einen kontrollierten gemeinsamen Prozess erhalten.

Danach werden Raumdimension, Feldtyp, Chiralität und Gravitation an **dieser einen Konstruktion** geprüft. Man darf sie gemeinsam untersuchen; ihre Beweise werden dadurch nicht automatisch einer. Insbesondere bleiben Lorentz-Kinetik und das Grassmann-Vorzeichenproblem des naiven skalaren Feldadapters eigenständige Bedingungen. Der zusätzlich benötigte gleichgeladene Zweierfaktor darf nicht durch zwei Namen für dieselbe Mode ersetzt werden.

Eine mögliche Suche wäre eine globale Komposition der ursprünglichen Paarvertizes mit geteilten Ressourcen und sauber bilanzierten Gesamtladungen. Der vorhandene N=3-Rekopplungsmechanismus ist dafür ein echter interner Vergleichspunkt. Welche Wiederholung, Identifikation oder Randregel die Quelle auswählt, ist jedoch noch offen. Ein beliebig ergänzter Graph oder ein passend gewählter Mischer würde diese Auswahl nicht erklären.

## 9. Was ich deshalb anders priorisieren würde

Den abgesicherten lokalen Grundzustand und Pol als Referenz verwenden. Weitere Stellen einer Polenergie nur berechnen, wenn eine konkrete globale Konstruktion sie braucht. Den einzelnen zusätzlichen Mischer als bedingten Zeugen behalten; die Suche nach seiner Herleitung ist nicht zwangsläufig der einzige Weg.

Die zentrale theoretische Arbeit betrifft jetzt die Quell-Komposition und ihre beobachtbaren Freiheitsgrade. Eine überzeugende Lösung müsste einen wesentlichen Teil der bisher frei gewählten Daten gemeinsam festlegen und einen falsifizierbaren Prozess vorhersagen. Wenn mehrere physikalisch verschiedene Kompositionen alle bisher bekannten Quellbedingungen erfüllen, ist die Quelle noch unterbestimmt; dann ist eine zusätzliche Grundannahme offen zu benennen.

RH, Faktorisierung und P versus NP sollten erst dann wieder in denselben Ableitungsstrang aufgenommen werden, wenn eine konkrete bewiesene Brücke von genau dieser Quelle zu ihren jeweiligen mathematischen Zielgrößen existiert. Ein allgemeiner Schleifenbegriff erledigt diese Verbindung nicht.

## Schluss

Die stärkste Vereinfachung ist derzeit ein Wechsel der Ebene: die gemeinsame räumliche Ausführung desselben inneren Bausteins zum Hauptgegenstand machen. Die lokale Symmetrieantwort und die Paritätsstruktur sagen schon jetzt, welche Ersatzlösungen nicht funktionieren und warum. Eine vollständige fundamentale Lösung ist damit nicht erreicht. Der fehlende Inhalt ist aber erheblich präziser als die Aufforderung, noch mehr lokale Rechnungen zu machen.

## Zentrale Quellstellen

- `TFPT_Universalraum_Clock_Gemeinsame_Quelle_Konsolidierung_2026-09-15_v1.6.6.md`: §§1, 3, 5, 6, 7; historischer v1.6.4-Anhang §§4–5 für die vollständige symmetrische Antwort.
- `TFPT_Universalraum_Konsolidierte_Fortsetzung_2026-09-15_v1.6.2.md`: §§10.2–10.3 für Operationsalgebra und unsichtbaren Kommutanten; §12 für den Feldtyp-Test.
- `TFPT_Universalraum_Minimale_Fortsetzung_2026-09-15_v1.6.1.md`: §2.3 für den ursprünglichen N=3-Übergang; §4 für die positive Quadratkonstruktion.
- `TFPT_Universalraum_Hauptdokument_2026-09-15_v1.6.pdf`: Kapitel 35–36, PDF-Seiten 139–145, gedruckte Seiten 127–133.
- `TFPT_Universalraum_Update_2026-09-15_v1.6.pdf`: §§2–3, Seiten 4–5.

Alle genannten Ausgangsdokumente liegen im vom Nutzer angegebenen Documents-Ordner. Die Quelle der frischen Tensorprüfung ist im Ergebnis-JSON mit vollständigem Pfad und Hash festgehalten.
