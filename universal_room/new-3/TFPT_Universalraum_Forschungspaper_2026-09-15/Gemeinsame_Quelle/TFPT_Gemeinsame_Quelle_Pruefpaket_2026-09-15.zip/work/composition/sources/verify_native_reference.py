"""Independent native N=3 component replay and full Lie covariance at pinned W."""
from pathlib import Path
from itertools import combinations
from collections import deque,defaultdict
import numpy as np,sympy as s,json
from scipy.sparse import csr_matrix,coo_matrix
H=Path(__file__).resolve().parent;checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
raw=np.load(H/'native_tensor.npz')['W'];need(np.all(raw.imag==0) and np.all(raw.real==np.rint(raw.real)),'real integer W');W=raw.real.astype(np.int64);Ws=csr_matrix(W)
pairs=list(combinations(range(64),2));pi={p:i for i,p in enumerate(pairs)}
channels=[[(int(i),int(j),int(row[c])) for c,(i,j) in enumerate(pairs) if row[c]] for row in W]
by_pair={p:[(a,int(W[a,c])) for a in np.flatnonzero(W[:,c])] for c,p in enumerate(pairs)}
def sign(mask,i):return -1 if (mask&((1<<i)-1)).bit_count()%2 else 1
def edges(state):
 tag,m,A=state;out=defaultdict(int)
 if tag=='b':
  for i,j,w in channels[A]:
   if m&((1<<i)|(1<<j)):continue
   n=m|(1<<i)|(1<<j);out['f',n,-1]+=w*sign(m,j)*sign(m|(1<<j),i)
 else:
  occupied=[i for i in range(64) if (m>>i)&1]
  for i,j in combinations(occupied,2):
   sg=sign(m,i)*sign(m^(1<<i),j)
   for a,w in by_pair[i,j]:out['b',m^(1<<i)^(1<<j),a]+=w*sg
 return {k:v for k,v in out.items() if v}
start=('b',1<<4,36);target=('b',1,0);todo=deque([start]);seen={start};links={}
while todo:
 a=todo.popleft();links[a]=edges(a)
 for b in links[a]:
  if b not in seen:seen.add(b);todo.append(b)
basis=sorted(seen);idx={x:i for i,x in enumerate(basis)};X=np.zeros((len(basis),len(basis)),dtype=np.int64)
for a,d in links.items():
 for b,v in d.items():X[idx[b],idx[a]]=v
need(len(basis)==35 and target in seen,'native connected component has 35 states and specified endpoint')
need(np.array_equal(X,X.T),'native CAR/CCR Hamiltonian Hermitian')
bf=[i for i,b in enumerate(basis) if b[0]=='b'];ff=[i for i,b in enumerate(basis) if b[0]=='f'];C=X[np.ix_(bf,ff)];S=s.Matrix(C@C.T)
need(len(bf)==5 and len(ff)==30,'five boson-fermion and thirty triple-fermion states')
need(S.charpoly().as_expr().factor()==(s.Symbol('lambda')-12)*(s.Symbol('lambda')-7)**4,'exact S spectrum 7 fourfold and 12 once')
need((S-7*s.eye(5)).rank()==1,'rank-one mixing beyond scalar')
need(int((X@X)[idx[target],idx[start]])==-1,'second-order native transition sign')
# Eight charge labels from the original Spin/color weights.
even=[m for m in range(32) if m.bit_count()%2==0]
cw=[tuple(1-2*(m>>j&1) for j in range(3)) for m in range(8) if m.bit_count()%2==0]
fw=np.array([tuple(1-2*(m>>j&1) for j in range(5))+c for m in even for c in cw],dtype=np.int64)
bw=np.array([fw[pairs[int(np.flatnonzero(W[a])[0])][0]]+fw[pairs[int(np.flatnonzero(W[a])[0])][1]] for a in range(60)])
qs=[]
for tag,m,a in basis:
 q=sum((fw[i] for i in range(64) if (m>>i)&1),start=np.zeros(8,dtype=np.int64))
 if tag=='b':q=q+bw[a]
 qs.append(q)
need(all(np.array_equal(q,qs[0]) for q in qs),'all eight Cartan charges conserved on every native path')
# Construct all 60 Lie generators; strip a common factor i to use integer arithmetic only.
ann=[]
for j in range(5):
 a=np.zeros((32,32),dtype=np.int64)
 for m in range(32):
  if (m>>j)&1:a[m^(1<<j),m]=sign(m,j)
 ann.append(a)
gamma=[a+a.T for a in ann]+[1j*(a.T-a) for a in ann]
gens=[np.kron((gamma[i]@gamma[j])[np.ix_(even,even)],np.eye(4,dtype=np.int64)) for i,j in combinations(range(10),2)]
for i,j in combinations(range(4),2):
 a=np.zeros((4,4),dtype=np.int64);a[i,j]=1;a[j,i]=-1;gens.append(np.kron(np.eye(16,dtype=np.int64),a))
 a=np.zeros((4,4),dtype=np.int64);a[i,j]=a[j,i]=1;gens.append(np.kron(np.eye(16,dtype=np.int64),a))
for i in range(3):
 a=np.zeros((4,4),dtype=np.int64);a[i,i]=1;a[i+1,i+1]=-1;gens.append(np.kron(np.eye(16,dtype=np.int64),a))
need(len(gens)==60,'45 plus 15 generators')
for n,T in enumerate(gens):
 if np.any(T.imag) and np.any(T.real):raise RuntimeError('not a pure integer or imaginary generator')
 T=(T.imag if np.any(T.imag) else T.real).astype(np.int64);rr=[];cc=[];vv=[]
 support=[[(int(r),int(T[r,i])) for r in np.flatnonzero(T[:,i])] for i in range(64)]
 for col,(i,j) in enumerate(pairs):
  for k,a in support[i]:
   if k!=j:rr.append(pi[tuple(sorted((k,j)))]);cc.append(col);vv.append(a*(1 if k<j else -1))
  for k,a in support[j]:
   if k!=i:rr.append(pi[tuple(sorted((i,k)))]);cc.append(col);vv.append(a*(1 if i<k else -1))
 L=coo_matrix((vv,(rr,cc)),shape=(2016,2016),dtype=np.int64).tocsr();B8=Ws@L@Ws.T;defect=B8@Ws-8*Ws@L;defect.eliminate_zeros()
 need(defect.nnz==0,'full integer Lie covariance '+str(n))
need(64*2016*60*8*8<2**63,'sparse covariance arithmetic safely bounded')
np.savez(H/'native_reference_component.npz',X=X,Nb=np.diag([int(b[0]=='b') for b in basis]),start=idx[start],target=idx[target])
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'dimension':35,'boson_fermion_dimension':5,'triple_fermion_dimension':30,'start':'b36 f4','target':'b0 f0','full_Lie_generators_verified':60,'all_Cartan_charges':list(map(int,qs[0])),'H_squared_target_source_over_g_squared':-1,'amplitude_leading_coefficient':'g^2 t^2 /2','source_status':'independent replay of an existing result, not a new transition discovery','state_preparation_derived':False,'mode_resolved_readout_derived':False,'spatial_interpretation_derived':False},indent=2,sort_keys=True))
