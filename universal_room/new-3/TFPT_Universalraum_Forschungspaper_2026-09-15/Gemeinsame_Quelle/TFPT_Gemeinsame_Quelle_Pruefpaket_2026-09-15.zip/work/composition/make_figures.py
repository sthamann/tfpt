from pathlib import Path
import numpy as np,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent;out=H.parent.parent/'outputs/komposition/figures';out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
ink='#17344a';blue='#20768a';orange='#ad5b25'
def save(fig,n):
 fig.savefig(out/(n+'.pdf'),bbox_inches='tight');fig.savefig(out/(n+'.png'),dpi=180,bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(7,4.6));ax.set_aspect('equal');ax.axis('off');coords=np.array([[-1,0],[0,1.4],[1,0]])
for e,(i,j) in enumerate([(0,1),(1,2),(0,2)]):
 a,b=coords[i],coords[j];mid=(a+b)/2;ax.plot([a[0],b[0]],[a[1],b[1]],color=blue,lw=2)
 ax.scatter(*mid,s=1000,marker='s',color='#e8f3f3',edgecolor=blue,zorder=4);ax.text(*mid,'B'+str(e),ha='center',va='center',color=ink,zorder=5)
for i,(x,y) in enumerate(coords):
 ax.scatter(x,y,s=1500,color=ink,zorder=5);ax.text(x,y,'F'+str(i),ha='center',va='center',color='white',zorder=6)
ax.text(0,-.45,'F: 64 kanonische Fermionmoden pro Knoten',ha='center',color=ink)
ax.text(0,-.66,'B: 60 unabhängige Bosonmoden pro Verbindung',ha='center',color=ink)
ax.text(0,1.92,'Gesetzte Kompositionsregel: q = (F links + F rechts) / √2',ha='center',color=ink)
ax.set_xlim(-1.7,1.7);ax.set_ylim(-.8,2.05);save(fig,'quellregel')
g=.05;t=np.linspace(0,6,361)
def f(lam,t):
 omega=np.sqrt(1+4*g*g*lam);return np.exp(-1j*t/2)*(np.cos(omega*t/2)-1j/omega*np.sin(omega*t/2))
f6=f(6,t);f12=f(12,t);p0=np.abs(f12)**2/3;p1=np.abs(f12+2*f6)**2/27;delta=(p1-p0)*100
r=json.loads((H/'intervention_normal.json').read_text());cal=(abs(f(12,1)+2*f(6,1))**2/27-abs(f(12,1))**2/3)
if abs(cal-r['unconditional_difference_numeric'])>1e-14:raise RuntimeError('independent eigenchannel formula disagrees with rational Taylor evaluation')
fig,axs=plt.subplots(2,1,figsize=(7,5.5),sharex=True,layout='constrained')
axs[0].plot(t,p0,color=blue,label='ohne Eingriff');axs[0].plot(t,p1,color=orange,label='mit Phaseneingriff in B0');axs[0].set_ylabel('Wahrscheinlichkeit in B1');axs[0].legend(frameon=False);axs[0].set_title('Gemeinsame Quelle: unbedingte Wirkung',loc='left',fontweight='bold')
axs[1].plot(t,delta,color=blue);axs[1].scatter([1],[100*cal],color=orange,zorder=4);axs[1].annotate('zertifiziert: +0,301421 Prozentpunkte',(1,100*cal),xytext=(1.3,.45),textcoords='data',arrowprops={'arrowstyle':'-','color':ink},fontsize=9,color=ink);axs[1].set_ylabel('Differenz / Prozentpunkte');axs[1].set_xlabel('Zeit tΔ');
for ax in axs:ax.grid(axis='y',alpha=.18)
save(fig,'wirkung')
r=json.loads((H/'growth_normal.json').read_text())['countermodels'];fig,axs=plt.subplots(1,2,figsize=(7,3.8),layout='constrained')
for ax,name,title,outer,inner in [(axs[0],'Petersen','Petersen',[0,7,3,4,9],[8,6,5,2,1]),(axs[1],'Pentagonal_prism','Fünfeckiges Prisma',list(range(5)),list(range(5,10)))]:
 pts={}
 for ids,rad in [(outer,1),(inner,.48)]:
  for k,i in enumerate(ids):a=np.pi/2+2*np.pi*k/5;pts[i]=(rad*np.cos(a),rad*np.sin(a))
 for i,j in r[name]['edges']:
  a,b=pts[i],pts[j];ax.plot([a[0],b[0]],[a[1],b[1]],color=blue,lw=1.5,zorder=1)
 for i,(x,y) in pts.items():ax.scatter(x,y,s=130,color=ink,zorder=3)
 ax.set_aspect('equal');ax.axis('off');ax.set_title(title,loc='center',fontweight='bold');ax.text(0,-1.28,'10 Knoten · 15 Verbindungen · Grad 3',ha='center',fontsize=9,color=ink);ax.text(0,-1.5,'Spur B⁴ = '+str(r[name]['moments_B_1_4'][3]),ha='center',color=ink);ax.set_ylim(-1.68,1.15)
save(fig,'gegenmodelle')
