from pathlib import Path
import subprocess,pypandoc,shutil
H=Path(__file__).resolve().parent;root=H.parent.parent;out=root/'outputs/komposition';build=H/'build';build.mkdir(exist_ok=True)
name='TFPT_Gemeinsame_Quelle_2026-09-15'
header=(root/'work/paper_header.tex').read_text().replace('Synthese 1.0 · Quellen bis v1.6.7 einschließlich Nachtrag','Fortsetzung 1.2 · Gemeinsame Quelle und Größenfolge')
header += '\n'+r'\usepackage{needspace}'+'\n'
(build/'header.tex').write_text(header)
args=[pypandoc.get_pandoc_path(),str(out/(name+'.md')),'--standalone','--from=markdown+tex_math_dollars','--to=latex','--table-of-contents','--toc-depth=2','--resource-path='+str(out),'-V','documentclass=article','-V','fontsize=11pt','-V','papersize=a4','-V','geometry:margin=23mm','-V','colorlinks=true','-V','link-citations=true','--include-in-header='+str(build/'header.tex'),'-o',str(build/(name+'.tex'))]
subprocess.run(args,check=True,cwd=out)
xelatex=shutil.which('xelatex') or '/Library/TeX/texbin/xelatex'
for _ in range(3):
 p=subprocess.run([xelatex,'-interaction=nonstopmode','-halt-on-error','-output-directory='+str(build),str(build/(name+'.tex'))],cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (build/'console.txt').write_text(p.stdout)
 if p.returncode:print(p.stdout[-6000:]);raise SystemExit(p.returncode)
shutil.copy2(build/(name+'.pdf'),out/(name+'.pdf'))
print('Built',out/(name+'.pdf'))
