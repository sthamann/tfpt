"""Exact native-W shared-source composition and operator-QEC checks.
The graph/averaging rule is an explicit extra hypothesis, not derived TFPT data.
"""
from pathlib import Path
from itertools import combinations
import hashlib,json
import numpy as np
import sympy as s
from scipy.sparse import coo_matrix,csr_matrix,kron,eye,save_npz
H=Path(__file__).resolve().parent;checks=[]
def need(ok,label):
 if not ok:raise RuntimeError(label)
 checks.append(label)
def eq(A,B):
 C=A-B;C.eliminate_zeros();return C.nnz==0
p=H/'native_tensor.npz';need(hashlib.sha256(p.read_bytes()).hexdigest()=='3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763','pinned original W')
raw=np.load(p)['W'];need(np.all(raw.imag==0) and np.all(raw.real==np.rint(raw.real)),'original integer tensor')
W=raw.real.astype(np.int64);C2=np.load(H/'optimal_code15.npz')['C2'];need(np.array_equal(C2.T@C2,4*np.eye(15,dtype=int)),'original logical isometry')
# Three vertices and all three unoriented edges. q_e=(f_x+f_y)/sqrt2.
edges=[(0,1),(1,2),(0,2)];v=np.array([[int(x in edge) for x in range(3)] for edge in edges],dtype=np.int64);dots=v@v.T
pairs=list(combinations(range(64),2));globalpairs=list(combinations(range(192),2));index={p:i for i,p in enumerate(globalpairs)}
rr=[];cc=[];dd=[]
for e,edge in enumerate(edges):
 for A,c in zip(*np.nonzero(W)):
  i,j=pairs[c]
  for x in edge:
   for y in edge:
    a,b=64*x+i,64*y+j;sign=1 if a<b else -1
    rr.append(60*e+int(A));cc.append(index[tuple(sorted((a,b)))]);dd.append(sign*int(W[A,c]))
W2=coo_matrix((dd,(rr,cc)),shape=(180,len(globalpairs)),dtype=np.int64).tocsr();W2.sum_duplicates()
# W2/2 is the actual lifted coefficient matrix in global canonical pair order.
need(eq(W2@W2.T,kron(csr_matrix(8*dots*dots),eye(60,dtype=np.int64),format='csr')),'all 180 channels obey derived squared-overlap Gram')
need(W2.nnz==5760 and set(W2.data)=={-1,1},'5760 signed lifted vertices; coefficients plus-minus one half')
enc=kron(eye(3,dtype=np.int64),csr_matrix(C2),format='csr');E=W2.T@enc
need(eq(E.T@E,kron(csr_matrix(32*dots*dots),eye(15,dtype=np.int64),format='csr')),'full 45-dimensional pair-code Gram')
need(eq(W2@E,kron(csr_matrix(8*dots*dots),eye(60,dtype=np.int64),format='csr')@enc),'native Hamiltonian closes the same logical factor')
need(eq(W2.T@enc,E),'reverse conversion closes the pair-boson subsystem')
for r in range(192):
 idx=[i for i,pair in enumerate(globalpairs) if r in pair];F=E[idx,:]
 x=r//64;K=np.outer(v[:,x],v[:,x])*dots
 target=kron(csr_matrix(K),eye(15,dtype=np.int64),format='csr')
 need(eq(F.T@F,target),'known-mode erasure gauge-only Gram '+str(r))
 ar=[];ac=[];ad=[]
 for j in idx:
  i,k=globalpairs[j];remaining=k if i==r else i;sign=1 if i==r else -1
  row=E.getrow(j)
  for c,d in zip(row.indices,row.data):ar.append(remaining);ac.append(c);ad.append(sign*int(d))
 A=coo_matrix((ad,(ar,ac)),shape=(192,45),dtype=np.int64).tocsr()
 need(eq(A.T@A,target),'CAR signed loss branch '+str(r))
need(np.max(np.abs(E.data))==1,'all encoded amplitudes are integer signs over sqrt128')
# Pure coordinate-mode parities; each occupied interaction edge enforces equal signs.
piv={}
for c in np.unique(W2.indices):
 i,j=globalpairs[c];b=(1<<i)|(1<<j)
 while b:
  k=b.bit_length()-1
  if k not in piv:piv[k]=b;break
  b^=piv[k]
need(len(piv)==191,'only global coordinate-fermion parity on the triangle')
# Essential negative: connected support is not a full symmetry classification.
vp=s.Matrix([[1,1,0],[0,1,1]]);dark=s.Matrix([1,-1,1]);need(vp*dark==s.zeros(2,1),'two-edge path has a hidden entire dark fermion bank')
need(s.Matrix(v.tolist()).det()!=0,'triangle removes that unused copy direction')
# Rank-one pair tensors transform by congruence. Orthogonal modal resolution would require orthogonal or parallel vectors.
need(all(dots[e,f]==1 for e in range(3) for f in range(e+1,3)),'distinct source modes overlap and cannot be independent canonical banks')
need(s.Matrix(dots.tolist()).rank()==3,'three source vectors span the full three-copy space')
# Every unitary fermion involution preserving each fixed rank-one boson channel maps q_e to +/-q_e;
# nonzero overlaps force equal signs, and spanning makes it +/-I.
need(all(dots[e,f]!=0 for e in range(3) for f in range(3)),'overlap graph forces one sign for all fixed-channel fermion involutions')
G=s.Matrix((dots*dots).tolist())/4;B=8*G
need(B==s.Matrix([[8,2,2],[2,8,2],[2,2,8]]),'minimal triangle boson backreaction')
need(B.eigenvals()=={s.Integer(12):1,s.Integer(6):2},'exact triangle backreaction spectrum')
need(G.det()>0,'pair-coordinate Gram positive and nonsingular')
save_npz(H/'shared_W2.npz',W2);save_npz(H/'shared_code_integer.npz',E)
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'original_tensor_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fermion_copies':3,'fermion_modes':192,'boson_copies':3,'boson_modes':180,'lifted_tensor_denominator':2,'lifted_tensor_nonzeros':W2.nnz,'logical_dimension':15,'composition_gauge_dimension':6,'native_invariant_subsystem_dimension':90,'pair_code_Gram_integer':(32*dots*dots).tolist(),'backreaction_B':B.tolist(),'known_mode_erasures_verified':192,'single_total_charge_two_only':True,'code_selection_full_inner_symmetry_invariant':False,'physical_encoder_decoder_derived':False,'composition_rule_derived_from_TFPT':False,'large_ground_theorem_transferred':False,'hidden_path_mode':[1,-1,1],'T1_T8_closed':[]},default=str,indent=2,sort_keys=True))
