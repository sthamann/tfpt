"""Reproduce all exact results in a disposable extracted package copy."""
from pathlib import Path
import sys,subprocess,json,hashlib
H=Path(__file__).resolve().parent;R=H/'replay';R.mkdir(exist_ok=True)
for x in json.loads((H/'inputs_manifest.json').read_text()):
 p=H/x['path']
 if hashlib.sha256(p.read_bytes()).hexdigest()!=x['sha256']:raise RuntimeError('input mismatch '+x['path'])
count=0;reports={}
for script,prefix in [('verify_shared_source.py','shared'),('verify_intervention.py','intervention'),('verify_growth.py','growth'),('verify_phases.py','phases')]:
 baseline=(H/(prefix+'_normal.json')).read_bytes()
 for mode,flags in [('normal',[]),('optimized',['-OO'])]:
  print(prefix+' '+mode,flush=True)
  p=subprocess.run([sys.executable,*flags,str(H/script)],cwd=H,capture_output=True)
  (R/(prefix+'_'+mode+'.json')).write_bytes(p.stdout)
  (R/(prefix+'_'+mode+'.stderr')).write_bytes(p.stderr)
  if p.returncode:sys.stderr.buffer.write(p.stderr);raise RuntimeError('failed '+script)
  if p.stdout!=baseline:raise RuntimeError('result mismatch '+prefix+' '+mode)
 r=json.loads(baseline)
 if r['status']!='PASS':raise RuntimeError('nonPASS '+prefix)
 count+=r['exact_checks'];reports[prefix]=r['exact_checks']
report={'status':'PASS','conditions':count,'per_checker':reports,'normal_and_optimized_match_pinned_results':True,'full_source_to_internal_record_chain_closed':False,'full_Fock_ground_replayed':False,'T1_T8_closed':[]}
(R/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
