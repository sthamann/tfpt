# TFPT / Universalraum v1.4 — die sechs nächsten Entscheidungen

14. September 2026. Begleiter zum vollständigen Hauptdokument und zum kurzen Update.

## Das Gesamtbild

Wir haben jetzt ein berechenbares kleines Labor. Es kann einen Zustand herstellen,
eine Aufzeichnung machen und später testen, was diese Aufzeichnung verändert hat.
Neu sind nicht nur Formeln für einzelne Teile, sondern ein gemeinsamer Ablauf mit
vollständigen Erfolgswahrscheinlichkeiten. Uns fehlt weiterhin der Nachweis, dass
die ursprüngliche TFPT-Regel selbst dieses Labor und seine Bedienmöglichkeiten
erzeugt. Eine wachsende Anordnung solcher Labore ist außerdem noch keine
bewiesene Raumzeit mit Materie und Gravitation.

## 1. Wer bedient das Labor? — höchste Priorität

**Schon erreicht:** Ein vollständiger mikroskopischer Filter plus Aufzeichnung und
Endprüfung. Präparation gelingt pro Versuch mit etwa 16,19 %. Die gesamten
Erfolgsraten sind etwa 15,73 % mit behaltenem und 8,36 % mit frischem Record.
Der Unterschied entsteht in demselben deklarierten kontrollierten Modell.

**Offen:** Kontrollierte Zeitentwicklung, isolierte Kanten, Resonanz, Belegungsabfrage,
Messung und Reset sind noch Bedienmöglichkeiten, nicht alle aus dem Compiler abgeleitet.

**Entscheidender Test:** Eine Liste primitiver Operationen einfrieren und für jeden
dieser Handgriffe eine explizite Umsetzung samt Kosten angeben. Kein zusätzlich
eingeführter Zielzustandsprojektor darf die eigentliche Aufgabe verstecken.

## 2. Welche Bauweise ist wirklich vorgeschrieben?

**Schon erreicht:** Drei Architekturen sauber getrennt: gemeinsame globale Bank,
eine Bank pro Zelle, Vermittler pro Kante. Die letzten beiden können beide lokal sein.
Die kantenlokale äußere Bandschranke wurde auf 0,7 Δ verbessert.

**Offen:** Lokalität allein wählt die dritte Variante nicht aus. Unterschiedliche
Bauweisen geben unterschiedliche Korrekturen zur niedrigen Dynamik.

**Entscheidender Test:** Beide lokalen Varianten an identischen Quellanforderungen
messen. Eine Wahl nach dem angenehmsten Spektrum wäre keine Herleitung.

## 3. Können wir die Vierfachstruktur wirklich beweisen?

**Schon erreicht:** Die lokale vierte Ordnung ist eine Summe positiver lokaler
Operatoren. Die korrigierte 24.024-dimensionale Singulettrechnung liefert ein
vierfach gefundenes erstes Niveau und einen Gap von etwa 0,48648 J.

**Offen:** Gleitkommazahlen sind noch kein exakter Multiplizitätsbeweis. Die bisherigen
nackten Untergrenzen anderer Sektoren benötigen zertifizierte Fehlerintervalle;
der mikroskopische Rest bleibt eine weitere Aufgabe.

**Entscheidender Test:** Exakte Symmetrieprojektoren plus zertifizierte Spektralgrenzen.
Die neue positive Form reduziert dafür die algebraische Schwierigkeit deutlich.

## 4. Bleibt das Labor bei Fehlern und wachsender Größe brauchbar?

**Schon erreicht:** Ein vollständiger Sternfilter mit 13 physikalischen Zeitfaktoren;
ein gemeinsamer Start-/Endversuch benötigt 26 solcher Schritte. Beim alternativen
Feedbackweg ist die Fehlerverstärkung pro dauerhaftem Zyklusfehler auf etwa 40,68
beschränkt. Unabhängige Zellen lassen sich mit einer logarithmisch wachsenden
Zykluszahl kontrollieren.

**Offen:** Reale Clockfehler, Entropieabfluss und wechselwirkende Zellen sind nicht
durch den unabhängigen Zelltest erledigt. Exakte Zeitwahl ist eine starke Ressource.

**Entscheidender Test:** Eine wachsende, wirklich gekoppelte Probe mit vollständig
ausgewiesenen Fehlern, Resetkosten und Zeitskalen — nicht nur ideale Einzelzellen.

## 5. Entsteht daraus eine einzige gemeinsame Welt?

**Schon erreicht:** Skalierende Wärmetrace-Tests; ein expliziter zweidimensionaler
chiraler Flussoperator; Kontrollen gegen ungewollte Weyl-Arten; ein Tensor-Spektraltest.

**Offen:** Die Testfamilie gibt jede hineingesteckte Dimension wieder. Drei chirale
Nullmoden folgen bisher aus hineingestecktem Fluss drei. Ein Tensorprojektor erzeugt
noch keinen masselosen Gravitationsmodus. Das sind hilfreiche Kontrollmodelle,
aber nicht drei schon abgeleitete Eigenschaften des Universalraums.

**Entscheidender Test:** EINE native skalierende Familie muss Dimension und gemeinsamen
Lichtkegel, chirales Maß und Spin-2-Dynamik gleichzeitig tragen. Hier liegen T3, T4,
T5 und T7 zusammen. Ein positiver Test für nur einen dieser Punkte bleibt ein Teilresultat.

## 6. Stimmen dieselben Parameter mit mehreren Beobachtungen überein?

**Schon erreicht:** Drei Nullmoden sind von einer Massenhierarchie unterschieden.
Ein konstanter Überlapp liefert im kontrollierten Beispiel gleiche Massen. In der
einfachen Inflationsbranche wurde die frei scheinende Wahl der E-Faltungszahl N
eliminiert und eine Spannung zwischen Amplitude und Spektralneigung sichtbar.

**Offen:** Vollständige Flavourstruktur und gemeinsamer empirischer Transfer.
Einzeln passend gewählte Parameter sind keine unabhängigen Vorhersagen.

**Entscheidender Test:** Amplitude, Neigung, Tensoranteil und Flavour mit derselben
fixierten Parametrisierung und ihren Korrekturen berechnen. ACT-Vergleich siehe
[Primärquelle, Tabelle 5 v2](https://arxiv.org/abs/2503.14452v2).

## Was das für die großen Ziele bedeutet

T1–T8 sind einzeln im Hauptbuch und Forschungsbericht zugeordnet; keines ist vollständig
geschlossen. Der Halbladungsoperator für T2 braucht weiter eine native analytische
Erweiterung. RH, Faktorisierung und P versus NP sind nicht durch die endlichen
physikalischen Tests gelöst. Neuere externe RH-/Faktorquellen sind lokal teilweise
nicht verfügbar und deshalb nicht als unabhängig verifizierter Fortschritt verbucht.

**Mein Vorschlag für die nächste Revision:** Zuerst Frage 1 und 2 entscheiden,
daneben Frage 3 zertifizieren. Frage 4 liefert den Belastungstest. Erst auf dieser
gemeinsamen Grundlage können die Tests aus Frage 5 und 6 als Physik dieser Quelle
statt als passend ausgewählte Referenzmodelle gelten. Die aktuelle Revision hat
die Vorarbeiten für alle sechs Fragen tatsächlich gerechnet, nicht nur aufgelistet.
