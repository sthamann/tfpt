# Der erste klar erkennbare Ausschlag auf dem richtigen Hintergrund

**TFPT / Universalraum · einfach erklärt · Fortsetzung v1.6.3**

## Was wir diesmal tatsächlich weitergebracht haben

Die bisherige Rechnung zeigte eine besonders einfache Antwort auf einem
gewählten Vierladungszustand. Dieser Zustand war aber nicht der
Grundzustand des ursprünglichen Modells.

Jetzt wurde zuerst der ursprüngliche Grundzustandsbeweis vollständig
wiederholt. Im angegebenen Modell liegt der eindeutige Grundzustand bei
Gesamtladung 64. Auf genau diesem Hintergrund wurde anschließend
untersucht, was passiert, wenn man eines der ursprünglichen Fermionen entfernt.

**Dabei gibt es einen deutlich isolierten Ausschlag: eine einzelne niedrige
Energielinie, die mehr als 86,49 Prozent des gesamten Spektralgewichts
der ursprünglichen Fermionantwort trägt.**

Das ist das wichtigste neue Ergebnis dieser Fortsetzung. Wir haben nun
eine kontrollierte geladene Anregung auf dem richtigen modellinternen
Hintergrund. Der ursprüngliche Hamiltonoperator wurde dafür nicht erweitert.

## Ein Bild dafür

Stell dir ein gekoppeltes System vor, das in seinem energetisch günstigsten
Zustand ruht. Wenn du einen seiner ursprünglichen Bestandteile entnimmst,
könnte es in sehr viele verschiedene Schwingungen geraten.

Die neue Rechnung zeigt: Der größte Teil der Antwort landet in einer
einzigen, deutlich abgetrennten niedrigen Schwingung. Andere Entnahmeschwingungen
beginnen erst erheblich höher. Einen zusätzlichen Bestandteil hineinzusetzen
benötigt ebenfalls höhere Energien.

**Wo das Bild endet:** Diese „Schwingung“ ist eine lokale Energiedifferenz
im endlichen Modell. Noch sind weder ein Ort im physikalischen Raum noch
ein bewegtes Teilchen oder eine Lichtgeschwindigkeit daraus hergeleitet.

## Wie genau kennen wir diese Linie?

Für den unveränderten Hamiltonoperator ohne zusätzlichen Ladungsenergieterm
und den bereits verwendeten Prüfwert g/Δ=1/20 gilt:

- Die niedrige Entnahmeenergie liegt zwischen **0,007737 Δ und 0,062277 Δ**.
- Das Gewicht dieser einzelnen Linie liegt über **86,497 %** des gesamten
  normierten Fermionspektrums.
- Weitere Entnahmelinien beginnen oberhalb **0,379636 Δ**.
- Additionslinien beginnen oberhalb **0,329636 Δ**.

Δ ist die Energieskala des Modells. Ihre Umrechnung in eine physische
Energieeinheit ist hier nicht hergeleitet. Die Intervalle sind bewiesene
Grenzen; ihr Mittelpunkt ist kein berechneter Messwert.

Die gesamte Entnahmeantwort hat etwa **95,47–97,59 %** Gewicht, die Addition
**2,41–4,53 %**. Die mehr als 86,49 Prozent der einzelnen Linie sind in der
Entnahmeantwort enthalten. Es handelt sich um Spektralgewichte, nicht um
bereits realisierte Erfolgswahrscheinlichkeiten eines nativen Detektors.

## Weshalb das ohne riesige Komplettrechnung möglich war

Wir kennen einen einfachen vollständig besetzten Ausgangszustand und
mehrere daraus erzeugte Vergleichszustände. Ihre Normen und Kopplungen
lassen sich exakt berechnen. Entfernt man jeweils ein Fermion, entstehen
64 gleich aufgebaute kleine Vergleichsräume.

Mit diesen Räumen und einer Schranke für **alle anderen** Zustände lässt
sich beweisen, dass unten genau ein Energieniveau mit 64 inneren Varianten
liegt. Eine weitere Rechnung zeigt, dass die ursprüngliche Entnahmeoperation
dieses Niveau tatsächlich mit großem Gewicht trifft.

Wir wissen deshalb sicher, dass die Linie existiert und isoliert ist.
Ihren exakten Ort und ihr exaktes Gewicht haben wir noch nicht bestimmt.

## Zwei wichtige Korrekturen bleiben bestehen

**Die beiden 64er-Strukturen sind auf diesem Hintergrund nicht dasselbe.**
Ein ursprüngliches Fermion zu entfernen führt von Ladung 64 nach 63.
Die kubische zusammengesetzte Anregung zu erzeugen führt nach 67.
Gleiche Anzahl innerer Varianten macht diese beiden Vorgänge nicht identisch.

**Das relativistische Wörterbuch braucht einen anderen Anschluss.**
Die einfache Zuordnung zu gleichhändigen Weylfeldern und einem skalaren
Vermittler setzt die vorhandene Wechselwirkung exakt auf null.
Ein symmetrischer Spinortensor hat einen nichtverschwindenden Kanal,
aber seine vollständige physische Dynamik und seine Verbindung zur
ursprünglichen Bank sind noch offen.

## Was die zusätzlichen Operationen gebracht haben

Die dokumentierte Clock unterscheidet mehr innere Phasenklassen.
Die daraus mathematisch erzeugte Kontrollalgebra wächst von 14 auf
84 Dimensionen. Trotzdem bleiben große Gruppen von Zuständen für diese
Kontrollen ununterschieden. Insbesondere folgt daraus noch kein
ausführbarer Befehl, ein einzelnes Fermion an einen anderen Teil zu übertragen.

Ein entsprechender Detektor müsste die entnommene Ladung übernehmen.
Seine eigene Energie müsste mitkalibriert werden: Messbar ist die
Energiedifferenz zwischen Bank und Detektor. Der Detektor darf nicht
unbemerkt die fehlende physische Energieauswahl liefern.

## Was jetzt als Nächstes wirklich zählt

Die Kette ist nun länger:

**ursprüngliche Wechselwirkung → abgesicherter Grundzustand →
isolierte geladene Antwort auf diesem Grundzustand.**

Der nächste Herkunftsnachweis muss eine zulässige Operation zeigen, die
diese Anregung zwischen zwei tatsächlich bestimmten Teilen überträgt,
und ein konsistentes Feldwörterbuch dazu liefern. Danach wird eine
räumliche Skalierungsrechnung aussagekräftig.

Parallel kann die lokale Rechnung verschärft werden: Wie groß sind Energie
und Gewicht der isolierten Linie genau? Die jetzigen bewiesenen Intervalle
geben dafür einen konkreten Prüfrahmen.

**Die fundamentale Gesamtlösung ist weiterhin offen. Der neue lokale
Entnahmepol ist ein belastbarer weiterer Baustein, keine bereits
hergeleitete Raumzeit oder vollständige TOE.**

Die ausführlichen Beweise, Annahmen und Prüfdateien stehen im zugehörigen
Forschungsbericht v1.6.3. Die bisherigen Haupt- und Update-PDFs bleiben erhalten.
