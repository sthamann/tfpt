"""Replay the new verifier twice; fail on either exit status or byte mismatch."""
from pathlib import Path
from datetime import datetime
import subprocess,sys,json,hashlib

here=Path(__file__).resolve().parent
dest=here.parent/'work'/'replay'/datetime.now().strftime('%Y%m%d-%H%M%S-%f')
dest.mkdir(parents=True)
rows=[]
for name,flags in [('normal',[]),('optimized',['-OO'])]:
    result=subprocess.run([sys.executable,'-B',*flags,str(here/'verify_native_pole.py')],capture_output=True)
    (dest/f'{name}.json').write_bytes(result.stdout)
    (dest/f'{name}.stderr').write_bytes(result.stderr)
    rows.append({'name':name,'exit_code':result.returncode,'sha256':hashlib.sha256(result.stdout).hexdigest()})
    if result.returncode:
        print(result.stderr.decode(errors='replace'),file=sys.stderr)
        (dest/'replay.json').write_text(json.dumps({'status':'FAIL','runs':rows},indent=2))
        raise SystemExit(result.returncode)
    if json.loads(result.stdout)['status']!='PASS':raise RuntimeError('non-PASS verifier result')
same=(dest/'normal.json').read_bytes()==(dest/'optimized.json').read_bytes()
receipt={'status':'PASS' if same else 'FAIL','byte_identical':same,'runs':rows}
(dest/'replay.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
if not same:raise SystemExit(1)
