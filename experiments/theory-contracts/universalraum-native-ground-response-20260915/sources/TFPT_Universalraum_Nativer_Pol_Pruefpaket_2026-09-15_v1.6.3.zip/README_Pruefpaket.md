# TFPT / Universalraum v1.6.3 – Reproduktion

## Inhalt

- Forschungsbericht und einfache Erklärung.
- Abbildung der bewiesenen Spektralintervalle.
- `verify_native_pole.py`: neue exakte Prüfungen und analytische Zertifikate.
- `verification_native_pole.json` und optimiertes Gegenstück: 317 Prüfbedingungen.
- `native_ground_replayed.json`: frisch wiederholtes ursprüngliches Grundzustandszertifikat.
- `input_manifest.json`: die acht ursprünglichen Dokumente mit SHA-256.
- `replay_manifest.json`: Ergebnisse und Pins dieser Fortsetzung.
- Im ZIP zusätzlich: unverändertes ursprüngliches natives Prüfarchiv unter `sources/`
  und Snapshots der unmittelbar importierten Forschungsquellen unter `source_snapshots/`.

## Neue Rechnung wiederholen

```sh
python3 replay_native_pole.py
```

Der Starter bewahrt beide Exitcodes, schreibt Ergebnisse in einen neuen
Unterordner `work/replay` neben dem Paket und verlangt identische Ausgabe-Bytes.
Benötigt werden Python, NumPy, SciPy und SymPy. Verifiziert wurde mit dem
lokal installierten Homebrew-Python; dem gebündelten Dokument-Python fehlte SymPy.

**Lokaler Quellenkontext wird benötigt.** Der neue Prüfer liest die in
`replay_manifest.json` genannten bestehenden TFPT-Forschungsquellen unter
`/Users/stefanhamann/Projekte/tfpt-theoryv4/` und den ursprünglichen Tensor.
Die enthaltenen Quellsnapshots dokumentieren diese Abhängigkeiten, ersetzen
aber nicht automatisch sämtliche transitiven Repository-Abhängigkeiten.
Das neue Paket behauptet deshalb keine vollständig portable Installation.

## Ursprünglichen Grundzustandsnachweis wiederholen

Das enthaltene ZIP `sources/TFPT_Native_Bank_Pruefpaket_2026-09-14.zip`
in ein separates Verzeichnis entpacken und dort ausführen:

```sh
python3 run_checks.py
python3 run_checks.py --optimized
```

Dieses ursprüngliche Archiv rekonstruiert seine Tensoren und Normsummen
selbst. Zusätzlich benötigt es clang++ mit C++20 und Apples libdispatch.
Es schreibt ausschließlich innerhalb seines entpackten Verzeichnisses.
Auf anderen Plattformen muss die libdispatch-Parallelisierung angepasst werden.

## Beweisgrenze

Die Programme prüfen endliche Identitäten und rationale Ungleichungen.
Der Forschungsbericht enthält die dazugehörigen analytischen Übergänge:
Symmetrie, Minimax, Spektralmaßpositivität und Momentargumente. Ein grüner
Lauf allein ersetzt diese Argumente nicht. Eine vollständige formale
Lean-Verifikation oder externe Begutachtung wird nicht behauptet.

Ein isolierter sichtbarer Entnahmepol ist nachgewiesen; seine genaue Energie,
sein genaues Gewicht und sämtliche weiteren Pole sind nicht ausgerechnet.
Ebenso sind primitive Operationsherkunft, physische Energieauswahl,
relativistische Kinetik und räumliche Ausbreitung weiterhin offen.
