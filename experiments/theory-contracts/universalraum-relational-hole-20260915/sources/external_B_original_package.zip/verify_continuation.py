"""Independent finite checks for the research continuation; no source mutation.

All algebraic checks use integer or rational arithmetic. Numerical spectral
discovery is not used. Source coefficients and the Clifford convention are
explicit premises. A PASS does not select a physical state or continuum.
"""
from pathlib import Path
from itertools import combinations, permutations
from collections import defaultdict
import hashlib
import json
import math
import numpy as np
import scipy.sparse as sp
import sympy as sy

ROOT = Path(__file__).resolve().parent
PIN = '3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763'
checks = []
def require(ok, name):
    if not ok:
        raise RuntimeError(name)
    checks.append(name)
def zero(a):
    a = a.tocsr(); a.eliminate_zeros()
    return a.nnz == 0

path = ROOT/'sources/sources/native_tensor.npz'
require(hashlib.sha256(path.read_bytes()).hexdigest() == PIN, 'source SHA256')
with np.load(path, allow_pickle=False) as z:
    raw = z['W']
    require(np.all(raw.imag == 0) and np.all(raw.real == np.rint(raw.real)), 'exact integer tensor input')
    W = raw.real.astype(np.int64)
require(np.array_equal(W@W.T, 8*np.eye(60, dtype=np.int64)), 'W row Gram')
pairs = list(combinations(range(64), 2))
paircols = {p:i for i,p in enumerate(pairs)}
trips = list(combinations(range(64), 3))
entries = {pair: [(int(a),int(W[a,k])) for a in np.flatnonzero(W[:,k])]
           for k,pair in enumerate(pairs)}
rows, cols, vals = [], [], []
for col, t in enumerate(trips):
    for i,j in combinations(range(3),2):
        rest = t[3-i-j]
        # f_j f_i: remove position i, then position j-1.
        sign = (-1)**(i+j-1)
        for a,w in entries[t[i],t[j]]:
            rows.append(64*a+rest); cols.append(col); vals.append(sign*w)
C = sp.csr_matrix((np.array(vals,dtype=np.int64),(rows,cols)),shape=(3840,41664))
S = (C@C.T).tocsr()
require(C.nnz == 29760, 'independent C3 support')
I = sp.eye(3840, dtype=np.int64, format='csr')
rowbound = int(np.max(np.asarray(abs(S).sum(axis=1))))
require(math.prod(rowbound+r for r in [0,7,10,12]) < 2**63//3840, 'polynomial and trace integer bounds')
poly=I
for r in [0,7,10,12]: poly=poly@(S-r*I)
require(zero(poly), 'integer annihilating polynomial')
mult={}
for r in [0,7,10,12]:
    num=I; den=1
    for q in [0,7,10,12]:
        if q!=r: num=num@(S-q*I); den*=r-q
    tr=int(num.diagonal().sum())
    require(tr%den == 0, f'exact projector trace {r}')
    mult[r]=tr//den
require(mult == {0:64,7:2880,10:576,12:320}, 'full row spectrum')

# Reconstruct Clifford tensors on the exterior algebra of five modes.
ann=[]
for j in range(5):
    a=np.zeros((32,32),dtype=np.int64)
    for m in range(32):
        if m&(1<<j): a[m^(1<<j),m]=(-1)**((m&((1<<j)-1)).bit_count())
    ann.append(a)
conj=np.eye(32,dtype=np.int64)
for a in ann: conj=conj@(a+a.T)
ev=[m for m in range(32) if m.bit_count()%2==0]
beta=[(conj@a)[np.ix_(ev,ev)] for a in ann+[a.T for a in ann]]
epsilon={p:(-1)**sum(p[i]>p[j] for i in range(4) for j in range(i+1,4)) for p in permutations(range(4))}
J=np.zeros((64,60,64),dtype=np.int64)
for k in range(10):
    for ab,(a,b) in enumerate(combinations(range(4),2)):
        for s,t in zip(*np.nonzero(beta[(k+5)%10])):
            for c,d in permutations(range(4),2):
                J[4*t+d,6*k+ab,4*s+c]=int(beta[(k+5)%10][s,t])*epsilon.get((a,b,c,d),0)
Jflat=sp.csr_matrix(J.reshape(64,3840))
require(zero(Jflat@C), 'independent JC3 zero')
require(zero(Jflat@Jflat.T-15*sp.eye(64,dtype=np.int64)), 'independent JJdagger')
require(np.array_equal(np.einsum('rai,rbi->ab',J,J),16*np.eye(60,dtype=np.int64)), 'boson partial contraction 16 I60')
require(np.array_equal(np.einsum('rai,raj->ij',J,J),15*np.eye(64,dtype=np.int64)), 'fermion partial contraction 15 I64')

# Rational representative similar to each Hermitian sqrt(lambda) block.
X=sy.zeros(8); B=sy.diag(0,1,0,1,0,1,0,1)
for o,lam in [(2,7),(4,10),(6,12)]: X[o,o+1]=lam; X[o+1,o]=1
basis=[sy.eye(8)]; flat=sy.Matrix(64,1,list(basis[0])); rank=1
while True:
    old=len(basis)
    for a in list(basis):
        for gen in [X,B]:
            v=a*gen; f=sy.Matrix(64,1,list(v)); candidate=flat.row_join(f)
            newrank=candidate.rank()
            if newrank>rank: basis.append(v); flat=candidate; rank=newrank
    if len(basis)==old: break
require(rank==14,'N3 associative control algebra has exact dimension 14')
nf,nb=sy.symbols('nf nb',real=True)
Z=1+nb/sy.Integer(60)-nf/sy.Integer(64)
require(sy.simplify(Z.subs(nf,64-2*nb)-23*nb/480)==0,'N64 invariant-state spectral weight 23 nb/480')

# Exact bosonic polynomial basis: creation has coefficient one,
# annihilation has coefficient occupation. No boson cutoff is imposed.
terms=[[(int(a),int(i),int(J[r,a,i])) for a,i in zip(*np.nonzero(J[r]))] for r in range(64)]
def elementary(state,kind,index,dagger):
    occ,mask=state; occ=dict(occ)
    if kind=='f':
        present=bool(mask&(1<<index))
        if present == dagger: return None
        sign=(-1)**((mask&((1<<index)-1)).bit_count())
        return (tuple(sorted(occ.items())),mask^(1<<index)),sign
    n=occ.get(index,0)
    if not dagger and n==0: return None
    occ[index]=n+(1 if dagger else -1)
    if occ[index]==0: del occ[index]
    return (tuple(sorted(occ.items())),mask),1 if dagger else n
def chain(state,ops):
    coeff=1
    for op in ops:
        res=elementary(state,*op)
        if res is None:return None
        state,c=res; coeff*=c
    return state,coeff
def apply_comp(vector,r,dagger):
    out=defaultdict(int)
    for state,amp in vector.items():
        for a,i,j in terms[r]:
            res=chain(state,[('f',i,dagger),('b',a,dagger)])
            if res:
                s,c=res; out[s]+=amp*j*c
    return {s:c for s,c in out.items() if c}
def add(v,w):
    d=defaultdict(int,v)
    for s,c in w.items(): d[s]+=c
    return {s:c for s,c in d.items() if c}
def predicted(state,r,s):
    out=defaultdict(int)
    if r==s:out[state]+=15
    for a,i,u in terms[r]:
        for b,j,v in terms[s]:
            if i==j:
                res=chain(state,[('b',a,False),('b',b,True)])
                if res:
                    st,c=res;out[st]+=u*v*c
            if a==b:
                res=chain(state,[('f',i,False),('f',j,True)])
                if res:
                    st,c=res;out[st]-=u*v*c
    return {s:c for s,c in out.items() if c}
states=[((),0),((),(1<<64)-1),((),1),((),(1<<0)|(1<<4)|(1<<57)),(((0,1),),0),(((36,2),),1<<4),(((0,1),(4,1)),(1<<7)|(1<<12))]
for r,s in [(0,0),(0,1),(0,4),(7,12),(63,63)]:
    for st in states:
        lhs=add(apply_comp(apply_comp({st:1},s,True),r,False),apply_comp(apply_comp({st:1},r,False),s,True))
        require(lhs==predicted(st,r,s), f'CAR identity witness {r} {s} {states.index(st)}')

# Nonzero natural charge-four scalar candidate Qdagger=sum_r f_rdagger c_rdagger.
quartet=defaultdict(int)
for r in range(64):
    for a,i,j in terms[r]:
        res=chain(((),0),[('f',i,True),('b',a,True),('f',r,True)])
        if res:
            st,c=res;quartet[st]+=j*c
quartet={s:c for s,c in quartet.items() if c}
require(bool(quartet), 'native charge-four composite contraction is nonzero')
require(all(mask.bit_count()+2*sum(n for _,n in occ)==4 for occ,mask in quartet), 'all quartet monomials have N charge four')
# No numerical vacuum/condensate choice is part of these checks.
out={'status':'PASS','exact_checks':len(checks),'checks':checks,'source_sha256':PIN,
 'C3_shape':list(C.shape),'C3_nnz':C.nnz,'spectrum':mult,'control_algebra_dimension':rank,
 'control_algebra':'C on 37888 dark fermions + C on 64 dark composites + direct sum of M2 with multiplicities 2880,576,320',
 'composite_anticommutator':'delta_rs + boson_density_contraction/15 - fermion_density_contraction/15',
 'invariant_state_Z':'1 + <Nb>/60 - <Nf>/64','invariant_N64_Z':'23 <Nb>/480',
 'charge_four_unscaled_support':len(quartet),'charge_four_unscaled_squared_norm_on_vacuum':sum(c*c for c in quartet.values()),
 'physical_vacuum_selected':False,'quartet_condensation_proven':False,'spacetime_derived':False,'T1_T8_closed':[]}
print(json.dumps(out,indent=2,sort_keys=True))
