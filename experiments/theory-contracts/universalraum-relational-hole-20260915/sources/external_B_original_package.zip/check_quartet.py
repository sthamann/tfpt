from pathlib import Path
import runpy,contextlib,io,json,math
from collections import defaultdict
with contextlib.redirect_stdout(io.StringIO()):
    d=runpy.run_path(str(Path(__file__).with_name('verify_continuation.py')))
chain=d['chain']; W=d['W']; pairs=d['pairs']; q=d['quartet']; require=d['require']
require((d['J'] == -d['J'].transpose(2,1,0)).all(), 'J antisymmetric in output and spectator fermion indices')
vertices=[(a,*pairs[k],int(W[a,k])) for a,k in zip(*W.nonzero())]
def convert(vec):
    out=defaultdict(int)
    for state,c in vec.items():
        for a,i,j,w in vertices:
            for ops in [[('f',i,False),('f',j,False),('b',a,True)],
                        [('b',a,False),('f',j,True),('f',i,True)]]:
                res=chain(state,ops)
                if res:
                    st,amp=res;out[st]+=c*w*amp
    return {st:c for st,c in out.items() if c}
def inner(a,b):
    return sum(c*b.get(st,0)*math.prod(math.factorial(n) for _,n in st[0]) for st,c in a.items())
def summary(v):
    counts=defaultdict(int)
    for (occ,m),c in v.items(): counts[f'{m.bit_count()}f,{sum(n for _,n in occ)}b']+=1
    return dict(counts)
cq=convert(q); ccq=convert(cq)
require(all(mask==0 for occ,mask in cq),'quartet converts exclusively into two bosons')
nq=inner(q,q); ncq=inner(cq,cq)
require(ncq%nq==0,'quartet squared coupling integer')
lam=ncq//nq
require(ccq=={st:lam*c for st,c in q.items()},'quartet two-dimensional invariant block closure')
require(inner(q,cq)==0,'quartet basis orthogonal')
require(lam==16,'quartet coupling is 4g')
hole_checks=[]
for r in range(64):
    hole=defaultdict(int)
    for st,c in q.items():
        res=chain(st,[('f',r,False)])
        if res:
            st1,a=res;hole[st1]+=c*a
    hole={st:c for st,c in hole.items() if c}
    trion=d['apply_comp']({((),0):1},r,True)
    require(hole=={st:2*c for st,c in trion.items()},f'quartet hole equals trion for mode {r}')
    require(inner(hole,hole)==60,f'quartet hole norm for mode {r}')
    hole_checks.append(r)
four_free={((),sum(1<<i for i in [0,1,2,57])):1}
converted_free=convert(four_free)
free_strength=inner(converted_free,converted_free)
require(free_strength>0,'N4 free-fermion variational state couples')
require(all(mask.bit_count()==2 and sum(n for _,n in occ)==1 for occ,mask in converted_free), 'N4 variational compression has diagonal zero and Delta')
sy=d['sy']; Delta,g=sy.symbols('Delta g', real=True)
h=sy.Matrix([[Delta,4*g],[4*g,2*Delta]])
require(h*h-3*Delta*h+(2*Delta**2-16*g**2)*sy.eye(2)==sy.zeros(2), 'symbolic quartet characteristic polynomial')
print(json.dumps({'status':'PASS','exact_checks_including_dependencies':len(d['checks']),'q_unscaled_support':summary(q),'Xq_support':summary(cq),
 'norm_q_squared':nq,'norm_Xq_squared':ncq,'X_squared_on_q':lam,
 'normalized_H_block':'[[Delta,4g],[4g,2Delta]]',
 'energies':'(3Delta +/- sqrt(Delta^2+64g^2))/2',
 'negative_lower_energy_iff':'abs(g)/Delta > 1/sqrt(8)',
 'lower_energy_at_g_over_Delta_1_20':(3-math.sqrt(1+64/400))/2,
 'quartet_hole_modes_checked':len(hole_checks),
 'normalized_hole_identity':'f_r |Q4> = chi_r^dagger |0> / sqrt(32)',
 'lower_quartet_hole_gap':'(sqrt(Delta^2+64g^2)-Delta)/2',
 'lower_quartet_hole_gap_at_ratio_1_20':(math.sqrt(1+64/400)-1)/2,
 'lower_quartet_hole_residue_per_mode':'(1+Delta/sqrt(Delta^2+64g^2))/64',
 'negative_N4_variational_witness':{'fermion_modes':[0,1,2,57],'squared_conversion_norm':free_strength,
     'energy_upper_bound':'(Delta-sqrt(Delta^2+4g^2*squared_conversion_norm))/2 < 0 for g != 0'},
 'scope':'exact invariant charge-four subspace, no full N4 singlet census, no condensate or ground-state selection',
 'T1_T8_closed':[]},indent=2))
