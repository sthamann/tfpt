"""Run both independent checkers normally and optimized; preserve failures."""
from pathlib import Path
import subprocess
import sys
import json
import hashlib

base=Path(__file__).resolve().parent
reports=base/'reports'
reports.mkdir(exist_ok=True)
manifest={'status':'PASS','runs':[],'T1_T8_closed':[]}
for name in ['verify_continuation.py','check_quartet.py']:
    outputs=[]
    for flags,mode in [([], 'normal'),(['-OO'],'optimized')]:
        result=subprocess.run([sys.executable,*flags,str(base/name)],cwd=base,capture_output=True)
        (reports/(name+'.'+mode+'.json')).write_bytes(result.stdout)
        (reports/(name+'.'+mode+'.stderr')).write_bytes(result.stderr)
        if result.returncode:
            sys.stderr.write(result.stderr.decode(errors='replace'))
            raise SystemExit(result.returncode)
        data=json.loads(result.stdout)
        if data.get('status')!='PASS':raise RuntimeError((name,mode,'not PASS'))
        outputs.append(result.stdout)
    if outputs[0]!=outputs[1]:raise RuntimeError((name,'normal/optimized mismatch'))
    manifest['runs'].append({'script':name,'script_sha256':hashlib.sha256((base/name).read_bytes()).hexdigest(),
                            'normal_optimized_equal':True,'exit_code':0})
    print(name+': PASS; normal and optimized reports identical',flush=True)
(reports/'replay_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
