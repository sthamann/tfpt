# Rechenpaket: TFPT, Viererhintergrund und Lochanschluss

15. September 2026. Dieses Paket begleitet die Forschungsnotiz
`TFPT_Universalraum_Einfache_Fortsetzung_2026-09-15.md`.

## Ausführen

Voraussetzung: Python 3.10 oder neuer mit NumPy, SciPy und SymPy.
In einer gewünschten Python-Umgebung können die Abhängigkeiten mit
`python3 -m pip install numpy scipy sympy` installiert werden.

Danach in diesem Verzeichnis:

```sh
python3 replay.py
```

Der Replay führt beide Prüfer normal und mit `-OO` aus. Er erhält tatsächliche
Fehlercodes und verlangt bytegleiche Berichte. Ergebnisse stehen in `reports/`.
Er benötigt keine alten Repositorypfade. Der Tensor ist unter
`sources/sources/native_tensor.npz` enthalten und per SHA-256 geprüft.

## Inhalt und Grenzen

- `verify_continuation.py`: unabhängige N=3-Rekonstruktion, J-Tensor,
  Kontrollalgebra und Komposit-Normidentität; 54 exakte Prüfbedingungen.
- `check_quartet.py`: führt die Basisprüfung erneut aus und prüft den
  invarianten Viererblock, alle 64 Lochidentitäten und das negative
  N=4-Variationsgegenbeispiel; insgesamt 191 exakte Bedingungen inklusive Basis.
- `evidence/`: aktuelle Berichte der zusätzlich ausgeführten ursprünglichen
  N=3-/E8-Prüfer. Diese historischen Prüfer selbst sind nicht Teil dieses
  eigenständig ausführbaren Pakets; ihre Berichte bleiben getrennte Evidenz.
- `source_manifest.json`: Hashes der sieben vom Nutzer genannten Dokumente.

Die Prüfung belegt endliche Operator- und Vektoridentitäten des festgelegten
Modells. Sie wählt keinen physikalischen Zustand aus und leitet keinen Raum,
keine Gravitation, RH oder effiziente Faktorisierung her. Kein T1–T8-Tor ist
vollständig geschlossen. Die Dezimalwerte stammen aus geschlossenen Formeln.
Eine formale Lean-Verifikation oder externe Begutachtung wurde nicht ausgeführt.
