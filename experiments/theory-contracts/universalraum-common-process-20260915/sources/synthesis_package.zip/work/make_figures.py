from pathlib import Path
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
out=Path('outputs/figures');out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.bbox':'tight'})
navy='#18354b'; teal='#007f86'; orange='#ba5a28'; gray='#607181'
fig,ax=plt.subplots(figsize=(10.7,4.7));ax.axis('off');ax.set_xlim(0,10.7);ax.set_ylim(0,4.7)
boxes=[(.1,2.75,'MARKIERTE QUELLE','Träger · Tensor · Clock',navy),(3.7,2.75,'GEMEINSAMER PROZESS','Operationen · Zustand · Records',teal),(7.3,2.75,'PHYSIKALISCHE WELT','Raumzeit · Felder · Messwerte',orange),(.1,.4,'BELEGT IM MODELL','E8 · Paarregel · lokale Spektren',navy),(3.7,.4,'HIER VERBUNDEN','Gramkern · Referenz · Projektion',teal),(7.3,.4,'NOCH HERZULEITEN','Auswahl · Lokalität · Grenzwert',orange)]
for x,y,t,b,c in boxes:
 ax.add_patch(FancyBboxPatch((x,y),3.15,1.15,boxstyle='round,pad=0.12',facecolor=c,edgecolor=c));ax.text(x+.12,y+.77,t,color='white',weight='bold',fontsize=10);ax.text(x+.12,y+.32,b,color='white',fontsize=9)
for x in [3.3,6.9]:ax.annotate('',xy=(x+.33,3.3),xytext=(x,3.3),arrowprops={'arrowstyle':'->','color':gray,'lw':2})
ax.text(5.35,2.04,'Ein verbindender Formalismus ist konstruiert. Die physische Auswahl bleibt offen.',ha='center',color=gray,fontsize=11)
fig.savefig(out/'01_gemeinsame_kette.pdf');fig.savefig(out/'01_gemeinsame_kette.png',dpi=180);plt.close(fig)
g=.05;J=1-1/(10*np.sqrt(3));H=np.array([[0,g,0,0],[g,1,J,0],[0,J,1,g],[0,0,g,0]],float);e,v=np.linalg.eigh(H)
ts=np.linspace(0,20*np.pi*np.sqrt(3),600);amps=(v*np.exp(-1j*ts[:,None,None]*e)) if False else None
p=[]
for t in ts:U=(v*np.exp(-1j*t*e))@v.T;p.append(abs(U[3,0])**2)
fig,axs=plt.subplots(1,2,figsize=(10.4,3.6))
axs[0].plot(ts,p,color=teal,lw=2,label='Mit bilanzierter Referenz');axs[0].axhline(0,color=orange,ls='--',label='Ohne Mischkopplung');axs[0].set(xlabel=r'$t\Delta$',ylabel='Transferwahrscheinlichkeit',ylim=(-.04,1.06));axs[0].legend(fontsize=8);axs[0].set_title('Bedingter Vierzustandskanal',loc='left',color=navy)
axs[1].axis('off');axs[1].text(.03,.83,'SYSTEM      +      REFERENZ',weight='bold',color=navy);axs[1].text(.03,.61,'Cartanladung 7        +1');axs[1].text(.03,.44,'           ↓  gekoppelte Entwicklung');axs[1].text(.03,.26,'Cartanladung 9         −1');axs[1].text(.03,.06,'Gesamtladung bleibt 8.\nDie Referenz wird dabei verändert.',color=orange)
fig.tight_layout();fig.savefig(out/'02_relationaler_transfer.pdf');fig.savefig(out/'02_relationaler_transfer.png',dpi=180);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(10.4,3.5));th=np.linspace(0,np.pi,200)
axs[0].plot(th,-np.sin(th)/2,color=teal,label=r'$F_{\theta\phi}=-\sin\theta/2$');axs[0].set(xlabel=r'$\theta$',ylabel='Krümmung',title='Bewegter Projektor: geometrische Krümmung');axs[0].legend(fontsize=9)
axs[1].plot(th,np.sin(th)**2/4,color=navy,label=r'$g_{\phi\phi}=\sin^2\theta/4$');axs[1].axhline(.25,color=orange,ls='--',label=r'$g_{\theta\theta}=1/4$');axs[1].set(xlabel=r'$\theta$',ylabel='Metrik des Zustandsraums',title='Dieselbe Projektion: Unterscheidbarkeit');axs[1].legend(fontsize=9)
fig.tight_layout();fig.savefig(out/'03_projektorgeometrie.pdf');fig.savefig(out/'03_projektorgeometrie.png',dpi=180);plt.close(fig)
print('3 vector figures written')
