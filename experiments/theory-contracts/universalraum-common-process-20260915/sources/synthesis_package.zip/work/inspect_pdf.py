from pathlib import Path
import pymupdf,json
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parent.parent
p=root/'outputs/TFPT_Universalraum_Forschungspaper_2026-09-15.pdf'
doc=pymupdf.open(p);pages=[];bounds=[]
for i,page in enumerate(doc):
 text=page.get_text();pages.append({'page':i+1,'characters':len(text),'images':len(page.get_images())})
 for block in page.get_text('dict')['blocks']:
  for line in block.get('lines',[]):
   for sp in line['spans']:
    x0,y0,x1,y1=sp['bbox']
    if x0<35 or x1>page.rect.width-30 or y0<15 or y1>page.rect.height-15:
     bounds.append({'page':i+1,'text':sp['text'],'bbox':list(sp['bbox'])})
thumbs=[]
for i,page in enumerate(doc):
 pix=page.get_pixmap(matrix=pymupdf.Matrix(.48,.48),alpha=False)
 im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
 th=Image.new('RGB',(im.width,im.height+24),'#dce4e8');th.paste(im,(0,24));ImageDraw.Draw(th).text((8,5),f'Seite {i+1}',fill='black');thumbs.append(th)
w=thumbs[0].width;h=thumbs[0].height
for start in range(0,len(thumbs),12):
 ims=thumbs[start:start+12];contact=Image.new('RGB',(w*4,h*3),'#a9b5bd')
 for k,im in enumerate(ims):contact.paste(im,((k%4)*w,(k//4)*h))
 contact.save(root/f'work/contact_{start+1:02}.jpg')
# Inspect equations and the illustrations at useful resolution.
for n in [1,4,10,11,17,19,21,23,31,32]:
 if n<=len(doc):doc[n-1].get_pixmap(matrix=pymupdf.Matrix(1.3,1.3),alpha=False).save(root/f'work/page_{n:02}.png')
report={'pages':len(doc),'total_characters':sum(p['characters'] for p in pages),'per_page':pages,'spans_near_page_edges':bounds,'replacement_characters':sum(p.get_text().count('\ufffd') for p in doc)}
(root/'work/pdf_inspection.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps(report,ensure_ascii=False)[:4000])
