**TFPT und Universalraum: beide Rekonstruktionsrichtungen, Gegenprüfung und eine gemeinsame Konstruktion**

Analyse vom 14. September 2026 für Stefan Hamann.

Die beiden Ideen lassen sich in einem gemeinsamen mathematischen Rahmen verbinden: TFPT beschreibt markierte Strukturen und Operationen; ein vollständiger Prozess legt zusätzlich fest, wie sie zusammengesetzt, präpariert, ausgeführt und ausgelesen werden. Aus diesem Prozess lassen sich TFPT-Strukturen zurückgewinnen. Eine eindeutige Umkehrung ist genau dann möglich, wenn die zugelassenen Experimente sämtliche relevanten Unterschiede erfassen. Diese Bedingung ist für die bisher betrachteten Schatten nachweislich verletzt.

Damit ist eine präzise, relative Rekonstruktion möglich. Die Rekonstruktion eines einzigen physikalischen Universalraums, der außerdem Raumzeit, das Standardmodell und Gravitation auswählt, ist durch die vorliegenden Daten nicht bestimmt. Die Ursache ist konkret: Mehrere verschiedene Ausführungen erfüllen dieselben bislang überprüften Bedingungen. Ein größerer Zustandsraum oder ein zusätzlicher Symmetriename beseitigt diese Mehrdeutigkeit nicht.

Diese Analyse liefert neben der Einordnung fünf konkrete Ergebnisse: eine kleinere autonome Beschreibung für die festgelegten Marginalauslesungen; eine explizite relationale Uhr auf dem vorhandenen Singulett; ein Hindernis für dessen Präparation durch den reinen Stabilizer-Baukasten; eine korrigierte E₈-Klammer für die vorgeschlagene Kopplungsrechnung; und eine genaue Rekonstruktion der E₈-Hülle aus den beiden markierten Gitterfaktoren. Die ersten beiden Konstruktionen und die zusätzlichen endlichen Gegenprüfungen wurden hier berechnet. Sie werden nicht als physikalischer Abschluss ausgegeben.

Grundlage sind das 21-seitige Compiler-Manuskript vom 13. September, das 7-seitige Anschluss-Paper und die Inversionsnotiz vom 14. September. Beide PDFs wurden vollständig als Text gelesen; die für die Argumente relevanten Formeln und Tabellen wurden zusätzlich visuell kontrolliert. Im lokalen Repository wurden die genannten Ursprungskonstruktionen und Prüfer gezielt gelesen. Der Codegraph enthielt für diese neuen Dateien keine passenden Treffer; deshalb erfolgte dort der direkte Quellenzugriff. Basis-Commit ist `66b91e40e245569f06ab440ead80f446c9be0ee5`; der Arbeitsstand enthält zusätzliche, nicht eingecheckte Forschungsdateien. Die verwendeten Dateien sind im begleitenden Evidenzbericht mit Hashes identifiziert. Dokumentinterne Arbeitsaufträge wurden als Forschungsinhalt behandelt. Die Analysen haben keine Theoriequelle, keinen Ledger und keinen Abschlussmarker geändert.

**TFPT besitzt einen substanziellen algebraischen Kern.** Die historische Schnittstelle besteht aus einem orientierten Rand beziehungsweise einer Naht mit positivem Kern und Normierung \(c_3=1/(8\pi)\), sowie einem fünfteiligen Träger mit einer später als \(3+2\) interpretierten Zerlegung. Das sind strukturelle Annahmen. Die Kurzform „zwei Zahlen“ beschreibt ihren Informationsgehalt unzureichend: Orientierung, Positivität, Trägerart und Auslesung gehören dazu.

Aus dem komplexen Fünferträger entsteht die gerade äußere Algebra

\[
S^+=\Lambda^{\mathrm{even}}\mathbb C^5,
\qquad \dim S^+=1+10+5=16.
\]

Damit steht eine konkrete Spinorstruktur zur Verfügung. Hyperladung und ihre Anomaliesummen sind innerhalb der gewählten Darstellungszuordnung kontrollierbar. Die Verklebung von \(D_5\) und \(A_3\) liefert unter ihrer markierten \(\mathbb Z_4\)-Identifikation die E₈-Hülle. Das ist wesentlich stärker als die isolierten Dimensionsgleichungen \(5+3=8\) oder \(45+15+64+64+60=248\).

Die endliche Seite desselben Programms liefert im ausgewählten komplexen Viererträger 60 Strahlen in 15 vollständigen Messkontexten. Ihre Projektoren, Überlappungen und Symmetrien sind explizit vorhanden. Auch die gemeinsame Verwendung kleiner dimensionsloser Parameter macht das Programm prüfbar: Eine Änderung am Seed verschiebt mehrere Ausgaben gleichzeitig.

Ich habe den elektromagnetischen Formelwert und den Flavor-Seed unabhängig nachgerechnet:

\[
\varphi_0=\frac1{6\pi}+48c_3^4
=0{,}0531719521768455\ldots,
\]
\[
\lambda_C=\sqrt{\varphi_0(1-\varphi_0)}
=0{,}2243762368847218\ldots,
\qquad
\alpha^{-1}=137{,}0359992168407125\ldots.
\]

Der Vergleich mit dem ausdrücklich datierten CODATA-2022-Wert \(137{,}035999177(21)\) ergibt etwa 1,897 experimentelle Standardabweichungen. Die NIST-Tabelle wurde direkt überprüft. Das ist ein genauer Formelwert nahe einer Messgröße. Für eine physikalische Vorhersage bleibt zu zeigen, warum die Quellgleichung genau die Thomson-Kopplung liefert; eine vollständige Theorieunsicherheit ist durch die hohe Rechengenauigkeit nicht bestimmt. [NIST/CODATA](https://physics.nist.gov/cuu/Constants/Table/allascii.txt)

Bei den übrigen phänomenologischen Ausgaben sind Schema und Eingaben entscheidend. Eine Quellmasse ist nicht automatisch eine Polmasse. Ein aus Oszillationssplittings gebildeter Neutrinosummenwert enthält diese Splittings als Inputs. Eine Ausgabe in GeV benötigt den dimensionalen Skalenanker. Das Hauptmanuskript benennt selbst ungünstige Leptonverhältnisse, eine zu kleine einfache Inflationsamplitude und einen verfehlten älteren Higgs-Zweig. Die Universalraum-Idee erklärt diese Abweichungen bisher nicht. Sie wäre erst dann eine Verbesserung, wenn sie einen vorher festgelegten Transfer aus derselben Dynamik herleitet.

Der physikalische Abschluss ist deshalb weiterhin umfassender als die endliche Algebra: Eine gemeinsame lokale Dynamik in 3+1 Dimensionen, chirale Materie mit Spiegelentkopplung, wechselwirkender Kontinuumsgrenzwert, physikalischer Zustand, vollständige Kopplungen und universell gekoppelter quantisierter Spin 2 sind nicht gemeinsam konstruiert. Dies stimmt mit der aktuell gelesenen Datei `docs/OPEN_PROBLEMS.md` überein. Ein erneuter Gesamt-Lean-Lauf und eine vollständige externe Datenanpassung waren nicht Teil dieser Analyse.

**Die beiden Richtungen beantworten zunächst verschiedene Fragen.** Mit \(T\) als TFPT-Präsentation, \(U\) als vollständigem Prozess und \(P\) als Auslesung lautet die erste Richtung schematisch

\[
(T,\theta)\longmapsto U_{T,\theta}.
\]

Hier enthält \(\theta\) die bisher zusätzlichen Angaben: Kopplungen, Zustand, Kontextregel, Registerprotokoll, Zeitstruktur und gegebenenfalls Grenzwert. Die zweite Richtung lautet

\[
U\overset{P}{\longmapsto}T.
\]

Im ersten Fall entsteht eine Realisierung aus einer Beschreibung; im zweiten entsteht eine Beschreibung aus beobachtbaren Strukturen. Beide Richtungen können gleichzeitig gelten. Daraus folgt keine zeitliche oder ontologische Selbsterschaffung.

Für eine echte inverse Rekonstruktion müsste zusätzlich gelten:

\[
P(U_1)=P(U_2)\quad\Longrightarrow\quad U_1\simeq U_2,
\]

wobei \(\simeq\) Äquivalenz unter allen zugelassenen Experimenten bezeichnet. Die Registerzeugen widerlegen diese Aussage für die bloße Systemauslesung. Deshalb ist die Umkehrhypothese eine sinnvolle Deutung der Unvollständigkeit des Schattens, aber noch kein Beweis, dass TFPT ontologisch aus einem bestimmten tieferen Raum entsteht.

**Der Registerzeuge trägt, seine Reichweite muss präzise bleiben.** Im tatsächlichen Quellmodell besitzt die Vormessung \(U\) die Eigenschaft \(U^2=I\). Ein kohärent behaltenes Register und eine dephasierte Alternative können denselben sichtbaren Systemzustand \(I_4/4\) besitzen. Dieselbe Fortsetzung mit \(U\) liefert anschließend einmal einen reinen Zustand und einmal wieder \(I_4/4\). Daher gibt es auf diesem Schatten keine für alle diese inneren Zustände gültige autonome Entwicklung.

Das ist ein exakter Nachweis verlorener Vorhersageinformation. Er sagt nicht, dass jede TFPT-Auslesung nichtautonom ist: Für das ausdrücklich eingeschränkte Protokoll mit frischen Registern existiert eine autonome reduzierte Regel. Ebenso gelten auf dem ursprünglichen 60-Strahlen-Modell genau die Beziehungen

\[
CT=KC,\qquad FT=\frac37F.
\]

Es gibt hier drei unterschiedliche Klassen: Verteilungen über die bereits gemessenen 60 Strahlen; allgemeine klassische Kontext-Quanten-Zustände; und kohärente System-Register-Zustände. Aussagen zwischen diesen Klassen zu übertragen verursacht einen scheinbaren Widerspruch. Ein System kann auf der größeren Ebene einen vollständigen Zustand besitzen und auf der kleineren Ebene ein Prozess mit Gedächtnis sein. Der Befund erzwingt daher keinen Gegensatz zwischen „Zustandsraum“ und „Prozessraum“.

Dies ist eng mit der etablierten Theorie von Prozesstensoren verbunden. Dort wird ein Prozess durch seine Antworten auf Folgen von Eingriffen beschrieben, sodass auch Gedächtnis erfasst wird, das in einzelnen Dichteoperatoren nicht sichtbar ist. TFPT liefert hierfür einen konkreten kleinen Testfall; die allgemeine Idee ist bereits Teil der Theorie offener Quantensysteme. [Pollock et al., Operational Markov condition for quantum processes](https://arxiv.org/abs/1801.09811)

**Die behauptete Minimalität des vollen CQ-Zustands ist nicht bewiesen; für die im Folgenden festgelegte Auslesung ist sie zu stark.** Der Originalprüfer konstruiert zwei Zustände mit gleichen Marginalien und verschiedenen nächsten Marginalien. Damit widerlegt er eine bestimmte Kompression. Er untersucht nicht alle kleineren Beschreibungen.

Die konkrete CQ-Regel lautet

\[
(\mathcal L\sigma)_D=\sum_C K_{DC}\Delta_D(\sigma_C),
\qquad K=B/7,
\]

mit 15 positiven \(4\times4\)-Blöcken \(\sigma_C\), deren Spuren sich zu eins summieren. Der allgemeine CQ-Raum hat 240 reelle lineare Koordinaten, beziehungsweise affine Dimension 239 nach Normierung. Für einen festgelegten Ablauf ohne Eingriffe, bei dem für jeden Horizont getrennt nur System- und Kontextmarginalie ausgewertet werden, reicht jedoch eine kleinere Beschreibung.

Seien \(P_u\), \(u=1,\ldots,15\), die nichttrivialen Paulis und

\[
p_C=\operatorname{tr}\sigma_C,
\qquad a_{uC}=\operatorname{tr}(P_u\sigma_C),
\qquad x_u=\sum_C a_{uC}.
\]

Setze \(m_{uC}=1\), wenn Kontext \(C\) das Pauli \(P_u\) enthält, sonst null, und

\[
y_u=\frac17\sum_C(1+2m_{uC})a_{uC}.
\]

Die Quellinzidenz ergibt exakt

\[
\boxed{p'=Kp,\qquad x'_u=y_u,\qquad y'_u=\frac37y_u.}
\]

Begründung: Die Dephasierung in Kontext \(D\) erhält \(P_u\) genau dann, wenn \(m_{uD}=1\). Die 15 Kontextkoeffizienten eines Paulis entwickeln sich mit \(L_u=\operatorname{diag}(m_u)K\). Jedes Pauli liegt in drei Kontexten. Aus den tatsächlichen Quellmatrizen folgt

\[
\mathbf1^T L_u=\frac17(\mathbf1^T+2m_u^T),
\qquad
\mathbf1^T L_u^2=\frac37\mathbf1^T L_u.
\]

Die beiden Zeilen \(\mathbf1^T\) und \(\mathbf1^TL_u\) sind linear unabhängig. Zusammen mit den 15 unabhängigen Kontextspuren ergibt das einen beobachtbaren linearen Rang von \(15+2\cdot15=45\). Nach Normierung verbleiben **44 unabhängige reelle Größen**. Das ist die minimale affine lineare Beschreibung relativ zu genau diesen passiven Marginalausgaben; der positive Zustandsbereich ist das Bild der CQ-Zustandsmenge und kein beliebiger 44-dimensionaler Würfel.

Die Gegenprüfung benutzt auch positive Zustände. Für ein Pauli \(P\), das in zwei Kontexten \(C_0,C_1\) liegt, wähle

\[
\sigma_C^\pm=\frac{I_4}{60}\pm\frac{v_C}{120}P,
\qquad v_{C_0}=1,\quad v_{C_1}=-1,
\]

mit sonst \(v_C=0\). Alle Blöcke sind strikt positiv. Die beiden CQ-Zustände unterscheiden sich, besitzen aber dieselben \(p,x,y\) und damit dieselben hier betrachteten Marginalausgaben zu allen zukünftigen Zeiten.

Auf der bereits gemessenen Strahlenklasse gilt darüber hinaus \(y=(3/7)x\). Dort reichen 30 lineare beziehungsweise 29 normierte affine Koordinaten. Die 30 Nullrichtungen der 60-dimensionalen Übergangsmatrix werden tatsächlich ausgelöscht. Sie sind kein verstecktes Gedächtnis dieses Übergangs.

| Beschreibung | Lineare Dimension | Dimension nach Normierung | Gültigkeit |
|---|---:|---:|---|
| Allgemeiner CQ-Zustand | 240 | 239 | Beliebige positive Kontextblöcke |
| Bild nach einer CQ-Messrunde | 60 | 59 | Jeder Ausgangsblock diagonal in seinem Kontext |
| Vorhersagegrößen \((p,x,y)\) | 45 | 44 | Festes \(\mathcal L\), separat ermittelte Marginalien aller Horizonte |
| Strahlen-Marginalquotient \((p,x)\) | 30 | 29 | Bereits gemessene Strahlenklasse, dieselbe eingeschränkte Auslesung |

Diese Reduktion gilt ausdrücklich nicht für beliebige selektive Messgeschichten, Kontext-System-Korrelationen am selben Zeitpunkt oder kohärente Eingriffe in Register. Mit zusätzlichem Zugriff können zuvor unsichtbare Richtungen sichtbar werden. Die richtige Minimalitätsfrage lautet immer: minimal für welche Präparationen, Eingriffe und Ausgaben?

**Die kovariante Konstruktion von \(K=B/7\) ist korrekt, wählt die Regel aber nicht allein durch Symmetrie aus.** Der Follow-up-Prüfer zerlegt die siebenreguläre bipartite Inzidenzmatrix als \(B=\sum_{j=1}^7P_j\) und mittelt die sieben Permutationen mit gleichen Gewichten. Danach wird unter der Symplektikgruppe konjugiert. Weil \(B\) invariant ist, gilt bereits algebraisch

\[
\frac1{|G|\,7}\sum_{g\in G}\sum_jgP_jg^{-1}
=\frac1{|G|\,7}\sum_ggBg^{-1}=\frac B7.
\]

Die 4500 verschiedenen Orbit-Matchings sind interessante kombinatorische Daten dieser Zerlegung. Die Gleichgewichtung war jedoch schon in \(\frac17\sum_jP_j\) enthalten. Sie folgt nicht erst daraus, dass die Konjugationsgruppe 720 Elemente besitzt.

Ein explizites Gegenmodell zur Symmetrie-Eindeutigkeit ist

\[
K_{\mathrm{alt}}=\frac12I+\frac1{12}(B-I).
\]

Es ist stochastisch, besitzt denselben Inzidenzträger und dieselbe Symmetrie, unterscheidet sich aber von \(B/7\). Symmetrie kann den Selbstübergang und die sechs anderen inzidenten Nachfolger verschieden gewichten. Die Markierung \(a=1/7\) benötigt eine zusätzliche Auswahl, etwa die gleichgewichtete Matching-Ausführung, maximale Übergangsentropie oder das benannte Auslöschungsprinzip. Eine davon dynamisch aus der Quelle herzuleiten bleibt eine echte Aufgabe. „Zur Hälfte geschlossen“ ist hier keine mathematisch definierte Fortschrittsgröße.

**Der Hüllensatz für die Vierträgerzelle ist richtig, die physikalische Prämisse ist stärker als die E₈-Zerlegung.** Für einen Zustand auf \((\mathbb C^4)^{\otimes N}\) erzwingt die Bedingung

\[
\operatorname{supp}\rho_{ij}\subseteq\Lambda^2\mathbb C^4
\quad\text{für alle Paare}
\]

die totale Antisymmetrie. Denn jeder Swap hat auf dem Zustand Eigenwert \(-1\), und Transpositionen erzeugen die Permutationsgruppe. Für \(N=4\) bleibt das eindeutige Singulett

\[
|\Omega\rangle=\frac1{\sqrt{24}}\sum_{\pi\in S_4}
\operatorname{sgn}(\pi)|\pi(0,1,2,3)\rangle.
\]

Für \(N\ge5\) existiert kein solcher Zustand. Dass \(N=2,3\) ebenfalls antisymmetrische Zustände erlauben, zeigt zugleich: Genau vier Träger werden erst mit einer zusätzlichen Forderung wie maximaler Größe oder eindeutiger Singulettzelle ausgewählt.

In der E₈-Adjungierten tritt unter \(D_5\times A_3\) der Sektor \((10,6)\) auf; der symmetrische SU(4)-Zweiträgersektor \(10\) tritt in dieser Zerlegung nicht als entsprechender Bestandteil auf. Daraus folgt eine Auswahlregel für diese Adjungiertenstruktur und ihre Klammer. Es folgt nicht automatisch, dass im Hilbertraum zweier unabhängiger physischer Träger alle symmetrischen Zustände verboten sind. Dafür braucht man eine konkrete Zuordnung zwischen der Lie-Algebra-Zerlegung, physischen Freiheitsgraden und erlaubtem Zustandsraum.

Ein einfaches mathematisches Gegenbeispiel ist \(|0\rangle^{\otimes4}\): Es liegt im Träger-Tensorprodukt und ist für alle Paare symmetrisch. Die vorhandene SU(4)-Wirkung oder eine als Observable definierte antisymmetrisierende Klammer entfernt diesen Zustand nicht. Erst eine harte Einschränkung oder ein energetischer Mechanismus tut das.

Auch die Grundzustandskenntnis bestimmt die Dynamik nicht. Alle Hamiltonoperatoren

\[
H_{\mathbf J}=\sum_{i<j}J_{ij}\frac{I+S_{ij}}2,
\qquad J_{ij}>0,
\]

besitzen dieselbe eindeutige Vierträger-Nullmode \(\Omega\). Ihre Anregungsspektren unterscheiden sich. Als numerische Gegenprobe wurden die sechs Gewichte \(1,2,3,4,5,6\) verwendet: Der Grundzustand bleibt eindeutig, die Lücke beträgt etwa 3,847309 in diesen Einheiten; beim gleichgewichteten Modell beträgt sie 2. Die beiden Operatoren unterscheiden sich auch nach Herausrechnen einer gemeinsamen Skala.

Ein zusammenhängender, positiv gewichteter Austauschgraph auf vier Trägern genügt bereits für dieselbe Nullmode: Seine Kantentranspositionen erzeugen \(S_4\). Deshalb wählt der Grundzustand auch den vollständigen Sechs-Kanten-Graphen nicht aus. Bei mehr als vier über harte antisymmetrische Kanten verbundenen Trägern ist die gemeinsame Nullmode dagegen unmöglich. Vielzellenmodelle benötigen daher eine endliche energetische Strafe oder eine abgeschwächte Randbedingung an den Brücken.

**Die Präparation von \(\Omega\) benötigt im beschriebenen Qubit-Baukasten eine zusätzliche Ressource.** Seine Paarmarginalie lautet

\[
\rho_{ij}=\frac{I-S_{ij}}{12}
\]

und besitzt Rang 6 mit sechs Eigenwerten \(1/6\). Für einen reinen Stabilizer-Zustand ist jede Reduktion auf eine Qubit-Teilmenge ein normierter Stabilisatorprojektor; ihr Rang ist eine Zweierpotenz. Rang 6 schließt damit aus, dass \(\Omega\) ein reiner achtqubitiger Stabilizer-Zustand in der festgelegten Kodierung ist. Das folgt auch aus der bekannten ganzzahligen bipartiten Stabilizer-Entropie: Hier ist sie \(\log_2 6\). [Fattal et al., Entanglement in the stabilizer formalism](https://arxiv.org/abs/quant-ph/0406168)

Clifford-Gatter, Stabilizer-Präparationen und Pauli-Messungen mit klassischer Rückkopplung können diesen reinen Zustand folglich nicht exakt präparieren, auch nicht durch eine erlaubte Folge solcher Messungen mit Nachselektion. Man muss eine Ressource außerhalb dieser Klasse identifizieren. Kandidaten sind eine geeignete nicht-Cliffordsche kontinuierliche Austauschdynamik, eine andere Messoperation oder eine zusätzliche Zustandsquelle. Ein unitärer Swap ist selbst ein Clifford-Gatter; daraus folgt nicht, dass beliebige kontinuierliche Entwicklungen \(e^{-itS}\) oder eine Messung des Swap-Eigenwerts zur gleichen freien Operationsklasse gehören.

Das macht die offene Präparationsfrage schärfer: Sie ist im eingeschränkten Baukasten ein konkretes Hindernis, das durch bloßes weiteres Zusammensetzen derselben erlaubten Gatter nicht verschwindet. Diese Aussage ist relativ zur genannten Kodierung und Operationsklasse. Sie ist kein allgemeines Präparationsverbot für das Singulett.

**Die vorgeschlagene Superaustauschrechnung muss zwei Klammerkanäle auseinanderhalten.** Die direkte Wurzelprüfung bestätigt 960 geordnete Wurzelpaare für

\[
[(16,4),(16,4)]\longrightarrow(10,6).
\]

Für den gemischten Kanal gilt dagegen

\[
[(16,4),(\overline{16},\overline4)]
\longrightarrow(45,1)\oplus(1,15).
\]

Die unabhängige Enumeration ergibt hier 640 nichtverschwindende Wurzelsummen im ersten und 192 im zweiten Sektor; außerdem gibt es 64 Gegenwurzelpaare mit möglichem Cartan-Beitrag. Es gibt keinen \((10,6)\)-Zielsektor dieser gemischten Wurzelklammer. Das stimmt mit \(16\otimes\overline{16}=1\oplus45\oplus210\) und \(4\otimes\overline4=1\oplus15\) überein. Der nächste Schritt auf Seite 6 des Anschluss-Papers vermischt diese Kanäle und sollte vor einer effektiven Kopplungsrechnung korrigiert werden.

Ein kleiner konstruktiver Mechanismus lässt sich dennoch genau angeben. Sei \(P_-=\frac12(I-S)\) der antisymmetrische Zweiträgersektor. Ein Übergang \(W\) in einen Hilfssektor der Energie \(\Delta>0\), mit \(W^\dagger W=P_-\), erzeugt für die Kopplung \(g(W+W^\dagger)\) in zweiter Ordnung

\[
H_{\mathrm{eff}}=-\frac{g^2}{\Delta}P_-
=\frac{g^2}{\Delta}P_+-\frac{g^2}{\Delta}I.
\]

Bis auf die additive Konstante entsteht tatsächlich das Vorzeichen des Tetramer-Elternoperators. Das ist eine explizite hinreichende Konstruktion unter zusätzlichen Annahmen. Sie erklärt auch, warum Strukturkonstanten allein \(J\) oder \(\lambda\) noch nicht festlegen: Man benötigt die Kopplung \(g\), den Energieabstand \(\Delta\), den ausgewählten Hilfssektor und die Liste der gekoppelten Paare. Die Lie-Klammer kann die Form von Übergängen einschränken; diese Energie- und Graphdaten folgen daraus nicht ohne weitere Dynamik. [Bravyi, DiVincenzo und Loss, Schrieffer-Wolff transformation](https://arxiv.org/abs/1105.0675)

**Die Uhrfrage lässt sich konstruktiv verbessern.** Das Anschluss-Paper zeigt richtig, dass ein auf einem Träger angewendeter unitärer Tick am Singulett sichtbar wird:

\[
\langle\Omega|A_1|\Omega\rangle=\frac14\operatorname{tr}A,
\qquad
p_{1j}=\frac{16-|\operatorname{tr}A|^2}{24}.
\]

Die zweite Formel gilt in dieser Form für unitäres \(A\); bei einem allgemeinen nichtunitären Filter müssen Normierung und Erfolgswahrscheinlichkeit mitgeführt werden. Die Periode 3 in den Paartests ist ein reales endliches Lesemuster. Die Periode 12 eines gewählten Lifts benötigt eine relative Phasenreferenz. Beides setzt zunächst voraus, dass ein Tick angewendet wird; eine autonome Uhrendynamik folgt daraus noch nicht.

Die Inversionsnotiz findet für den gleichgewichteten System-Swap-Hamiltonoperator drei Energieniveaus. Ein stärkeres Argument erfasst unmittelbar den relevanten Zustandssektor: Auf \(\Lambda^3\mathbb C^4\) wirkt jede Systemtransposition als \(-I\). Die gesamte durch diese Permutationen erzeugte Algebra wirkt dort skalar. Deshalb kann keine aus dieser Algebra allein gewählte Dynamik die vier antisymmetrischen bedingten Zustände nichttrivial ineinander entwickeln. Ein allgemeines Uhrverbot folgt daraus nicht. Auch die Zahl unterscheidbarer Uhranzeigen ist außerhalb der dort gewählten idealen nichtentarteten Uhrklasse nicht einfach gleich der Zahl orthogonaler Energieniveaus.

Eine genaue Ergänzung derselben Zelle ist folgende. Schreibe

\[
|\Omega\rangle=\frac12\sum_{a=0}^3|a\rangle_C|\omega_a\rangle_S,
\]

wobei die \(\omega_a\) orthonormale antisymmetrische Zustände der übrigen drei Träger sind. Wähle dimensionslos

\[
h=\operatorname{diag}(0,1,2,3)
=\frac32I-Z_1-\frac12Z_2,
\qquad
H_S=h_1+h_2+h_3-6I.
\]

Da \(\omega_a\) genau die drei anderen Basiswerte enthält, gilt

\[
H_S\omega_a=-a\omega_a,
\qquad (h_C+H_S)\Omega=0.
\]

Definiere die vier Uhranzeigen durch die Fourierbasis

\[
|t_k\rangle=\frac12\sum_{a=0}^3i^{-ak}|a\rangle,
\qquad k=0,1,2,3.
\]

Jede Anzeige tritt mit Wahrscheinlichkeit \(1/4\) auf. Der normierte bedingte Systemzustand ist

\[
|\phi_k\rangle=\frac12\sum_{a=0}^3i^{ak}|\omega_a\rangle,
\]

und erfüllt exakt

\[
\boxed{e^{-iH_S\pi/2}|\phi_k\rangle=|\phi_{k+1\;\mathrm{mod}\;4}\rangle.}
\]

Die vier Zustände sind orthogonal. Der Gesamtzustand ist stationär, die bedingten Zustände besitzen eine genaue zyklische Schrödinger-Entwicklung. Das ist eine ausdrückliche Page-Wootters-Konstruktion auf der vorhandenen Zelle. Die Identitäten wurden symbolisch überprüft. Die allgemeine relationale Zeitidee ist etabliert; die hier angegebene Einbettung ist eine eigene Anwendung auf das untersuchte Singulett. [Moreva et al., Time from quantum entanglement](https://arxiv.org/abs/1310.4691)

Die Konstruktion fügt eine bevorzugte Basis, die äquidistanten Energien und ihre Koeffizienten hinzu. Dass \(h\) im linearen Raum der Quell-Paulis liegt, bedeutet nicht, dass der Compiler gerade diese Linearkombination als Hamiltonoperator auswählt. Eine Energieskala \(\varepsilon\) würde den Schritt zu \(\Delta t=\pi\hbar/(2\varepsilon)\) machen; \(\varepsilon\) ist nicht hergeleitet. Dies ersetzt auch nicht unbemerkt die ursprüngliche volle Tetramer-Dynamik. Es ist eine alternative ergänzte Zwangsdynamik, die denselben Zustand trägt. Der Fortschritt lautet: Die Uhr ist explizit konstruierbar; ihre Quellauswahl bleibt offen.

**Irreversibilität und Vielzellenphysik benötigen getrennte Grenzwertaussagen.** Der Beweis gegen exaktes nichttriviales exponentielles Abklingen in einem geschlossenen endlichen Quantensystem mit festem unitärem Schritt ist korrekt. Eine Erwartungswertfolge ist eine endliche Summe von Phasen. Nach Zusammenfassung gleicher Frequenzen besitzt ihr mittleres Betragsquadrat einen positiven Cesàro-Grenzwert, sofern die Folge nicht identisch null ist. Eine echte \((3/7)^n\)-Dämpfung für alle \(n\) verlangt somit einen offenen Nachschub, einen unbeschränkten Grenzprozess oder eine andere Erweiterung dieser Voraussetzungen.

Die Rückkehr nach \(2m\) Schritten ist eine exakte Eigenschaft der hier untersuchten zyklischen Wiederverwendung von \(m\) Registern bei der festgelegten Vormessung im selben Kontext. Sie ist kein allgemeines Gesetz „Gedächtnis gleich Rekurrenzzeit“. Andere Kopplungen und Spektren können andere oder nur näherungsweise Rekurrenzen besitzen. Ebenso ist die Nichtumkehrbarkeit eines reduzierten Kanals noch keine Auswahl des kosmischen Anfangszustands oder eines thermodynamischen Zeitpfeils.

Die offene SU(4)-Kettenrechnung des Anschluss-Papers wurde reproduziert. Die angegebenen Lücken für zwei, drei und vier Vierersegmente erscheinen erneut. Zwei Einschränkungen sind für ihre Bewertung wesentlich: Erstens wechselt das Paper vom vollständigen Sechs-Kanten-Tetramer zu Vierersegmenten mit nächsten Nachbarn; damit ändert sich der Hamiltonoperator. Zweitens untersucht der Prüfer bei 16 Trägern eine ausgewählte Familie von Darstellungen, die aus den kleineren Ketten motiviert wurde. Der dort ausgegebene erste Anregungswert ist ohne zusätzlichen Ausschlusssatz nicht als global über alle Darstellungen zertifiziert.

Die SU(4)₁-WZW-Zuordnung des uniformen Kettenmodells ist fachlich plausibel und passt zu etablierter Spin-Ketten-Literatur. Die endlichen Spektren stützen diese Zuordnung. Sie beweisen aus den wenigen Größen allein weder eine thermodynamische Lücke für jedes \(\lambda<J\) noch eine neue TFPT-Kontinuumstheorie. Die größere Ringrechnung und eine neue vollständige Skalierungsanalyse wurden hier nicht wiederholt. [Führinger et al., DMRG studies of critical SU(N) spin chains](https://arxiv.org/abs/0806.2563)

**Die Rückrichtung zur E₈-Hülle kann exakt geschlossen werden, sobald die markierten Faktoren gegeben sind.** Man kann den \(A_3\)-Faktor als \(D_3\) im euklidischen \(\mathbb R^3\) realisieren. Beginne mit

\[
L_0=D_5\oplus D_3\subset\mathbb R^5\oplus\mathbb R^3,
\qquad
g=(\tfrac12,\ldots,\tfrac12)\in\mathbb R^8,
\]

und setze

\[
L=L_0+\mathbb Zg.
\]

Die Klasse von \(g\) hat Ordnung 4 modulo \(L_0\). Das Skalarprodukt mit \(L_0\) ist ganzzahlig, und \(g^2=5/4+3/4=2\). Deshalb ist \(L\) gerade und ganzzahlig. Sein Index über \(L_0\) ist 4 und

\[
\det L=\frac{\det D_5\,\det A_3}{4^2}=\frac{4\cdot4}{16}=1.
\]

Das ist die positive gerade unimodulare Rang-8-Hülle E₈. Explizit besteht ihr ganzzahliger Teil aus den D₈-Vektoren und ihr halbzahliger Teil aus der zugehörigen Spinorklasse. Die Wurzeln lassen sich nachrechnen: 40 aus D₅, 12 aus D₃, 60 gemischte ganzzahlige und 128 halbzahlige Wurzeln, zusammen 240. Die Cartanrichtungen ergänzen auf 248.

Auch die konforme Zielstruktur ist konkret. Bei Niveau 1 lauten die zentralen Ladungen

\[
c(D_5)=\frac{45}{1+8}=5,\qquad
c(A_3)=\frac{15}{1+4}=3,\qquad
c(E_8)=\frac{248}{1+30}=8.
\]

Für die gekoppelten Spinorfelder ergänzen sich die Gewichte zu \(5/8+3/8=1\); für Vektor und antisymmetrischen Zweiträger zu \(1/2+1/2=1\). Die vier passenden \(\mathbb Z_4\)-Klassen organisieren die lokale Gittererweiterung. Auf Stufe 1 erscheinen genau

\[
(45,1)\oplus(1,15)\oplus(16,4)
\oplus(\overline{16},\overline4)\oplus(10,6).
\]

Dies ist eine echte gegenseitige algebraische Rekonstruktion der markierten Hülle und ihrer Faktoren. Ihre Ausgangsannahmen dürfen jedoch nicht verschwinden: D₅, A₃, Metrik, Markierungen und die passende lokale Verklebung sind gegeben. Weder \(c=8\) noch eine Vierträgerzelle allein wählt sie aus.

Zudem erzeugt eine gewöhnliche kritische SU(4)-Kette typischerweise eine nichtchirale 1+1D-Feldbeschreibung mit beiden Bewegungsrichtungen. Der Übergang zu einer bestimmten holomorphen E₈-Naht verlangt die Auswahl der Chiralität und der lokalen Erweiterung. Zehn zusätzlich postulierte Majorana-Moden liefern dafür einen möglichen D₅-Zielsektor; ihre bloße Hinzufügung ist keine Herleitung ihrer Herkunft. Das 3+1D-Raumzeitproblem bleibt nochmals gesondert.

**Eine universelle Rekonstruktion lässt sich als präziser mathematischer Auftrag formulieren.** Man beginne nicht mit einem unbestimmt großen Raum, sondern mit einer vollständigen Liste zulässiger Präparationen, Operationen, Zusammensetzungen und Ausgaben. In einer quantenmechanischen Realisierung seien \(\mathfrak A\) die Observablenalgebra, \(\rho\) der Anfangszustand und \(\mathcal I_{a|x}\) die Operation zum Ergebnis \(a\) bei gewähltem Experiment \(x\). Dann definiert

\[
p(a_1,\ldots,a_n\mid x_1,\ldots,x_n)
=\operatorname{tr}\!left[
\mathcal I_{a_n|x_n}\circ\cdots\circ
\mathcal I_{a_1|x_1}(\rho)\right]
\]

die Prozessstatistik. Verdeckte Register werden dabei in den gemeinsamen Zustand aufgenommen. Adaptive Entscheidungen können als Teil des Experiments mitgeführt werden.

Zwei Zustände oder Vorgeschichten werden identifiziert, wenn jede erlaubte Fortsetzung dieselben Ergebniswahrscheinlichkeiten liefert:

\[
h\sim h'
\quad\Longleftrightarrow\quad
p(f\mid h)=p(f\mid h')\quad\text{für jede erlaubte Zukunft }f.
\]

Die Fortsetzungen müssen unter weiterer Zusammensetzung geschlossen sein; für quantenmechanische Vollständigkeit werden gegebenenfalls auch erlaubte Hilfssysteme mitgeführt. Der Quotient ist die kanonische operationelle Beschreibung relativ zu diesem Experimentbestand. Er bewahrt genau die Information, die irgendeine zugelassene Zukunft noch unterscheiden kann. Er setzt nicht voraus, dass die physische Welt aus klassischen Vorgeschichten besteht.

Im endlichen linearen Fall ist diese Definition konstruktiv berechenbar. Man startet mit dem linearen Raum der Auslese-Effekte und erweitert ihn wiederholt durch alle adjungierten zulässigen Operationen:

\[
V_0=\operatorname{span}(\text{Auslese-Effekte}),
\qquad
V_{k+1}=V_k+
\operatorname{span}\{\mathcal I^*(E):E\in V_k\}.
\]

Sobald sich der Raum nicht mehr vergrößert, ist \(V_\infty\) der vollständige Raum der unterscheidenden linearen Zukunftstests. Zwei Zustände sind genau dann operationell gleich, wenn sie auf allen Effekten dieses Raums übereinstimmen. Der Annihilator enthält die unsichtbaren Zustandsunterschiede; die duale Quotientenbeschreibung ist autonom. Die oben berechneten 45 und 30 linearen Dimensionen sind konkrete eingeschränkte Instanzen dieses Verfahrens.

Für allgemeine Mehrzeitprozesse ist die entsprechende quantenmechanische Beschreibung eine konsistente Familie positiver Prozesstensoren beziehungsweise Quantenkämme. Die Positivität und kausalen Normierungsbedingungen sind wesentlich. Das Entfernen einer Zeitstelle erfolgt durch Einsetzen einer Identitätsoperation; das bloße Summieren über Messergebnisse kann eine störende Messung zurücklassen. Geeignete Konsistenzbedingungen erlauben eine Erweiterung auf einen umfassenderen Prozess. Sie wählen keine eindeutige unbeobachtbare Umweltmikroskopie. [Chiribella et al., Theoretical framework for quantum networks](https://arxiv.org/abs/0904.4483), [Milz et al., Kolmogorov extension theorem for causal modelling](https://arxiv.org/abs/1712.02589)

Damit erhält man eine gemeinsame Definition des Kandidaten:

\[
\mathcal U_{\mathrm{op}}=
\bigl(\text{komponierbare Operationen},\;
\text{positive konsistente Prozessstatistik}\bigr)/\!\sim.
\]

TFPT kann eine markierte Präsentation eines Teils dieser Struktur liefern. Eine freie Erweiterung seiner Generatoren und Relationen beschreibt zunächst eine Klasse von möglichen Realisierungen. Die positive Statistik und die physisch erlaubte Komposition wählen daraus erst einen bestimmten operationellen Prozess. In einer kategorischen Formulierung muss die Beobachtungsäquivalenz alle zulässigen Einbettungen in größere Experimente berücksichtigen, damit sie mit Zusammensetzung verträglich ist.

Die beiden Pfeile schließen sich dann in einer präzisen Form: Aus \(U\) gewonnene vollständige Operations- und Prozessdaten rekonstruieren \(U\) bis auf operationelle Äquivalenz. Aus unvollständigen Daten rekonstruieren sie die Klasse kompatibler Erweiterungen. Die Bedingung für eine eindeutige physische Auswahl ist ein zusätzlicher Satz über diese Klasse; sie ist nicht durch die Definition des Quotienten erledigt.

Allgemeine Quantenrekonstruktionen aus Informationsprinzipien zeigen, wie man Hilbertraumstruktur mit zusätzlichen operationellen Annahmen begründen kann. Sie benötigen konkrete Prinzipien, etwa Kausalität, Unterscheidbarkeit, Kompression, lokale Unterscheidbarkeit, reine Konditionierung und Purifikation im betreffenden Rahmen. „Veränderungen sind miteinander verbunden“ allein enthält diese Auswahl nicht und erzwingt weder komplexe Quantenmechanik noch E₈. [Chiribella, D’Ariano und Perinotti, Informational derivation of Quantum Theory](https://arxiv.org/abs/1011.6451)

**Teilsysteme können innerhalb dieses Rahmens aus Beziehungen rekonstruiert werden.** Im endlichen algebraischen Fall liefern hinreichend große, miteinander kommutierende Matrixfaktoren, die gemeinsam die Gesamtalgebra erzeugen, eine Tensorproduktzerlegung bis auf die üblichen unitären Äquivalenzen und Umbenennungen. Mit nichttrivialem Zentrum oder unvollständigem Zugriff bleibt eine direkte Sektorzerlegung beziehungsweise weitere Mehrdeutigkeit. Die klassische Referenz hierfür ist die beobachtungsinduzierte Tensorproduktstruktur. [Zanardi, Lidar und Lloyd](https://arxiv.org/abs/quant-ph/0308043)

Die Enumeration der 105 Qubit-Paarungen passt dazu: Innerhalb dieser endlichen Klasse erkennt die Zwei-Körper-Struktur der sechs Swaps eine einzige Paarung. Sie ist jedoch keine Enumeration aller Faktorisierungen des 256-dimensionalen Hilbertraums. Außerdem bleibt zu begründen, weshalb gerade die verwendeten Wechselwirkungen die privilegierten physikalischen Beziehungen sind. Ein einzelner Zustand reicht hierfür im Allgemeinen nicht.

**Der Lorentzkegel ist eine genaue geometrische Teilrekonstruktion.** Sobald ein markierter \(M_2(\mathbb C)\)-Block samt hermitescher Struktur und positivem Kegel gegeben ist, gilt

\[
H=\begin{pmatrix}t+z&x-iy\\x+iy&t-z\end{pmatrix},
\qquad
\det H=t^2-x^2-y^2-z^2,
\]

und \(H\succeq0\) entspricht \(t\ge\sqrt{x^2+y^2+z^2}\). Die Kongruenz \(H\mapsto AHA^\dagger\), \(A\in SL(2,\mathbb C)\), erhält diese Form. Diese etablierte Spinor-Lorentz-Struktur ist in den Unterlagen konkret anschließbar. Sie rekonstruiert eine Kinematik des ausgewählten Blocks. Für Raumzeit fehlen die Zuordnung solcher Blöcke zu Ereignissen oder Regionen, eine kausale Lokalitätsstruktur, geometrische Skalen, ein geeigneter Grenzwert und eine gemeinsame Dynamik. Insbesondere ist die Dimension eines internen Viererträgers kein Beweis für vierdimensionale Raumzeit.

Für eine umfassende Theorie müsste die Prozessstruktur deshalb zusätzliche, quellenseitig bestimmte Daten liefern: lokale Observablen, verträgliche Überlappungen, Ausbreitungsregeln und die Auswahl eines physikalischen Zustands. Erst daraus wäre zu prüfen, ob eine vierdimensionale Lorentzgeometrie mit universeller Materiekopplung entsteht. Der vorhandene Lichtkegel macht dieses Ziel mathematisch konkret; er löst es nicht allein.

Die weiteren Anschlussbefunde fügen sich in dieselbe Logik. Eine Hamiltonoperator-Rekonstruktion \(H\to\psi\to H\) innerhalb einer festgelegten Operatorliste prüft Identifizierbarkeit; sie ist keine unabhängige Vorhersage des ursprünglichen \(H\). Kleine Varianzen für HH-Hop und \(E^4\) zeigen dort fehlende Empfindlichkeit des untersuchten niedrigen Energiesektors. Die Zweischleifen-Protonzerfallsrechnung ist im Paper ein bedingtes negatives Resultat des gaugeten SO(10)-Zweigs; sie wurde hier nicht erneut gerechnet und darf die Universalraum-Rekonstruktion nicht als schon gelöst voraussetzen. Die Unterscheidung innerer Glue-\(\mathbb Z_4\) und geometrischer Rotation ist wichtig: Ihre verschiedenen Spuren schließen die behauptete Operatorgleichheit aus. Eine Indexgleichheit beim Hecke-/Jones-Anschluss beschreibt eine Inklusion; sie bestimmt für sich allein keinen physikalischen Zeitgenerator.

**Der nächste entscheidende Herkunftstest betrifft die Operation, die die Zelle tatsächlich herstellen kann.** Es ist sinnvoll, den folgenden zusammenhängenden Nachweis anzustreben:

1. Die primitive TFPT-Operationsklasse und ihre zulässige Verbindung zwischen Trägern werden vollständig festgelegt. Dabei wird jede Ressource außerhalb des Stabilizer-Baukastens benannt.
2. Aus dieser Quelle wird ein Übergang zu einem bestimmten Zwischenzustandssektor mit Energieabstand und Kopplung konstruiert. Die beiden E₈-Klammerkanäle werden dabei korrekt getrennt.
3. Derselbe Mechanismus erzeugt die effektive Paarwechselwirkung und ein physisch ausführbares Präparationsverfahren für \(\Omega\), einschließlich Umwelt- oder Messressourcen.
4. Daraus wird eine vorher festgelegte Mehrzeitstatistik berechnet, die alternative Lifts oder Registerprotokolle unterscheidet.
5. Mindestens eine Auslesung wird vorher eingefroren und anschließend aus diesem Ursprung berechnet, ohne die Zusatzparameter am Zielwert nachzustellen.

Ein Scheitern von Schritt 1 oder 2 ist informativ: Dann enthält die bisherige Quelle die erforderliche Ausführung noch nicht. Ein Gelingen wäre stärker als weitere Symmetrie- oder Spektralübereinstimmungen, weil es die bislang fehlende Ursache mit dem beobachtbaren Effekt verbindet. Die konkrete Uhrkonstruktion kann anschließend prüfen, ob diese neue Dynamik die erforderlichen relativen Energien auswählt oder eine andere, ebenfalls messbare Zeitstruktur erzeugt.

Die umfassende Beweislast bleibt dabei sichtbar:

| Tor | Erforderliche Schließung | Ergebnis dieser Analyse |
|---|---|---|
| T1 | Herkunft von Rand-, Träger- und Auswahlannahmen | Mehrdeutigkeit der bisherigen Auswahl konkretisiert |
| T2 | Tatsächliches markiertes Nahtfeld mit Skalierungslimes und analytischer Kontrolle | E₈-Zielhülle algebraisch rekonstruierbar; Quellfeld nicht hergeleitet |
| T3 | Ein ausgewählter lokaler/quasilokaler unitärer Ursprung in 3+1D | Endliche Ausführung und ihre Zusatzressourcen präzisiert |
| T4 | Chirales Standardmodell, Anomalien, Spiegelentkopplung | Keine neue Schließung |
| T5 | Wechselwirkender Kontinuumsgrenzwert | Endliche Kettendaten bestätigt, Gültigkeitsbereich eingegrenzt |
| T6 | Vollständige interne Kopplungen und Neutrinostruktur | Formelwerte nachgerechnet, Herkunftsbrücke unverändert offen |
| T7 | Quantisierter masseloser Spin 2 und universelle Kopplung | Lorentzkegel als Teilstruktur eingeordnet |
| T8 | Physikalischer Zustand und gemeinsames Auslesefunktional | Präparationshindernis, operationelle Rekonstruktion und bedingte Uhr konstruiert |

Die wissenschaftlich stärkste Fassung beider Ideen lautet damit: **Ein gemeinsamer komponierbarer Prozess trägt die beobachtbare Struktur; TFPT gibt dafür eine markierte algebraische Präsentation. Vollständige Prozessdaten erlauben eine Rückrekonstruktion bis auf operationelle Äquivalenz. Die Auswahl gerade des physikalischen Prozesses verlangt zusätzliche, überprüfbare Herkunftssätze.**

Die in dieser Analyse ausgeführten Berechnungen sind im begleitenden JSON getrennt nach Originalreplay, eigener exakter Gegenprüfung, numerischer Gegenprobe und nicht erneut geprüften Aussagen dokumentiert. Die ursprüngliche Inversionsprüfung liefert 325 Checks, die Follow-ups 147; alle 19 zugehörigen Tests bestehen. Der ausgewählte Anschlussprüfer für Hüllensatz, Klammer, Tick-Lifts und offene Ketten läuft erfolgreich. Die eigene Rekonstruktionsprüfung umfasst 86 Bedingungen. Keine dieser Zahlen ist eine Zahl unabhängiger physikalischer Bestätigungen. Die wesentlichen neuen Belege sind die expliziten Formeln, Gegenmodelle und ihre ausgewiesenen Voraussetzungen.
