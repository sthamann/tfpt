# Der gesuchte Austausch – einfach erklärt

## Was ich gefunden habe

Es gibt jetzt einen ausdrücklich beschriebenen ursprünglichen inneren Prozess, der alle fünf verlangten Bestandteile zusammenbringt: **Anfangszustand, Gegenstelle, Rückweg, Ladungsbilanz und kohärente Aufzeichnung.** Außerdem steht ein räumlicher Austauschbaustein bereits in einem älteren TFPT-Modell. Für dessen Verbindung zur neuen lokalen Bank konnte ich zusätzliche Aussagen herleiten.

Die noch offene Stelle ist sehr konkret: Wir wissen noch nicht, welche ursprüngliche Compileroperation diesen Austausch zwischen zwei neuen Banken erzeugt. Der folgende Prozess ist deshalb eine mathematisch konsistente, geprüfte Erweiterung. Seine ursprüngliche Herkunft ist noch nicht bewiesen.

## Zuerst: Der ursprüngliche innere Austausch ist bereits da

Innerhalb der Bank gibt es zwei operational verschiedene Teile: Fermionen und Bosonen. Ein vorhandener Term verwandelt ein Fermionpaar in ein Boson; sein Adjungiertes kehrt das um. Die Gesamtladung bleibt erhalten, weil ein Boson hier zwei Ladungseinheiten trägt.

Für einen ausdrücklich vorbereiteten passenden Paarzustand lässt sich dieser Vorgang exakt lösen. Bei den unveränderten Modellparametern erreicht die Boson-Besetzung maximal **2/27, also 7,4074 %**. Diese vorbereitete Zweiladungs-Situation ist nicht der wirkliche Grundzustand mit Ladung 64.

Auch auf dem wirklichen Grundzustand ist der Austausch kohärent vorhanden: Seine negative Wechselwirkungsenergie beweist das. Weil der Grundzustand stationär ist, entsteht daraus kein mittlerer gerichteter Strom. Würde man die Bosonenzahl vollständig messen und das Ergebnis ignorieren, ginge die betreffende Kohärenz verloren; die mittlere Energie stiege nachweislich um **zwischen 1,972482 und 2,403745 Δ**.

Die Kanalaufzeichnung ist besonders aufschlussreich: Acht innere Fermionpaarbeiträge führen zum selben Boson und können deshalb interferieren. Ein Register, das die acht Beiträge auseinanderhält, verändert diesen Prozess.

**Dieser Austausch benötigt keinen neuen Hamiltonterm. Aber die beiden Teile sind damit noch keine räumlichen Orte.** Für die räumliche Verbindung folgt nun die ausdrücklich gekennzeichnete Erweiterung.

## 1. Zwei Teile und eine Verbindung

Man nimmt zwei Kopien der tatsächlich untersuchten Bank. Jede besitzt zunächst ihren bekannten Grundzustand. Dazwischen liegt ein quantenmechanisches Verbindungsregister.

Beim Übergang geschieht gleichzeitig:

| Linke Bank | Verbindung | Rechte Bank |
|---|---|---|
| verliert ein Fermion | Fluss steigt um eins | nimmt ein Fermion auf |

Die Umkehrung benutzt genau den adjungierten Operator. Dabei sinkt der Fluss wieder. Es wird keine Ladung erzeugt oder vergessen.

Mathematisch lautet der Austausch

\[
B=\sum_{r=1}^{64}f_{y,r}^{\dagger}U f_{x,r}.
\]

Das Verbindungsregister ist Teil des Quantenzustands. Dadurch kann der gesamte Austausch kohärent bleiben.

## 2. Der neue Grundzustand kann tatsächlich etwas aufnehmen

Das ist der wichtigste neue Anschluss an die vorhandene Rechnung.

Die lokale Bank ist im Grundzustand nicht starr bis zum letzten Fermionplatz gefüllt. Ein kleiner Teil der Belegung steckt in bosonischen Paaren. Deshalb besitzt die andere Bank freie Aufnahmeanteile.

Aus genau dieser bereits bestimmten Struktur folgt für den ersten gerichteten Übergang:

\[
\|B\Psi_0\|^2=2\bar b-\bar b^2/16,
\quad1.64129<\|B\Psi_0\|^2<2.39434.
\]

**Der Übergang verschwindet also nicht.** Das ist keine ausgedachte Näherung für den Grundzustand. Die Formel folgt aus dessen vorhandenen Symmetrien und Besetzungsgrenzen. Sie ist auch keine Wahrscheinlichkeit über eins: Es ist das Normquadrat eines nicht auf eins normierten Übergangsoperators; zur Anfangswahrscheinlichkeit kommen Kopplungsstärke und Zeit hinzu.

Aus zwei identischen Grundzuständen entstehen zunächst gleichberechtigte Fluktuationen in beide Richtungen. Für gerichteten Transport muss der Anfangszustand eine Richtung beziehungsweise eine Anregung vorgeben.

## 3. Warum die Gegenstelle eine eigene Rolle spielt

Eine Bank kann ein Fermion günstig abgeben. Das ist der schon bekannte niedrige Entnahmeton. Die andere muss dasselbe Fermion aber auch aufnehmen können.

Deshalb setzt sich die Energie des gemeinsamen Vorgangs zusammen aus

**Entnahmeenergie + Aufnahmeenergie + Energie des Verbindungsflusses.**

Die beiden lokalen Antworten lassen sich exakt zu einer gemeinsamen Austauschverteilung zusammenführen. Im neutralen Zwei-Banken-Versuch liegt deren Schwelle oberhalb von

\[
0.337373\Delta+\kappa/2.
\]

Der niedrige Ton allein erklärt daher noch nicht den Austausch aus zwei Grundzuständen.

Ist schon ein niedriges „Loch“ vorhanden, erhält man dagegen einen klaren Transportansatz: Der projizierte Übergang wird mit dem bekannten Polgewicht \(Z\) multipliziert. Dieses ist größer als 0,880076. Wie zuverlässig die volle Entwicklung im niedrigen Raum bleibt, muss separat geprüft werden. Ein einzelnes Loch braucht außerdem eine erklärte äußere Gegenladung oder einen entsprechend geänderten Ladungshintergrund.

## 4. Die Aufzeichnung darf die inneren Alternativen nicht verraten

Die Verbindung darf festhalten, wie viel Ladung übertragen wurde. Sie darf aber nicht ohne Weiteres die beiden inneren Austauschmöglichkeiten auseinanderhalten, deren Interferenz erhalten bleiben soll.

Wenn beide Möglichkeiten denselben relevanten Registerzustand hinterlassen, bleibt ihre Interferenz erhalten. Wenn zwei eindeutig unterscheidbare Einträge entstehen, verschwindet sie beim Ignorieren des Registers.

Auch räumlich verschiedene Wege sind gesondert zu prüfen: Ein zusätzlicher Umlauf kann im Linkregister eine andere Spur hinterlassen. „Alles aufzeichnen“ garantiert deshalb noch keine passende History.

## 5. Ein tatsächlicher Austauschlauf ist bereits gelungen

Den Austausch im älteren räumlichen Quellmodell habe ich vollständig erneut berechnet. Dort gibt es zwei Orte mit jeweils zwei Fermionsorten. Durch die Ladungsbedingungen ist der gesamte physikalische Raum des offenen Zwei-Orte-Systems nur sechs-dimensional. Eine künstliche Flussgrenze wurde nicht benutzt.

Aus einer ausdrücklich vorbereiteten Anfangsbelegung ergibt sich:

| Zeit in den Einheiten dieses Modells | Wahrscheinlichkeit am vorgesehenen Ziel |
|---:|---:|
| 1 | 0,6925 % |
| 12 | 70,7587 % |
| 19 | **99,8718 %** |

Die vollständige Zeitentwicklung wurde mit exakten rationalen Zwischenrechnungen und mathematischer Restabschätzung geprüft. Diese Zahl gilt für das ältere Zwei-Orte-Modell und seinen vorbereiteten Zustand. Sie ist keine neue Transportmessung der 64-Fermion-Bank.

## 6. Warum das noch nicht der gemeinsame Ursprung ist

Die bislang betrachteten lokalen Operationen ändern die Fermionzahl jeder Bank nur um gerade Beträge. Der gesuchte Austausch ändert sie links und rechts jeweils um eins.

Aus ausschließlich diesen lokalen Operationen und reinem Bosonentransport kann der erforderliche Einzeltransfer deshalb nicht entstehen. Eine größere ursprüngliche Operationsmenge könnte ihn enthalten – aber genau die entsprechende Operation muss jetzt gefunden und nachgewiesen werden.

Der Fortschritt ist: Wir kennen nun einen konkreten funktionsfähigen Austausch und wissen, wie die neue Bank daran anschließt. Die fehlende Stelle ist nicht mehr nur „irgendwie Raum erzeugen“, sondern ein bestimmter bankübergreifender Operator mit nachprüfbarer Ladungs- und Kohärenzwirkung.

## 7. Was das für die arithmetische Erweiterung bedeutet

Endlich viele Banken mit endlich vielen elektrischen Verbindungen besitzen weiterhin zu wenige Zustände, um denselben Hamiltonoperator mit dem vollständigen Spektrum \(\log n\) für alle ganzen Zahlen zu identifizieren.

Unendlich viele identische Kopien lösen das nicht automatisch: Dieselbe Anregung könnte dann an unendlich vielen Orten mit derselben Energie sitzen. Die globale thermische Spur wäre dadurch unendlich.

Eine bekannte mathematisch passende Alternative verwendet wachsende Primmoden mit Energien \(\log p\). Sie berücksichtigt die nötige Zustandszahl, setzt aber die Primstruktur zusätzlich voraus. Damit sind weder ihr nativer Ursprung noch eine effiziente Faktorisierung gefunden.

## Das belastbare Ergebnis

**Der innere Austausch ist im ursprünglichen Modell exakt identifiziert. Ein räumlicher Anschluss ist als konkretes Modell konstruiert, in einer vorhandenen räumlichen Quelle ausgeführt und mit dem neuen nativen Grundzustand durch exakte Formeln verbunden.**

**Der nächste notwendige Beweis ist die Erzeugung des räumlichen Austauschs durch eine tatsächliche ursprüngliche Operation.** Gemeinsamer Ursprung, Gravitation und effiziente native Faktorisierung bleiben offen. Der ausführliche Bericht enthält alle Voraussetzungen, die neuen Ableitungen und die Grenzen der 753 ausgeführten Prüfbedingungen.
