# TFPT / Universalraum - Update v1.6.7

15. September 2026. Ausschließlich Änderungen gegenüber v1.6.6.

## Vier statt einer Richtung - jetzt konstruiert

Der vollständige Singulettbereich im N=64-Sektor bei zwei Bosonen besitzt
exakt vier Dimensionen. Der fertige neue Worker-Bericht und unsere unabhängige
Charakterrechnung stimmen überein. Die Typen auf der Bosonseite sind
(54,1), (1,20'), (54,20') und (45,15). Durch Projektion des frisch berechneten
nativen Zustands v2 erhält man alle vier Basisrichtungen.

Ihre quadrierten Kopplungen vom Ein-Boson-Singulett betragen
\(g^2(36,16,504,360)\). Die Summe ist \(916g^2\). Der ganze Bereich bis
Bosonstufe zwei ist damit ein exakt bestimmter Sechszustands-Ausschnitt:
eine helle Dreierkette und drei nach unten dunkle Richtungen. Höhere
Bosonstufen bleiben angekoppelt; der Ausschnitt ist keine vollständige Lösung.

## Die richtige einfache Kette und eine neue Energiegrenze

Die Lanczos-Kette der Wiederholungen des ganzen H vermeidet die falsche
Annahme, ein Kettenschritt sei identisch mit einer Bosonzahl. Neu bestimmt:

\[
b_4^2/g^2=78877653/47632,\qquad
a_4/\Delta=105168998/26292551.
\]

Der vierte neue Vektor enthält sowohl die Stufe vier als auch den bekannten
Seitenzweig auf Stufe zwei. Die ersten fünf Kettenglieder bestimmen die
zehn Energiemomente \(\langle F,H^nF\rangle\), n von 0 bis 9, exakt.
Dies sind Momente der gefüllten Referenz, nicht die geladenen Momente des
Grundzustands.

Eine rationale Eigenwerteinschließung liefert
\(E_0<-1.12963811\Delta\). Mit dem früheren N=63-Floor folgt
\(\epsilon>0.00773911\Delta\). Das verbessert die frühere untere
Polgrenze 0.007737 geringfügig; Polgewicht und obere Polgrenze werden
dadurch nicht verändert. Die vier-Boson-Norm bleibt ein früherer exakter
Eingang, nicht eine in dieser Runde frisch wiederholte Enumeration.

## Der bilineare Rest ist vollständig zerlegt

\[
\operatorname{End}(16\otimes4)=
(1,1)\oplus(45,1)\oplus(210,1)
\oplus(1,15)\oplus(45,15)\oplus(210,15).
\]

Die 4035 zuvor unbestimmten Komponenten sind 210 plus 675 plus 3150.
Die Zerlegung ist innere Darstellungstheorie, keine neue Teilchenzählung.
Sie wurde durch Clifford-Gram und Weyl-Multiplizitäten abgesichert.

## Korrekturen und Reichweite

- Der Clock liegt in Spin(10). Nichtskalare Wirkung widerlegt diese
  Zugehörigkeit nicht; die gegenteilige Eingabe wird korrigiert.
- Die zusätzlichen SU(4)- und Spin(10)-Stufen haben im N=3-Sektor die
  Kommutantdimensionen 2247168 und 1648. Verfügbarkeit ist nicht binär.
- Volle Gruppe plus alle Besetzungen erzeugt bedingt die volle Sektoralgebra.
  Ohne gewährte Gruppenoperationen bleibt trotz Besetzungsauslese eine
  nichtskalare Cartan-Erhaltung. Eine Auslese ist noch kein Transferinstrument.
- Drei Feldkanäle mit Normquadrat 64 ergeben Normquadrat 192 und Norm
  \(8\sqrt3\), nicht 24. Ein Projektorranganteil von einem Drittel ist
  kein universelles Spektralgewicht.
- Der fertig eingefrorene Grundzustandsbericht meldet 379 exakte und drei
  numerische Guards. Seine schwächeren Sektorschranken widerlegen den
  stärkeren früheren Grundzustandssatz nicht. Beim Operationsbericht gibt
  es eine Checkerhash-Abweichung und 306 statt angegebener 307 Guards;
  seine entscheidenden Aussagen wurden deshalb unabhängig kontrolliert.

## Fundamentale Auswahlfrage jetzt als konkreter Test

Bei gleichem W und denselben Symmetrien ergibt sich für dieselbe Referenz

\[
\mu_4\mu_2/\mu_3^2=1+1396(g/\Delta)^2.
\]

Die Werte 4,49 und 1,8725 für die beiden zulässigen Prüfparameter 1/20
und 1/40 zeigen: Die bisherigen geometrischen Grunddaten wählen noch
keine eindeutige Dynamik. Eine zusätzliche einfache Ursprungsregel könnte
das leisten; sie ist bislang nicht konstruiert.

**Prüfung:** 436 neue exakte Prüfbedingungen je Python-Modus, identische
Ergebnisdateien, frisch wiederholte historische C++-Kontraktion, 17
eingefrorene Eingaben. Kein vollständiger Fremdprogramm-Replay, kein
geschlossenes T1-T8-Tor, keine fertige TOE.

**Nächste Schritte:** korrekte H-Kette mit Restschranke fortsetzen;
ursprüngliches Transferinstrument nachweisen; dazu denselben Feldadapter
mit konsistenter Kinetik konstruieren. Vollständige Herleitungen und
frühere Ergebnisse stehen im Hauptdokument v1.6.7.
