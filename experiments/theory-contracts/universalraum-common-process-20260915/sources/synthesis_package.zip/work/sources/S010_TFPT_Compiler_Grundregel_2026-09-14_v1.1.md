# TFPT: Compiler-Grundregel und symmetrische Randrecords

Vollständig fortgeführte Forschungsnotiz v1.1 — 14. September 2026.

Diese Fassung enthält die neue Gesamtsynthese, den vollständigen Grundregel-Befund der vorigen Revision und die neue gemeinsame Randrecord-/Präparationskonstruktion. Sie ist eine Forschungsnotiz, kein Ersatz für das vollständige TFPT-Hauptpaper. Keine physische Abschlussbedingung T1–T8 wurde geschlossen.

# Teil I — Neuer Gesamtstand

# Eine symmetrische Grundregel und ihre Randrecords

Forschungsfortsetzung vom 14. September 2026, Revision1.1. NON-RH.
Vier parallel beziehungsweise unabhängig geprüfte Arbeitsstränge.
Keine ursprünglichen Quellen, Physikmarker, Hauptpaper oder Website geändert.

## Ergebnis der Runde

Die Frage »Kann die Bewegungsregel einfach und vollsymmetrisch bleiben, während
die verschiedenen Markierungen am Rand entstehen?« hat jetzt einen konkreten
positiven endlichen Teil. Auf dem ursprünglichen Klassenträger ist das bereits
mit derselben Matrix B/7 möglich. Auf den tatsächlichen Gaussian-Quantenzuständen
wurde zusätzlich ein kovariantes Instrument konstruiert, das ohne vorgewähltes q
eine Markierung und deren korrelierte Randzustände erzeugt.

Diese Konstruktion ist mit den echten Compiler-Reflexionswörtern verbunden:
Präparation, Zwischenrecord und Endereignis sind aus EINER anfänglichen
Dichtematrix berechnet. Die physische Ausführung dieses Instruments aus P1
folgt daraus noch nicht. Ebenso werden die freie Nahtkonstruktion, die
Kollisionsdynamik und das Markierungsinstrument nicht stillschweigend als
bereits derselbe mikroskopische Prozess ausgegeben.

## 1. Tatsächlich gleiche Grundregel, nicht nur gleich aussehende Familien

Die Originalquelle definiert K_xy=[hbar(x,y)=0]/7 ohne q. Jede der sechs
gleichartigen Arf-1-Markierungen bildet lediglich die Randmenge O_q aus fünf
der fünfzehn Klassen. Für sämtliche Markierungen ist der grobe Prozess gleich:

\[
K_{5/10}=\frac17\begin{pmatrix}1&6\\3&4\end{pmatrix},\qquad
p_q(n)=\frac13+\frac23\left(-\frac27\right)^n.
\]

K ist ein Markovoperator, aber wegen −2/7 nicht Hilbert-positiv. Der ursprüngliche
Doppelschritt K²=(4I+3J)/49 ist beides. Die sechs q bestimmen hier keinen neuen
Transfer. Das ist eine überprüfte Lesart einer schon vorhandenen Quellstruktur.

Die stärkere Behauptung »q ist überall nur eine Randmarkierung« wäre falsch:
Der ursprüngliche Ankerselektor braucht sigma,A,F_Sigma; die später signierte
reelle Wortalgebra bindet q an die Wortquadrate. Eine mu4-Rephasierung kann
diese reelle Struktur verändern, nicht einfach physisch vergessen. Außerdem
sind die Gaussian-Klassen über ganze Pauli-Kontexte angebunden, nicht über eine
unbegründete lineare Gleichsetzung mit einzelnen Pauli-Operatorlabels.

Details und Quellen: [Markierungsprüfung](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-boundary-selection-20260914/marking/RESULTS.md).

## 2. Die Markierung lebt tatsächlich in Korrelationen

Jedes q liefert fünf ursprüngliche MUB-Kontexte, zusammen20 Quellstrahlen.
Ihre Zustandsensembles besitzen denselben ersten Moment I4/4, denselben
Zweikopienmoment (I+Swap)/20 und denselben unaufgezeichneten D1/5-Messkanal.
Die dritten korrelierten Momente M_q sind jedoch verschieden.

Ein ursprünglicher Teststrahl unterscheidet die Fälle mit Wahrscheinlichkeit
1/16 beziehungsweise7/160. Diese Aussage erfordert korrelierte Kopien derselben
verborgenen Strahlwahl; bei unabhängiger Neuauswahl verschwindet die q-Information
für jede Kopienzahl. Ein direkt mitgelesenes Kontextetikett kann q schon früher
sichtbar machen. Es wird also kein pauschales Verbot von Einzeit-Auslese behauptet.

Aus dem exakten Moment-Gram folgt die Summenidentität
sum_q M_q=(3/10)Pi_sym. Sie liefert ein explizites Markierungsinstrument mit
Krausoperatoren P_r^tensor3/sqrt6 für r im jeweiligen q sowie dem komplementären
Symmetrieprojektor als Nichterfolgszweig. Aus drei unabhängigen Trace-Zuständen
entstehen

\[
p(q)=5/96,\qquad \rho_{\mathrm{nach}\ q}=M_q,\qquad p(\perp)=11/16.
\]

Eine Markierung wird hier wirklich als Record erzeugt; sie war kein vorher
eingesetzter Programmparameter. Die sechs Ergebnisse sind bedingt auf Erfolg
gleich wahrscheinlich. Die Konstruktion setzt Tensorzugang und das Quanteninstrument
voraus. Sie wählt weder dieses Instrument noch den ursprünglichen qstar-Anker
aus P1 eindeutig aus.

Ein verführerischer Zusatz wurde widerlegt: Reinheit Tr(M_q²)=1/16 macht M_q
nicht zum normierten Rang16-Projektor. Die exakte Gram-Abweichung ist erhalten;
ein fehlender Vierer-Korrelationsraum wird nicht behauptet.

Details und vollständige Herleitung: [Randrecord-Konstruktion](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-boundary-selection-20260914/Q_RECORD.md).

## 3. Präparation und Phasenvergleich sind jetzt gemeinsam gerechnet

Das Markierungsinstrument kann denselben ursprünglichen Strahl psi vorbereiten,
der den Drei-Reflexions-Test der vorigen Runde ermöglicht. Anfangszustand bleibt
(I4/4)^tensor3. Der Record(q,psi) hat für jedes der zwei zulässigen q das rohe
Gewicht1/384. Anschließend wirken ausschließlich tatsächliche ursprüngliche
Reflexionen auf der ersten Kopie.

Für die zwei Reihenfolgen W=R0 R+ R+i und W'=R0 R+i R+ liefert die gleiche
ursprüngliche Endauslese phi vollständige gemeinsame Gewichte1/384 beziehungsweise0.
Bedingt auf den aufgezeichneten Präparationserfolg sind dies1 und0. Werden die
zwei q-Records summiert, ohne Geschichten separat zu renormieren, sind die rohen
Gewichte1/192 und0. Ohne Heroldrecords verschwindet der Unterschied im gemittelten
Endzustand: beide Endwahrscheinlichkeiten sind1/4.

Damit ist die endliche Statistik einer gemeinsamen bedingten Ausführung
konstruiert, nicht bloß eine Formel für einen zuvor eingesetzten reinen Zustand.
Ein Record-Erzeugungsfunktional ergibt sich direkt aus denselben Krauspfaden.
Das ist noch nicht der physische 3+1D-Schwinger–Keldysh-Funktional von T8.

## 4. Die richtige Naht hat eine kleine exakte Bauform

Im ursprünglichen freien N8-NS-Modell ist die vollständige positive Hälfte
Cl4(C). Für ihren16×16-OS-Gram wurde exakt bewiesen

\[
W^\dagger G_{\mathrm{OS}}W=\bigoplus_{k=0}^4\wedge^k M,\qquad M>0.
\]

M ist ein4×4-Kern zwischen beiden Seiten des Schnitts; W ist die aus dem
gegebenen Zustand berechnete Wick-Normalordnung. Die gesamte größere Form
folgt damit aus einem kleinen Kern und seinen äußeren Potenzen. Eine gewählte
Clifford-Identifikation mit der Compileralgebra liefert einen expliziten
metrischen Anschluss, keine neue freie Bewertungsmatrix.

Die Zustandswahl bleibt aber tragend: Der ungefilterte zyklische Tr/4-Gram
ist nicht der OS-Gram. Der positive Faktor sqrt(G_OS) ist invertierbar,
jedoch ohne Skalierung kein zulässiger kontraktiver Mess-Krausoperator.
Der Wick-Faktor fixiert den Vakuumvektor, hat dieselbe Nicht-Kontraktionsgrenze.

Die tatsächliche lokale Translation ist ebenfalls nicht mit einer beliebig
gewählten positiven Zeitabbildung zu verwechseln. Ihre ursprüngliche
Zweischritt-Kompression ist auf einer4D-Domäne positiv, mit Eigenwerten1 und
sqrt2−1, jeweils doppelt. Das gibt noch keinen vollen selbstadjungierten
Zeitgenerator. Die unkomprimierte lokale Translation expandiert einen Modus.

Die ursprüngliche Seed-Kategorie nimmt Zustand, Zeittranslation, Reflexion
und Collar-Generator bereits als Eingaben. Ihre kanonische Completion
beweist deshalb keine eindeutige Auswahl dieser Eingaben aus P1.

Details: [Echte Naht und Wick-Anschluss](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-boundary-selection-20260914/seam/RESULTS.md).

## 5. Eine minimale Kollisionsausführung zeigt die Mehrzeitpflicht

Unter zusätzlich festgelegtem System/Umwelt-Tensorzugang und voller diagonaler
Symmetrie ist der Zwei-C4-Unitär ein partieller Austausch. Der vorhandene
Quantendecode D3/7 wird exakt realisiert durch

\[
U_\pm=\sqrt{3/7}\,I\pm i\sqrt{4/7}\,\mathrm{Swap}
\]

mit Umwelt I4/4. Die minimale reine Umwelt ist der neutrale Typ4 tensor4bar,
nicht einfach ein zweiter fundamentaler Viererträger. Dies ist eine explizite
mathematische Realisierung, keine neu hergeleitete physische Zelle.

Schon nach zwei Kontakten ist die bisher unspezifizierte Umweltgeschichte
messbar: Derselbe reine Eingangs-/Teststrahl hat bei frischer Umwelt
Rückkehrwahrscheinlichkeit19/49, bei wiederverwendeter Umwelt13/49.
Ein zusätzlicher ursprünglicher Zwischenfilter unterscheidet sogar die
beiden Kopplungsvorzeichen. Der Einzeitkanal bestimmt diesen Record-/Gedächtnisvertrag
nicht. Die Kollisionsmethode selbst ist bekannt; hier wurde ihr Anschluss an
den tatsächlichen TFPT-Quantendecode exakt geprüft.
[Primärquelle zur Methode](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.65.042105).

Auch volle Quellsymmetrie und gleicher D3/7-Kanal wählen die Aufzeichnungen
nicht: [Zwei Quelleninstrumente](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-boundary-selection-20260914/RECORDS.md) haben sogar dieselben ersten
Recordwahrscheinlichkeiten aus I4/4, aber verschiedene bedingte Präparationen
und Zweierrecords. Dies ist die explizite Gegenkontrolle zur Auswahlbehauptung.

## 6. Was Eindeutigkeit bei T8 tatsächlich verlangt

Der ursprüngliche T8-Vertrag verlangt einen eindeutig ausgewählten
Anfangszustand und einen gemeinsamen SK-Funktional; dies ist keine neu
erfundene Forderung dieser Untersuchung. Er verlangt jedoch keine deterministisch
festgelegte einzelne Messgeschichte. Eine Anfangsdichtematrix kann stochastisch
verschiedene spätere Records erzeugen. Der neue q-Ausgang widerspricht
dieser Form der Eindeutigkeit nicht.

Belege: tfpt_research_contracts.tex:14136 und:13827. Der Ankerselektor qstar
bleibt eine andere, unter festgehaltenen sigma,A,F_Sigma eindeutige Aussage.
Gemeinsam transformierte Markierungen und Messbezüge können äquivalente
Beschreibungen sein; bei festem Messbezug sind die Zustände unterscheidbar.

## 7. Stand aller physischen Abschlussfragen

| Tor | Beitrag dieser Runde | Weiter fehlender physischer Nachweis |
|---|---|---|
| T1 | q-unabhängige Quelle; bedingte kovariante Recordauswahl | Native P1/P2- und Ausführungs-/Dimensionsauswahl |
| T2 | Vollständiger positiver freier N8-Halbseitenkern mit exaktem Filteranschluss | Markierte geladene E8-Naht, Half-Charge-Felder und continuumverträgliche Identifikation |
| T3 | Kleine vollsymmetrische D3/7-Kollisionsrealisierung | Eine gemeinsame quasilokale unitäre3+1D-Hamiltonfamilie |
| T4 | Keine neue chirale Feldkonstruktion | Lokales chirales Maß und uniformer Spiegelspalt |
| T5 | Kein Kontinuumsabschluss | Lorentzgrenze, Confinement, Clustering und Streuung im gleichen Modell |
| T6 | Keine neue physische Kopplungsherleitung | Alle drei Eichkopplungen und Neutrinotextur aus der Quelle |
| T7 | Kein dynamischer Spin-2-Sektor konstruiert | Massloser quantisierter Spin2 mit universeller Kopplung |
| T8 | Gemeinsame endliche Record-/Präparations-/Endstatistik | Quellenseitiges konsistentes Paar(S,rho0) und alle physischen Auslesungen |

Alle acht Tore bleiben offen. Die endlichen Konstruktionen sind konkrete
Fortschritte innerhalb benannter Prämissen, keine acht erledigten Physikprobleme.
RH, Faktorisierung und P/NP wurden in dieser Runde nicht bearbeitet.

## 8. Der präzise gemeinsame nächste Nachweis

Die nächste Aufgabe ist nicht, eine weitere Matrix passend hinzuzufügen:
**Aus derselben ursprünglichen Naht müssen Zustand, zulässige Komposition,
Zeitfortsetzung und Recordinstrument gemeinsam folgen.**

Die positive Seite dieser Runde ist, dass dafür mehrere große Beschreibungen
auf kleine schon vorhandene Strukturen zurückgeführt werden konnten. Die
verbleibende Pflicht ist eine Auswahl- und Verträglichkeitsaussage. Ein
metrischer Nahtfilter ist nicht automatisch ein Messinstrument; ein
Kollisionskanal ist nicht automatisch die vollständige Kontextgeschichte;
eine kovariante Markierung ist nicht automatisch der Ankerselektor.

Ein akzeptabler Anschluss muss insbesondere die oben gemeinsam berechneten
ungefilterten Pfadgewichte reproduzieren und explizit entscheiden, welche
Umweltinformationen erhalten bleiben. Eine Gleichheit weniger Mittelwerte
oder Kontraktionszahlen genügt nach den exakten Gegenbeispielen nicht.

## 9. Belege und Replays

- Markierungen:2299 exakte Prüfungen; Quellmomente:132; jeweils normal/-OO identisch.
- Quellrecord-Instrumente:4145 eigene plus1073 geerbte Prüfungen; normal/-OO identisch;3 Mutanten abgefangen.
- Q-Record-Korollar und gemeinsame Ausführung:24 eigene plus1073 geerbte Prüfungen; normal/-OO identisch.
- Kollisionsausführung:158 eigene plus2014 geerbte Prüfungen; normal/-OO identisch;3 Mutanten abgefangen.
- Echte Naht:322 exakte Prüfungen, auch unter -O; Positivität durch algebraische LDL und Wick-Kongruenz.

Prüfzahlen zählen algebraische Bedingungen, nicht unabhängige Entdeckungen.
Alle neuen Dateien liegen im eigenen Untersuchungsordner. Die Altbefunde,
Negativresultate, Repräsentationsunterschiede und Quellenpins sind erhalten.

# Teil II — Vollständiger Grundregel-Befund aus Revision1.0

Dieser Teil bleibt als Beweisgrundlage erhalten. Die Anschlussfragen werden durch Teil I und III präzisiert und teilweise endlich konstruktiv beantwortet.

# Zur kleinen gemeinsamen Regel: Compilerprozesse vor ihren Schatten

Forschungsnotiz v1.0, 14. September 2026. NON-RH. Keine TOE-Promotion.

## Ergebnis

Ein kleiner, direkt an den vorhandenen Compiler angeschlossener Kandidat ist
jetzt ausgeschrieben und exakt geprüft: **Operationen geordnet verknüpfen,
ihre vollständigen komplexen Überlappungen erhalten und erst danach auslesen.**
Unter einer ausdrücklich benannten Schnittunabhängigkeit geschlossener
Prozesse ist deren skalare Bewertung eindeutig.

Der stärkste anschauliche Zeuge besteht aus drei ursprünglichen
Compilerzuständen: Alle drei paarweisen Übergangswahrscheinlichkeiten sind
identisch, aber die orientierte Dreieramplitude unterscheidet sich.
Zweierwahrscheinlichkeiten können die Richtungsinformation verbergen, die
im geordneten Prozess erhalten bleibt.

Das benötigt kein größeres Zellmodell und keinen neuen Hamiltonoperator.
**Nicht bewiesen ist, dass diese algebraische Regel bereits die physische
P1-Randquelle ist oder deren Zeitentwicklung auswählt.** Die kleinen
Gegenkontrollen verhindern genau diese voreilige Identifikation.

## 1. Die ursprünglichen Reflexionen bestimmen einen positiven Kern

Alle 60 Strahlen werden aus dem ursprünglichen Gaussian-E8-Chart rekonstruiert.
Für einen normierten Strahl gilt

\[
P_r=|r\rangle\langle r|,\quad R_r=I-2P_r,\quad P_r=(I-R_r)/2.
\]

Die vorhandenen Reflexionen bestimmen daher die Projektoren als Elemente ihrer
komplexen Algebra. Die Projektoren spannen M4(C). Ihre algebraische Existenz
beweist noch keine physische Ausführbarkeit kohärenter Linearkombinationen.

Für Wörter w,v ist der operatorwertige Kern

\[
\boxed{\mathcal K(w,v)=W(w)^\dagger W(v).}
\]

Er ist positiv: Für jede Wortliste ist [W_i†W_j] die Gram-Matrix
[W_1 ... W_n]†[W_1 ... W_n]. Dafür wird kein skalarer Anfangszustand gewählt.
Die Operationsvorzeichen bleiben in der geordneten Multiplikation erhalten.

Das ist bekannte Operatoralgebra, keine neue mathematische Klasse. Der
konkrete Beitrag ist ihr exakter Anschluss an die unveränderten TFPT-Quellen
und die Trennung der dadurch geschlossenen und weiterhin offenen Aussagen.

## 2. Schnittunabhängigkeit fixiert die geschlossene Bewertung

Fordere auf der schon bestimmten Algebra eine komplex-lineare Bewertung tau
mit tau(I)=1 und tau(ab)=tau(ba). Die letzte Bedingung lässt sich als
Unabhängigkeit davon lesen, wo ein geschlossener Prozess zum Aufschreiben
aufgeschnitten wird. Sie ist ein **benannter Konsistenzvertrag**, noch kein
aus der physischen P1-Naht bewiesenes Gesetz.

Aus [Eii,Eij]=Eij folgt tau(Eij)=0 für i≠j. Aus
[Eij,Eji]=Eii−Ejj folgen gleiche Diagonalgewichte. Also eindeutig

\[
\tau(A)=\tfrac14\operatorname{Tr}(A),\qquad
k(w,v)=\tfrac14\operatorname{Tr}(W(w)^\dagger W(v)).
\]

Positivität und Treue folgen. Ein frei anpassbarer Gramkern entfällt auf dieser
Algebra. Dasselbe Ergebnis folgt für einen normierten Zustand unter voller
Invarianz der tatsächlichen irreduziblen Reflexionsgruppe.

Der zugehörige GNS-Raum ist der 16-dimensionale Operatorraum M4(C), **kein
zusätzlich postulierter physischer 16-Zustands-Träger**. Treue gilt auf
Matrizen, nicht auf verschiedenen Wortbeschreibungen derselben Matrix.

### Ein vollständiger Rekonstruktionssatz

Zwei gleichdimensionale irreduzible unitäre Darstellungen desselben markierten
*-Wortalphabets sind unitär äquivalent, wenn ihre normierten komplexen Spuren
für **alle** Wörter einschließlich gemischter Adjunktenwörter übereinstimmen.

Beweis: Alle Wortspuren bestimmen tau(A†A) jeder endlichen Linearkombination.
Treue erkennt genau die Nullkombinationen. Die Wortabbildung ist daher
wohldefiniert und bijektiv und erhält Multiplikation, Adjungierung und Spur.
Der so entstehende *-Isomorphismus voller gleicher Matrixalgebren ist durch
eine gemeinsame Unitary implementiert.

Die Quantoren sind wichtig: komplexe Amplituden aller Wörter, nicht nur
Beträge, Wahrscheinlichkeiten oder drei numerische Momente. Hieraus folgt
kein effizienter allgemeiner Rekonstruktionsalgorithmus.

## 3. Ein ursprüngliches Dreieck trägt die fehlende Orientierung

Im tatsächlichen C4-Chart liegen

\[
|0\rangle=(1,0,0,0),\quad |+\rangle=(1,0,1,0)/\sqrt2,\quad
|+i\rangle=(1,0,i,0)/\sqrt2,\quad |-i\rangle=\overline{|+i\rangle}.
\]

Alle drei paarweisen Born-Überlappungen des Dreiecks 0,+,+i sind 1/2.
Komplexe Konjugation lässt sogar die gesamte paarweise Projektor-Gram-Matrix
aller 60 Strahlen unverändert. Für die **gewöhnliche Spur** gilt dagegen

\[
\operatorname{Tr}(P_0P_+P_{+i})=(1+i)/4,\qquad
\operatorname{Tr}(P_0P_{+i}P_+)=(1-i)/4.
\]

Für tau=Tr/4 sind die Werte (1±i)/16; die Normierungen dürfen nicht vermischt
werden. Die Phasen bleiben ±pi/4. Diese komplexen Amplituden sind nicht schon
Wahrscheinlichkeiten gewöhnlicher sequenzieller Projektivmessungen: Ihre
Auslese verlangt einen kohärenten Interferenzvertrag.

Mit P_n=(I+n·sigma)/2 im kleinen Zweierblock folgt exakt

\[
\operatorname{Tr}(P_aP_bP_c)=
\frac{1+a\cdot b+b\cdot c+c\cdot a+i\,a\cdot(b\times c)}4.
\]

Dieselbe Multiplikation enthält paarweise Geometrie und Orientierung.
Daneben ist det(tI+x sigma_x+y sigma_y+z sigma_z)=t²−x²−y²−z².
Der hier gewählte Zweierblock ist nicht dadurch schon mit dem früheren
reellen Anker-Kommutanten identifiziert; dessen markierter Anschluss bleibt
mitzuführen.

Die Verbindung solcher Amplituden zu geometrischen Phasen ist bekannte
Bargmann-/Pancharatnam-Mathematik:
[Mukunda et al., 2003](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.67.042114).
Der TFPT-Befund ist der konkrete Zeuge aus den ursprünglichen Strahlen.

### Stärker: Zwei echte Reflexionswörter sind intern unterscheidbar

Der Anschluss bleibt nicht auf formal addierte Projektoroperationen beschränkt.
Setze R_j=I−2P_j für die drei obigen ursprünglichen Reflexionen. Dann gilt exakt

\[
W=R_0R_+R_{+i}=\operatorname{diag}(-i,1,-i,1),\qquad
W'=R_0R_{+i}R_+=\operatorname{diag}(i,1,i,1).
\]

Hier wirkt der rechte Faktor zuerst. Die beiden zeitlichen Folgen sind also
R_+i → R_+ → R_0 beziehungsweise R_+ → R_+i → R_0.
Die internen Bezugsstrahlen

\[
|\psi\rangle=(1,1,0,0)/\sqrt2,\qquad
|\phi\rangle=(1,i,0,0)/\sqrt2
\]

gehören ebenfalls zu den ursprünglichen 60 Strahlen. Für dieselbe Präparation
psi und dieselbe Auslese phi gilt

\[
\boxed{|\langle\phi|W|\psi\rangle|^2=1,\qquad
|\langle\phi|W'|\psi\rangle|^2=0.}
\]

Die beiden Abläufe verwenden die gleichen drei Reflexionen jeweils einmal.
Der Unterschied liegt ausschließlich in der Reihenfolge. Ein bereits im
originalen C4 vorhandener Querblock-Bezug genügt; für diesen mathematischen
Zeugen braucht es kein zusätzlich postuliertes Referenzregister und keine
kohärente Summe verschiedener Operationen.

Das ist eine Aussage über die Vorhersagen zweier konkreter Quellwörter,
**gegeben** den Zugang zu dieser Präparation und Messung. Deren physische
Implementierung wird damit nicht hergeleitet. Eine globale zentrale Phase
iI4 bleibt unsichtbar. Wer das gesamte Experiment einschließlich Gates,
Präparation und Auslese komplex konjugiert, erhält wieder dieselben Bornwerte.
Der Zeuge wählt daher keine absolute komplexe Orientierung und beweist weder
physische Chiralität noch eine Zwölferuhr.

## 4. Die korrekte Uhrenbrücke ist eine Dualität, keine Gleichsetzung

Die Quellen benutzen dieselbe Gitterpermutation PI_SIG. Sie fixiert drei
nichttriviale Quotientenklassen. Im Gaussian-C4-Chart fixiert ihre Konjugation
keinen nichttrivialen Paulioperator, aber drei Pauli-Kontexte.
Die tatsächliche Klassen-zu-Kontext-Bijektion ist an allen 240 Wurzeln erneut
geprüft und äquivariant.

Der abstrakte Wortlift realisiert die Familienbitdrehung auf einer anderen
C4-Darstellung. Die beiden Implementierer besitzen |Tr sigma|=1 bzw.2 und
lassen sich nicht durch unitären oder antiunitären Basiswechsel, skalare
Deckphase oder Inversion gleichsetzen.

Das ist **kein Fehler in v774 oder v783**. Die Originalquelle nennt
Punkt-Linien-Dualität und äußeren S6-Twist ausdrücklich. Eine gemeinsame Regel
darf unterschiedliche Darstellungen besitzen; ihre korrekte Brücke verläuft
hier über Klassen und Kontexte, nicht über identifizierte Einzelvektoren.

Belege: [Uhren- und Kernaudit](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-kernel-foundation-20260914/redteam/RESULTS.md).

## 5. Der einfache Polarzerfall von B/7 bleibt typgebunden

Auf den 15 Kontextlabels gilt B²=4I+3J. Mit P0=J/15 und Q=I−P0 ist

\[
S=B/2-J/6,\quad S^2=I,\qquad
K=B/7=S\big(P_0+(2/7)Q\big).
\]

Das ist eine exakte Vorzeichen-/Kontraktionszerlegung. S hat negative
Einträge und ist kein Markovschritt. Im tatsächlichen 60-Strahlen-Lift
verschwindet das nichttriviale Kontextvorzeichen beim Decode in die
Materiedichtematrix. Der materielle Kontrast ist 3/7, nicht 2/7.
Auch der Betrag des 60-Strahlen-Operators besitzt negative Einträge
(Minimum −1/42): Operatorpositivität ist nicht Eintragspositivität.

Volle Inzidenzsymmetrie lässt zwei Verluste auf den 9er- und 5er-Sektoren zu.
Erst zusätzliche Isotropie reduziert sie auf eine Zahl rho. In diesem
eingeschränkten Ansatz wählt exakt der B-Support rho=2/7. Ohne Isotropie
bleibt eine Familie mit gleichem Support und gleichem Polarzeichen.
Mit q*-Markierung ist die Freiheit größer, nicht kleiner.

Belege: [Polar- und Schattentest](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-kernel-foundation-20260914/polar_shadow/RESULTS.md). Das Ergebnis
erklärt die vorhandene Regel, nicht ihre physische Auswahl.

## 6. Zwei tatsächliche Anschlussstellen dürfen nicht übersprungen werden

### Gewöhnliche Positivität ist nicht automatisch P1-Reflexionspositivität

Die parabolische Quelle benutzt
U=[[3,0,0],[3,0,0],[3,0,0]], Sigma=diag(1,−1,−1), a=(1,1,2) und
Theta(X)=Sigma X^T Sigma. Auf dem echten Compilerbuchstaben gilt

\[
a^T\Theta(U)Ua=-9,\qquad a^TU^\dagger Ua=27.
\]

Der positive gewöhnliche Gram und die getestete Nahtreflexionsform sind
verschieden. Dies widerlegt weder P1 noch OS-Reflexionspositivität: Eine
passende positive Halbseitenalgebra kann kleiner sein. Es verbietet aber,
die ganze Wortalgebra ungeprüft als diese Hälfte auszugeben.

### Dreiercompiler und Viererträger brauchen einen typgerechten Anschluss

Der ursprüngliche U,V-Ankercompiler erzeugt eine parabolische Algebra der
Dimension7. Ihre kleinste †-Abschließung im bestehenden C3 ist M3(C),
Dimension9. Ein unitaler *-Homomorphismus M3(C) nach M4(C) existiert nicht:
Drei äquivalente minimale Projektoren hätten gleichen Bildrang r, also 3r=4.

Andere Verträge bleiben möglich: nichtunitale Einbettung, M3⊕C nach M4,
nichtmultiplikative positive Abbildung oder Modulbrücke. Keiner davon ist
automatisch ein unital getreues Gleichsetzen der Compiler.

Auch die vorhandene Z4-Mittelung muss typgerecht bleiben: Für den zentralen
Deckoperator iI4 ist der Durchschnitt seiner Konjugationen die Identität.
Die nichttriviale Sektormittelung in v993 verwendet eine nichtzentrale Clock.
Ihre positive operatorwertige Regel E(X†Y) ist ein möglicher Baustein; die
erforderliche Sektorwirkung entsteht nicht durch Umbenennen der Zentralphase.

## 7. Was noch nicht ausgewählt ist

Der eindeutige Spurkern besitzt triviale modulare Dynamik. Auch c=i sigma
mit linearer Ordnung12 erzeugt ohne relative Referenz nur drei verschiedene
Prozessstrahlen, denn c^(n+3)=−i c^n.

Positive kovariante Gluing-Regeln existieren schon als Familie
T_gamma(t)=P+exp(−gamma t)(I−P). Verschiedene positive gamma können nur
verschiedene Zeiteinheiten sein; dieses Beispiel allein beweist keine
dimensionslos unterschiedliche Physik. Die gesonderte relative-Ratenprüfung
liefert jetzt eine stärkere und genauer eingegrenzte Aussage.

Auf der tatsächlichen q*-markierten Clifford-Wortalgebra sei

\[
\mathcal L=\gamma_5\sum_{v\in O_5}(\operatorname{Ad}_{P_v}-I)
+\gamma_{10}\sum_{v\in O_{10}}(\operatorname{Ad}_{P_v}-I),
\quad \gamma_5,\gamma_{10}\ge0.
\]

O5 und O10 sind die beiden ursprünglichen markierten Wortorbits. Jede
Halbgruppe exp(t L) ist als Poissonmischung unitärer Wortoperationen vollständig
positiv, unital und spurtreu. Die tatsächliche signierte S5-Kovarianz wurde
mitgeprüft. Die beiden Kontrastzerfallsraten sind exakt

\[
r_5=8(\gamma_5+\gamma_{10}),\qquad
r_{10}=4\gamma_5+12\gamma_{10}.
\]

Die Wahl (gamma5,gamma10)=(1,0) gibt r5/r10=2, die Wahl (0,1) gibt 2/3.
Diese Verhältnisse lassen sich nicht durch Ändern der Zeiteinheit angleichen.
Wenn derselbe 10er-Kontrast auf 1/8 gefallen ist, beträgt der 5er-Kontrast
in den beiden Fällen 1/64 beziehungsweise 1/4.

**Die positive Vereinfachung ist ebenso wichtig:** Bei zusätzlich voller
unmarkierter Clifford-Kovarianz müssen die beiden Raten in dieser Familie
zusammenfallen. Dann bleibt nur eine gemeinsame Zeitskala. Eine stärkere
Symmetrie kann die Freiheit also tatsächlich beseitigen; sie darf nur nicht
behauptet werden, wenn zugleich eine widersprechende markierte Dynamik
verwendet wird.

Damit entsteht eine konkrete Vereinfachungsfrage: Gehört q* zur universellen
Bewegungsregel selbst, oder markiert q* lediglich den Randzustand und dessen
Auslese, während die Grundregel vollsymmetrisch bleibt? Die zweite Lesart
ist ein kleiner Kandidat, aber hier nicht aus P1 hergeleitet.

Der [Zweiraten-Nachtrag](/Users/stefanhamann/Projekte/tfpt-theoryv4/experiments/theory-contracts/compiler-kernel-foundation-20260914/redteam/TWO_RATE_ADDENDUM.md) enthält 284 exakte
Prüfungen, Normal/-OO-Replay und drei abgefangene Mutanten. Seine vollständige
Positivität ist ausdrücklich stärker als bloße Positivität einer
Prozess-Gram-Matrix. Dies konstruiert eine Gegenfamilie unter benannten
Annahmen, keine von TFPT physisch ausgewählte Dynamik.

Ein vorhandener Transfer bestimmt seine Iterationen. Weder diese algebraische
Bestimmtheit noch Schnittunabhängigkeit erklärt jedoch schon, weshalb genau
dieser Ablauf stattfindet, welche offene Randpräparation vorliegt und welche
lokalen Teile physisch miteinander verknüpft werden.

## 8. Der nächste entscheidende Suchauftrag

**Kann die tatsächliche orientierte P1-Naht eine positive Halbseiten- und
Kompositionsregel auswählen, deren geschlossene Bewertungen mit dem
eindeutigen Compiler-Loopkern übereinstimmen und deren offene Ausführung
keinen nachträglich passend gewählten Zustand oder Transfer braucht?**

Ein Anschluss muss die geordnete Dreierphase, die Klassen–Kontext-Dualität
und den Unterschied zwischen zentraler Deckphase und beobachtbarer
Sektorwirkung erhalten. Paarweise Wahrscheinlichkeiten oder einige gleiche
Konstanten genügen nicht. Veränderte Adjungierung, unbenannte Halbseite oder
passend gesetzte relative Raten zählen nicht als Herleitung.

T1–T8 bleiben offen. Kein gemeinsamer lokaler 3+1D-Ursprung, kein vollständiges
chirales Maß, keine vollständigen Standardmodellparameter und kein dynamischer
masseloser Spin-2-Sektor wurden aus diesem endlichen Kern gewonnen.
RH, Faktorisierung und P/NP wurden in dieser Runde nicht bearbeitet.

## 9. Reproduzierbarkeit

Der Hauptprüfer relational_kernel.py verwendet kleine exakte Matrizen und
ursprüngliche Projektoren: 209 neue Bedingungen plus 1073 geerbte aktive
P0/P1-Prüfungen. Normal/-OO-Ausgaben sind byteidentisch. Quelle und Loader
sind gepinnt. Die vollständige ursprüngliche v783-Gruppen-/Hom-Zählung
wird nicht als neu ausgeführt ausgegeben.

Die eigenständigen Redteam- und Polarbelege enthalten ihre Quellpins,
Prüfprogramme und Grenzen. Keine Originalquelle, kein TOE-Marker, kein
Hauptpaper und keine Website wurden geändert.

# Teil III — Gemeinsame Markierungs-, Präparations- und Recordausführung

# Eine Markierung kann als Randrecord entstehen

14. September 2026. Exakte bedingte Konstruktion auf den ursprünglichen
Gaussian-Strahlen, unabhängig gegengeprüft. Kein neuer physischer Träger,
kein Born-Beweis und keine TOE-Promotion.

## Die ursprünglichen Markierungen sind in frühen Mittelwerten unsichtbar

Die sechs q-Markierungen wählen jeweils fünf tatsächliche Kontexte und damit
20 ursprüngliche Quellstrahlen. Diese fünf Kontexte sind gegenseitig unverzerrte
Basen. Für ihre korrelierten Kopienmomente

\[
M_k(q)=\frac1{20}\sum_{r\in q}P_r^{\otimes k}
\]

gilt exakt für jedes q:

\[
M_1=I_4/4,\qquad M_2=(I_{16}+\mathrm{Swap})/20.
\]

Auch die unaufgezeichnete uniforme Kontextmessung ist jeweils derselbe Kanal
D1/5. Die dritte Korrelation unterscheidet die Markierungen dagegen. Für einen
ursprünglichen Teststrahl psi ist

\[
\operatorname{Tr}(P_\psi^{\otimes3}M_3(q))=
\begin{cases}1/16,&\text{wenn sein Kontext in q liegt},\\
7/160,&\text{sonst}.\end{cases}
\]

Ein einzelner solcher Test trennt zwei von vier Markierungen, nicht alle sechs
auf einmal. Für jedes Paar unterschiedlicher Markierungen gibt es jedoch einen
solchen Quellstrahl-Zeugen. Dabei muss dieselbe verborgene Strahlwahl über die
drei Kopien korreliert sein. Bei unabhängigem Neuziehen werden alle Momente zum
Produkt von I4/4; die Information verschwindet dann für jede Kopienzahl.
Mit zugänglichen Kontextetiketten kann die Markierung schon im ersten Record
sichtbar sein. Der Drei-Kopien-Satz betrifft unetikettierte Quantenzustände.

Dies ist nicht die frühere geordnete Bargmann-Dreieramplitude: symmetrische
Kopienkorrelation und zeitlich geordnetes Wort sind verschiedene Objekte.

## Eine einfache positive Folge: ein kovariantes Markierungsinstrument

Schreibe M_q=M3(q) und Pi_sym für den Projektor auf Sym³(C4), Dimension20.
Aus den direkt geprüften Quellüberlappungen folgt

\[
\operatorname{Tr}(M_q^2)=1/16,\qquad
\operatorname{Tr}(M_qM_{q'})=19/400\quad(q\ne q').
\]

Für Mbar=sum_q M_q/6 ist daher Tr(Mbar²)=1/20. Alle M_q sind auf demselben
symmetrischen Raum getragen und haben Spur1. Folglich

\[
\|Mbar-\Pi_{\mathrm{sym}}/20\|_{\mathrm{HS}}^2=0,
\qquad \sum_qM_q=\frac3{10}\Pi_{\mathrm{sym}}.
\]

Das bestimmt die positiven Effekte

\[
E_q=\frac{10}{3}M_q,\qquad
E_\perp=I_{64}-\Pi_{\mathrm{sym}},\qquad
\sum_qE_q+E_\perp=I_{64}.
\]

Ein explizites Instrument braucht nicht einmal die vollständige Matrixwurzel
von M_q. Verwende die Krausoperatoren

\[
K_{q,r}=P_r^{\otimes3}/\sqrt6\quad(r\in q),\qquad
K_\perp=I_{64}-\Pi_{\mathrm{sym}}.
\]

Jeder Quellstrahl gehört genau zwei Markierungen; zusammen mit der obigen
Summenidentität beweist das die Vollständigkeit. Die ursprüngliche Gruppe
permutiert q und r gemeinsam. Das Instrument ist deshalb kovariant, ohne
vorab ein bestimmtes q in seine Bewegungsregel einzusetzen.

Starte nun mit drei unabhängigen zyklischen Randzuständen, also I64/64.
Für jedes q gilt genau

\[
\boxed{p(q)=5/96,\quad \rho_{\mathrm{nach}\ q}=M_q,\quad
p(\perp)=11/16.}
\]

Insgesamt treten q-Records mit Wahrscheinlichkeit5/16 auf. Bedingt auf
diesen Erfolg sind die sechs gleich wahrscheinlich. **Die Korrelationen
entstehen hier im Instrument; sie sind nicht schon in den Eingang hineingelegt.**

Alternativ liefert die Lüders-Realisierung sqrt(E_q) aus demselben
maximalgemischten Eingang dieselben bedingten Zustände. Sie ist aber auf
allgemeinen Eingängen NICHT dasselbe Instrument wie die obige Krausliste.
Diese Nicht-Eindeutigkeit wird nicht versteckt.

Die Konstruktion löst eine begrenzte Existenzfrage: Eine volle symmetrische
Regel kann eine unterschiedliche Markierung als stochastischen Randrecord
hervorbringen. Sie löst nicht den ursprünglichen Ankerselektor für qstar und
beweist keine native Tensorfaktorisierung oder Verfügbarkeit dieses Instruments.

## Präparation, Record und Compilerwort in einer Ausführung

Der neue Anschluss wird auch mit dem früheren Reflexionswort-Zeugen verbunden.
Alle Schritte beginnen gemeinsam bei (I4/4)^tensor3; ein reiner Eingang wird
nicht zusätzlich festgesetzt. Bewahre im obigen Instrument den Record(q,r)
auf und betrachte r=psi=(1,1,0,0)/sqrt2. Zwei q-Markierungen erlauben diesen
ursprünglichen Strahl. Für jedes der beiden Paare gilt ungefiltert p(q,r)=1/384;
der zugehörige bedingte Zustand ist P_psi^tensor3.

Auf der ersten Kopie folgen entweder W=R0 R+ R+i oder W'=R0 R+i R+ aus den
drei ursprünglichen Reflexionen. Der rechte Faktor wirkt jeweils zuerst.
Am Ende wird der ursprüngliche Strahl phi=(1,i,0,0)/sqrt2 getestet.

| Gewicht derselben vollständigen Geschichte | W | W' |
|---|---:|---:|
| Vorgegebener zulässiger Record(q,psi) und Endereignis | 1/384 | 0 |
| Beide zulässigen q summiert, psi und Endereignis erhalten | 1/192 | 0 |
| Bedingt auf den aufgezeichneten Präparationserfolg | 1 | 0 |

Alle Zahlen sind aus derselben Anfangsdichte und denselben Krausoperatoren
berechnet. Ohne Herold-/Randrecords bleibt die Anfangsdichte unter dem
nichtselektiven Instrument und den Wörtern invariant; der Endtest liefert
dann in beiden Fällen1/4. Die Information sitzt in den gemeinsamen Records,
nicht in einer nachträglich passend eingesetzten reinen Anfangsbedingung.

Für jede festgelegte Fortsetzung wird die gesamte endliche Statistik gemeinsam
durch p(o1,...,on)=Tr(K_on...K_o1 rho0 K_o1†...K_on†) bestimmt; ein gemeinsames
Record-Erzeugungsfunktional ist die entsprechende charakteristische Funktion
Z(chi)=sum_history exp(i sum_t chi_t(o_t)) p(history). Diese endliche
Formel ist kein bereits konstruierter Kontinuums-SK-Funktional für T8.

## Kein perfekter Decoder und kein erfundener fehlender Viererraum

Das verwandte Pretty-good-Messverfahren E_q identifiziert einen als M_q
vorbereiteten Zustand nur mit Wahrscheinlichkeit5/24; jedes falsche Label
hat Wahrscheinlichkeit19/120. Die Zustände sind nicht orthogonal.

Aus Tr(M_q²)=1/16 folgt NICHT, M_q sei ein normierter Rang16-Projektor.
Diese attraktive Hypothese wurde unabhängig für alle sechs Markierungen
widerlegt: Im 20×20-Gram G der symmetrischen Strahlwürfel gilt
G²≠(5/4)G; eine explizite Residuumskomponente ist3/16.
Ein vierdimensionaler fehlender Korrelationsraum ist also nicht nachgewiesen.
Die gültige Summen-/POVM-Konstruktion oben benutzt diese falsche Hypothese nicht.

## Physische Grenze

Gegenstand sind Quellenalgebra, Tensorprodukte und ein wohldefiniertes
Quanteninstrument unter der normalen endlichdimensionalen Quantenmechanik.
Die Verfügbarkeit genau dieser gemeinsam adressierten Kopien, Projektionen
und Records ist zusätzliche operative Struktur. Zahlen wie5/96 sind
Protokollwahrscheinlichkeiten, keine neuen Naturkonstanten.
Symmetrie allein wählt dieses Instrument nicht eindeutig aus.

Der ursprüngliche P1-Zustands-/Zeitvertrag und der gemeinsame 3+1D-Elternprozess
sind weiterhin nicht konstruiert. Alle T1–T8 bleiben offen.

Belege: marking/boundary_moments.py und dessen exakte Quellelemente;
q_record_completion.py prüft die rationalen Summen- und Normierungsschritte
aus dem archivierten Moment-Gram. Der Drei-Design-Hintergrund ist bekannte
Mathematik, nicht eine neue allgemeine TFPT-Entdeckung:
[Zhu, 2017](https://journals.aps.org/pra/abstract/10.1103/PhysRevA.96.062336).

