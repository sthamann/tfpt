# TFPT / Universalraum: Präparation, Restantwort und die Herkunft räumlicher Teile

## Fundamentale Fortsetzung v1.6.6 · 15. September 2026

### Ergebnis

Diese Fortsetzung schließt vier eng bestimmte Fragen nach v1.6.5 beziehungsweise entscheidet einen dort offenen Kandidaten. Sie enthält eigene analytische Herleitungen mit exakten algebraischen und rationalen Zertifikaten. Die Aussagen gelten unter dem angegebenen nativen Modellvertrag; sie sind nicht in Lean formalisiert und begründen keinen literaturweiten Neuheitsanspruch.

| Frage | Ergebnis dieser Arbeit | Reichweite |
|---|---|---|
| Kann man den nativen Grundzustand aus einem einfachen Zustand erreichen? | Eine lineare Kopplungsrampe besitzt im gesamten N=64-Sektor durchgehend eine Lücke >0,082261 Δ. Eine konservative Laufzeit liefert Grundzustandswahrscheinlichkeit >99,9999726 %. | Konstruktiver bedingter Präparationssatz; voll besetzter Anfangszustand und Steuerbarkeit der Rampe vorausgesetzt. |
| Wie stark ist die unvermeidliche Restantwort mindestens? | Var(N_b)>0,1193989 und der zweite Lanczos-Nebendiagonalkoeffizient erfüllt β₂²>9,640875·10⁻⁷ Δ². | Neue quantitative Untergrenze auf demselben nativen Grundzustand; keine vollständige Berechnung von Σ₂. |
| Kann man eine Bank einfach in zwei unabhängige Teile zerlegen? | Der exakte Unterstützungsgraph ist zusammenhängend und hat Laplacelücke 12. Jeder Schnitt mit s Moden hat mindestens 3s(64−s)/16 kreuzende Paarterme; bei 32/32 mindestens 192 von 480. | Alle Teilmengen der ursprünglichen Modenbasis; keine Aussage über beliebige neue Feldkoordinaten oder emergente Lokalität. |
| Ist der zuletzt vorgeschlagene freie (1,0)-Kinetikterm stabil? | Nein: Er erlaubt negative, nach unten unbeschränkte Energie und säkulare Lösungen. | Entscheidung des freien, unbeschränkten, geladenen Zweitableitungs-Kandidaten; kein Ausschluss jeder Tensorfeldtheorie. |

Zusätzlich werden ein stabiler **freier Vergleichsparent** mit einem massiven Vektorfeld und die Grenze der skalaren Hilfsindex-Reparatur angegeben. Der Vektorparent ist ein zusätzliches effektives Modell, kein abgeleiteter TFPT-Hamiltonoperator.

**T1–T8 bleiben als Gesamtaufgaben offen.** Herkunft von Teilbereichen, ursprünglichen Kontrollen, Ladungsreferenzen und Feldträgern wird durch die hier gelösten Teilfragen enger, aber nicht automatisch mitgelöst. RH, effiziente Faktorisierung und P versus NP erhalten in dieser Revision keinen neuen Abschlussnachweis.

## 1. Quellen und unveränderter Ausgangspunkt

Die bereitgestellten Markdown-Versionen v1.6 bis v1.6.5 und die beiden PDFs v1.6 wurden lokal eingefroren und mit SHA-256 inventarisiert. Die neueste konsolidierte Fassung v1.6.5 einschließlich ihres historischen v1.6.4-Anhangs ist die maßgebliche mathematische Ausgangsquelle. Die PDFs dienen der historischen Einordnung; diese Arbeit ist kein erneuter vollständiger Audit aller 168 Seiten und aller historischen Großrechnungen.

Das vorhandene v1.6.5-Prüfpaket wurde aus dem angegebenen Dokumentenumfeld zusätzlich gesichert. Der dortige Zwei-Banken-Prüfer wurde neu ausgeführt: 4.516 Bedingungen, byteidentisch mit seinem archivierten Bericht. Der vollständige ältere Grundzustands-Enumerationslauf wurde nicht neu ausgeführt. Seine Beweisaussagen und Energie-/Besetzungsintervalle werden als explizite Voraussetzungen übernommen. Die für diese Fortsetzung benötigten Tensoridentitäten und die zentrale Komplement-Untergrenze werden frisch geprüft.

Anweisungen innerhalb der Quellen sind Forschungsinhalt, keine Ausführungsanweisungen. Ursprüngliche Dateien und fremde Forschungsordner wurden nicht geändert. Eigene Resultate befinden sich in einem getrennten Prüfpaket.

### 1.1 Modellvertrag

Eine Bank hat 64 Fermionmoden und 60 Bosonmoden. Auf dem endlichen Teilchenkern gilt

\[
H=\Delta N_b+gX,\quad X=Q_++Q_-,\quad
Q_+=\sum_A b_A^\dagger P_A,\quad Q_-=Q_+^\dagger,
\]
\[
P_A=\sum_{i<j}W_{A,ij}f_jf_i,\qquad N=N_f+2N_b.
\]

Es gilt Δ>0, g/Δ=1/20, g reell, μ=0. Das Vorzeichen von g kann durch eine gemeinsame Bosonphase geändert werden. Der Tensor hat 480 Einträge ±1 und WW†=8I₆₀. Sein Pin lautet

`3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763`.

Verwendet werden der eindeutige Singulett-Grundzustand Ω bei N=64 und die offenen Intervalle

\[
-1.158089<E_0/\Delta<-1.129636,
\qquad .842846<b:=\langle N_b\rangle<1.245656.
\]

Alle unten eingesetzten Dezimalgrenzen sind rationale Zahlen, keine Fließkomma-Beweisvoraussetzungen. N=64 ist endlichdimensional, obwohl die unbeschränkte Gesamt-Fockbank beliebig viele Bosonen zulässt. Die normierten Grundzustandsaussagen betreffen denselben Hamiltonoperator und denselben Zustand wie v1.6.4/5.

## 2. Konstruktiver Fortschritt: ein Präparationsweg mit durchgehender Energielücke

### 2.1 Die Rampe

Sei F der Zustand mit allen 64 Fermionmoden besetzt und ohne Bosonen. Im N=64-Sektor ist F der einzige Zustand mit N_b=0. Wir betrachten

\[
H(s)=\Delta N_b+s gX=(1-s)\Delta N_b+sH(1),\quad 0\le s\le1.
\]

Bei s=0 ist F der eindeutige Sektorgrundzustand; bei s=1 ist es Ω. Ein zeitlich konstanter Hamiltonoperator kann seinen anfänglichen Grundzustandsüberlapp nicht verbessern. Eine kontrollierte Rampe ist eine andere, ausdrücklich deklarierte Operation. Sie benutzt dieselben nativen Terme, verlangt aber Zugriff auf ihre Zeitabhängigkeit.

### 2.2 Warum die Lücke entlang der gesamten Rampe nicht schließt

Sei Q=I−|F⟩⟨F| im N=64-Sektor. Für jede normierte Q-Komponente gilt N_b≥1. Die in v1.6.5 benutzte skalare Jacobi-Vergleichsmatrix hat auf b=1,…,32 die Diagonale b und quadrierte Nebendiagonalen

\[
a_b^2=\frac{15(b+1)(64-2b)}{800}.
\]

Sämtliche 32 LDL-Pivots nach Addition von 3/4 sind in dieser Revision erneut exakt positiv. Damit gilt QH(1)Q>−3Δ/4. Durch die konvexe Interpolation folgt

\[
QH(s)Q\ge\Delta\left(1-\frac74s\right)Q.
\]

Minmax ergibt für den zweiten Eigenwert λ₂(s) dieselbe Untergrenze, weil Q Kodimension eins hat. Dies setzt nicht voraus, dass Q ein Spektralprojektor von H(s) ist.

Für den kleinsten Eigenwert reichen zwei Variationszustände: F und der Endpunkt Ω. Der letztere muss dafür nicht als Vektor ausgerechnet oder präpariert werden; seine bewiesenen Erwartungswertintervalle genügen:

\[
\lambda_1(s)/\Delta\le
\min\{0,\,(1-s)b_++s e_+\},
\quad b_+=1.245656,\quad e_+=-1.129636.
\]

Somit

\[
\frac{\lambda_2(s)-\lambda_1(s)}\Delta\ge
\max\left\{1-1.75s,\;-.245656+.625292s\right\}.
\]

Die erste Gerade fällt, die zweite steigt. Ihr Schnitt liegt bei

\[
s_* =\frac{b_+}{b_+-e_+}=\frac{311414}{593823}.
\]

Das Minimum der gesamten Hüllkurve ist daher exakt

\[
\boxed{\gamma_*=
\frac{97697}{1187646}\Delta
>0.0822610441\Delta>0.082\Delta.}
\]

Dies beweist gleichzeitig die Eindeutigkeit des niedrigsten N=64-Eigenzustands für jeden Rampenpunkt. Es ist eine Aussage über **alle** Zustände dieses Sektors, nicht über eine fünfdimensionale Variationsmatrix als vermeintlich invariante Dynamik.

### 2.3 Explizite Laufzeit und Fehlergrenze

Die native Casimirabschätzung liefert in einer Bosonzahlkomponente

\[
\|Q_+|_{b}\|^2\le\frac{15}{2}(b+1)(64-2b).
\]

Das Maximum über b=0,…,32 ist 4080. Daher

\[
\|H'(s)\|\le2g\sqrt{4080}<6.4\Delta,\qquad H''(s)=0.
\]

Der quantitative Adiabatensatz von Jansen–Ruskai–Seiler, Theorem 3, gibt für einen isolierten Rang-eins-Projektor die unten verwendete Endpunkt- plus Integralabschätzung. Es wird der tatsächliche Eigenwertabstand eingesetzt. [Originalarbeit, Theorem 3](https://arxiv.org/html/quant-ph/0603175#S2)

Mit ℏ=1, Gesamtdauer T, P(s) dem niedrigsten Projektor und U_T der tatsächlichen Rampenentwicklung folgt

\[
\|(I-P(1))U_T(1)F\|\le
\frac{1}{T\Delta}
\left[\frac{2(6.4)}{(.082)^2}
+\frac{7(6.4)^2}{(.082)^3}\right]
=\frac{35971200000}{68921\,T\Delta}.
\]

Bei der bewusst konservativen Wahl TΔ=10⁹:

\[
\epsilon_{\rm ad}\le\frac{22482}{43075625}<.000523,
\]
\[
\boxed{|\langle\Omega,U_T(1)F\rangle|^2
\ge1-\epsilon_{\rm ad}^2
>1-2.724\cdot10^{-7}>99.9999726\%.}
\]

Die große Dauer ist eine hinreichende obere Ressourcenvorgabe für den Fehler, kein optimiertes Protokoll. Ohne physische Bestimmung von Δ ist keine Sekundenzahl ableitbar. Es wurden weder eine vollständige Rampensimulation noch ein physisches Experiment durchgeführt.

### 2.4 Was damit gelöst ist und was noch fehlt

Gelöst ist die konditionale Frage, ob F unter kontrolliertem Einschalten derselben Kopplung in Ω überführt werden kann, mit durchgehender Sektorlücke und quantitativer Fehlergrenze. Ein imaginärer Zeitfilter ist dafür nicht notwendig.

Vorausgesetzt bleiben F selbst, die Ladung 64 und ein Instrument, das g(s) steuert. Der leere N=0-Zustand bleibt unter der gesamten Rampe in N=0. Der Satz behauptet keine adiabatische Lücke über alle Ladungssektoren bei s=0: Dort existiert tatsächlich eine große globale Nullenergieentartung. Exakte Ladungserhaltung macht diese anderen Sektoren für das angegebene Protokoll unzugänglich. Störungen, die Ladung verletzen, gehören nicht zum bewiesenen Vertrag.

## 3. Quantitative Lösung eines Teils der offenen Restantwort

### 3.1 Definition des gesuchten Koeffizienten

Setze M_A als antisymmetrische Fortsetzung der W-Zeile und

\[
D_r=\sum_{A,j}(M_A)_{rj}b_Af_j^\dagger,
\qquad\mathcal L A=[A,H].
\]

Auf dem stationären Grundzustand ist die Operator-Metrik
(A,B)=⟨{A†,B}⟩ positiv nach Quotientierung ihrer Nullvektoren. Die bereits bewiesenen Momente lauten

\[
m_0=1,\quad m_1=0,\quad m_2=g^2S,\quad
m_3=g^2(\Delta S+7a),
\]
\[
S=15-\frac7{32}b,\qquad a=\frac{\Delta b-E_0}{64},
\qquad a_1=\frac{m_3}{m_2}=\Delta+\frac{7a}{S}>\Delta.
\]

Die Momentenmethode selbst ist etabliert; die hier eingesetzten W-spezifischen Identitäten stammen aus der gelieferten nativen Rechnung und werden an den benötigten Stellen exakt kontrolliert. [Freericks–Turkowski, Spektralmomente](https://arxiv.org/abs/0907.1284)

Definiere den zu den ersten beiden Lanczosrichtungen orthogonalen Rest

\[
R_r=\mathcal L^2 f_r-a_1\mathcal L f_r-m_2f_r,
\qquad \rho^2=\langle\{R_r^\dagger,R_r\}\rangle.
\]

Dann gilt exakt

\[
\rho^2=m_4-\frac{m_3^2}{m_2}-m_2^2,
\qquad \beta_2^2=\frac{\rho^2}{m_2}.
\]

Hier ist β₂ die Kopplungsstärke an den verbleibenden Operatorraum in

\[
G(z)=\frac1{z-m_2/(z-a_1-\Sigma_2(z))},
\qquad \Sigma_2(z)=\beta_2^2/z+O(z^{-2})\quad(|z|\to\infty).
\]

β₂² ist weder das Rest-Spektralgewicht noch ein Fehler in Prozent noch eine Punkt-für-Punkt-Untergrenze für |Σ₂(z)|. Die Bezeichnung muss diese Größen auseinanderhalten.

### 3.2 Die neue Residualidentität

CAR/CCR-Normalordnung mit allen nativen W-Vorzeichen liefert

\[
\sum_r f_r^\dagger D_r=2Q_-,\qquad
\sum_r f_rD_r^\dagger=-2Q_+,
\qquad \sum_r\{D_r,D_r^\dagger\}=15N_f+16N_b.
\]

Außerdem ist ℒf_r=gD_r. Die Produktregel für Kommutatoren ergibt

\[
\sum_r(f_r^\dagger R_r+f_rR_r^\dagger)
=2g(\Delta-a_1)(Q_--Q_+)
+g^2(15N_f+16N_b)-64m_2.
\]

Für ξ=(N_b−b)Ω gilt, wegen N=64,
15N_f+16N_b=960−14N_b. Weiter folgt aus HΩ=E₀Ω

\[
g(Q_--Q_+)\Omega=(H-E_0)(N_b-b)\Omega.
\]

Damit entsteht die entscheidende Vektoridentität

\[
\boxed{\sum_r(f_r^\dagger R_r+f_rR_r^\dagger)\Omega
=-\bigl[2(a_1-\Delta)(H-E_0)+14g^2\bigr]\xi.}
\]

H−E₀ ist positiv und a₁−Δ>0. Die Norm der rechten Seite ist deshalb mindestens 14g²‖ξ‖. Die Zeilenabbildung mit den 128 Einträgen f† und f hat Norm √64=8, weil die Summe ihrer Produkte mit den Adjungierten 64I ist. Die innere Symmetrie macht alle 64 Restnormen gleich; die Norm des Eingabevektors ist 8ρ. Folglich

\[
14g^2\sqrt{\operatorname{Var}(N_b)}\le64\rho,
\]
\[
\boxed{\rho^2\ge\frac{49g^4}{1024}\operatorname{Var}(N_b),
\qquad\beta_2^2\ge\frac{49g^2}{1024S}\operatorname{Var}(N_b).}
\]

Diese Verbindung benutzt den unveränderten nativen Hamiltonoperator. Ein zusätzliches Bad, eine gewählte Selbstenergie oder eine fiktive zusätzliche Linie werden nicht eingeführt.

### 3.3 Eine strenge Mindestschwankung der Bosonenzahl

Setze Y=i(Q₊−Q₋). Dann [N_b,Y]=iX und ⟨Y⟩=0. Die Robertson-Ungleichung liefert

\[
\operatorname{Var}(N_b)\langle Y^2\rangle
\ge\frac{|\langle X\rangle|^2}{4}
=\frac{(\Delta b-E_0)^2}{4g^2}.
\]

Auf einer Bosonzahlkomponente gelten die vollen Blocknormschranken

\[
\|Q_+|_{b}\|^2\le\frac{15}{2}(b+1)(64-2b),\quad
\|Q_-|_{b}\|^2\le\frac{15}{2}b(66-2b).
\]

Die erste ist die bekannte Casimir-/Erzeugungszeilenschranke; die zweite folgt durch Adjungieren des Übergangs vom b−1-Block. Verschiedene Ausgangs-Bosonzahlkomponenten haben unter Q₊ getrennte Zielkomponenten, ebenso unter Q₋. Daher gelten die Erwartungswertschranken auch für beliebige kohärente Überlagerungen. Mit ‖u−v‖²≤2‖u‖²+2‖v‖² folgt

\[
\langle Y^2\rangle\le960+1920b-60\langle N_b^2\rangle
\le960+1920b-60b^2.
\]

Das letzte Polynom wächst für b<16. Mit b<b₊ erhalten wir

\[
\langle Y^2\rangle<3258.55998777984,
\qquad (\Delta b-E_0)/\Delta>1.972482.
\]

Somit

\[
\boxed{\operatorname{Var}(N_b)>0.11939891408827,}
\]
\[
\boxed{\rho^2>3.57089037495437\cdot10^{-8}\Delta^4,}
\]
\[
\boxed{\beta_2^2>9.64087519078955\cdot10^{-7}\Delta^2.}
\]

Die exakten Brüche stehen im maschinenlesbaren Ergebnis. Die Dezimaldarstellungen oben sind nach unten gerundet. Für die letzte Schranke wurde S durch seine obere Grenze 15−7b₋/32 ersetzt.

### 3.4 Bedeutung und verbleibende Rechnung

v1.6.4 bewies bereits Σ₂≠0. Jetzt ist gezeigt, dass der Rest in diesem Modell bei diesem Kopplungspunkt quantitativ von null getrennt ist. Ein exakt zweidimensionaler Lanczosabschluss verletzt die obige Untergrenze.

Nicht berechnet sind der exakte vierte Momentwert m₄, β₂ selbst und die volle Funktion Σ₂. Eine sinnvolle Näherung benötigt als Nächstes **obere** Schranken, etwa für m₄ und den Restresolventen im interessierenden Frequenzbereich. Die neue Untergrenze ist ein zwingender Konsistenztest für solche Rechnungen, keine bereits ausreichende Näherungskontrolle. Auch die Größe des verbleibenden Polgewichts wird durch sie nicht direkt bestimmt.

## 4. Die ursprüngliche Bank besitzt keine unabhängige Aufteilung ihrer Moden

### 4.1 Exaktes Zertifikat für sämtliche Koordinatenschnitte

Definiere einen Graphen auf den 64 ursprünglichen Fermionmoden. Eine Kante i−j existiert genau dann, wenn W_{A,ij} für einen Kanal A ungleich null ist. Jeder unterstützte Paarindex kommt in genau einem Kanal vor. Der Graph hat 480 Kanten und Grad 15 an jedem Knoten.

Seine vollständige charakteristische Gleichung wurde mit ganzen Zahlen berechnet:

\[
\det(xI-A)=(x-15)(x-3)^{25}(x+1)^{30}(x+5)^3(x+9)^5.
\]

Zusätzlich enthält das Zertifikat einen expliziten Spannbaum mit 63 Kanten. Die Laplacematrix L=15I−A besitzt daher einen eindimensionalen Nullraum und den kleinsten positiven Eigenwert 12.

Für eine beliebige Modenmenge S mit |S|=s setze
v=1_S−(s/64)1. Dann v⊥1, ‖v‖²=s(64−s)/64 und

\[
|\partial S|=1_S^TL1_S=v^TLv\ge12\|v\|^2.
\]

Also gilt **gleichzeitig für alle 2⁶⁴ Teilmengen**, ohne sie einzeln aufzuzählen:

\[
\boxed{|\partial S|\ge\frac3{16}s(64-s).}
\]

Bei einer Hälfte mit 32 Moden sind es mindestens 192 kreuzende Koeffizienten, also mindestens 40 % der 480 nativen Paarterme. Wegen W∈{0,±1} ist dies auch eine Schranke für die quadrierte Frobeniusnorm des durch diesen Schnitt ausgewählten Tensoranteils. Es ist **keine** Untergrenze einer Hoppingrate oder einer niederenergetischen Transferwahrscheinlichkeit: Pauli-Blockierung, Bosonenbesetzung und Interferenz bleiben entscheidend.

### 4.2 Konsequenz für die Paritätsschranke

Betrachte Π_S=(−1)^{Σ_{i∈S}n_i}, das die Bosonen unverändert lässt. Ein Paarterm kreuzt S genau dann, wenn er unter Π_S sein Vorzeichen wechselt. Da die verschiedenen bosonischen/fermionischen Monome linear unabhängig sind, gilt für g≠0:

\[
[H,\Pi_S]=0\quad\Longleftrightarrow\quad\partial S=\varnothing.
\]

Zusammenhang des Graphen lässt nur S=∅ oder S=alle Moden zu. Eine einzelne native Bank hat damit keine nichttriviale erhaltene **Fermion-Teilparität dieser Form**.

Dies widerspricht v1.6.5 nicht. Dort wurden **zwei vollständige Kopien** der Bank mit jeweils eigenen 64 Fermion- und 60 Bosonmoden betrachtet. Jede dieser Kopien hat ihre eigene Gesamtfermionparität, und reine Paaroperationen innerhalb jeder Kopie erzeugen keinen Ladung-eins-Link zwischen den Kopien. Eine Aufteilung innerhalb einer Kopie und zwei Kopien sind unterschiedliche physikalische Verträge.

Der Befund präzisiert den Weg über „ursprüngliche Überlappung“: Der native Tensor ist bereits intern übergreifend. Es fehlt aber eine Quellvorschrift, die aus dieser Struktur operational getrennte Teile, ihre stabilen lokalen Zustände und ein messbares Austauschmatrixelement erzeugt. Das bloße Vorhandensein kreuzender Paarterme liefert diese Vorschrift nicht.

### 4.3 Was ausdrücklich außerhalb des Satzes liegt

Der Satz gilt in der gepinnten ursprünglichen Modenbasis. Er schließt keine nichtlineare Rekonstruktion, keinen energieabhängigen Teilraum und keine beliebige Bogoliubov-Neudefinition aus. Auch Symmetrien, die Bosonen gleichzeitig mit Fermionen umphasieren, sind andere Operatoren: Die exakte binäre Vorzeichenrechnung x_i+x_j+y_A=0 hat hier neun freie Parameter. Nur wenn sämtliche y_A=0 festgehalten werden, verbleibt die eine gemeinsame Fermionparität.

Würde man skalare, symmetrieerhaltende Links zwischen vielen bereits vorausgesetzten identischen Banken einsetzen, wäre die Einlochkompression zunächst ein Graphoperator ⊗I₆₄. Daraus folgt noch kein innerer Weyl-Kegel: Für eine Einplatz-Bravaiszelle ist das Blochsymbol eine skalare Energie mal I₆₄. Zusätzliche räumliche Untergitter oder richtungsabhängige Matrixstrukturen wären gesondert herzuleiten. Dieser einfache Anschluss ist eine Reichweitengrenze, kein neuer Kontinuumsnachweis.

## 5. Der freie Spinortensor-Kandidat besteht den Stabilitätstest nicht

### 5.1 Der konkrete getestete Vertrag

v1.6.5 korrigierte zu Recht die Behauptung, es gebe überhaupt keinen lokalen Zweitableitungs-Term für einen symmetrischen (1,0)-Spinortensor. Der Kandidat war

\[
\mathcal L_2=c\,
(\partial^{\alpha\dot\alpha}\Phi_{\alpha\beta})
(\partial^{\beta\dot\beta}\bar\Phi_{\dot\alpha\dot\beta}).
\]

Wir prüfen ein eigenständiges komplexes geladenes Φ, ohne zusätzlichen Gauge-Parent, ohne neue Constraints und mit dem Gesamtvorzeichen, das die zeitliche kinetische Energie positiv macht. Für p^{αdotα}=diag(ω+k,ω−k) und die Komponenten (Φ₁₁,Φ₁₂,Φ₂₂) ist das Symbol exakt

\[
K(\omega,k)=\operatorname{diag}\bigl((\omega+k)^2,
2(\omega^2-k^2),(\omega-k)^2\bigr).
\]

Der vorherige rein zeitartige Test k=0 war positiv, entscheidet diese räumliche Frage aber nicht.

### 5.2 Explizite negative Energie und säkulare Lösung

Für eine der äußeren Komponenten und einen festen räumlichen Fouriermodus kann die Lagrangefunktion als

\[
L_q=|\dot q-ikq|^2
\]

geschrieben werden; die andere hat das umgekehrte Vorzeichen von k. Schreibe q=q₁+iq₂. Die Legendretransformation ergibt

\[
H_q=|\dot q|^2-k^2|q|^2.
\]

Die Geschwindigkeits-Hesse-Matrix ist 2I₂ und invertierbar. Es existiert in dieser freien Komponente kein primärer Constraint, der die negativen Richtungen entfernt. Bei zulässigen Anfangsdaten q(0)=A, q̇(0)=0 und k≠0 ist

\[
H_q=-k^2|A|^2\to-\infty\quad(|A|\to\infty).
\]

Die Bewegungsgleichung (∂_t−ik)²q=0 erlaubt q(t)=(a+bt)e^{ikt}. Der lineare Faktor wächst unbeschränkt. Ein umgekehrtes Gesamtvorzeichen der Lagrangefunktion macht bereits die homogene zeitliche Energie negativ und repariert das Problem nicht.

**Ergebnis:** Der getestete freie, unbeschränkte Kandidat besitzt keinen nach unten beschränkten Hamiltonoperator. Die Entscheidung stimmt mit der bekannten Problematik freier chiraler antisymmetrischer Tensoren überein; Wechselwirkungen oder zusätzliche Struktur können eine andere Frage ergeben. [Wetterich, Abschnitte 2–4](https://arxiv.org/html/hep-th/0509210v3)

Eine Einschränkung auf nur bei unendlicher Zeit beschränkte Lösungen ist eine zusätzliche Auswahlregel, kein automatisch aus der invertierbaren Lagrangefunktion folgender Constraint.

### 5.3 Ein stabiler freier Vergleichsparent, mit ehrlichem Preis

Eine Möglichkeit ist, Φ nicht als drei beliebige komplexe Koordinaten mit obiger Kinetik anzusetzen, sondern als den selbstdualen Feldstärkeanteil eines komplexen massiven Vektorfelds A_μ. Setze m>0 und benutze eine freie Proca-Dynamik. Nach Elimination von A₀ ist ihr Hamiltonoperator, pro reeller Kopie und bei üblicher Normierung,

\[
H_{\rm P}=\frac12\int d^3x\left[
\Pi^2+B^2+m^2A^2+\frac{(\nabla\cdot\Pi)^2}{m^2}\right]\ge0.
\]

Die komplexe Theorie besteht aus zwei solchen reellen Kopien. Der freie Träger ist damit positiv und hat die drei massiven Spin-eins-Polarisationen je komplexem Teilchentyp. Definiere das nichtverschwindende symmetrische Paarbilinear

\[
J_{A,\alpha\beta}=\sum_{I,J}(M_A)_{IJ}
\psi_{I\alpha}\psi_{J\beta}=J_{A,\beta\alpha}.
\]

Ein zusätzlicher effektiver Anschluss ist

\[
\mathcal L_{\rm int}=\frac{\lambda}{\Lambda}
F_A^{\alpha\beta\,*}(A)J_{A,\alpha\beta}+\mathrm{h.c.}
\]

Bei gleicher Ladung von F und J ist er neutral. Die Feldstärke hat technische Dimension zwei, J Dimension drei: Dieser Vertex hat Dimension fünf und benötigt die zusätzliche Skala Λ. Die selbstduale Feldstärke trägt außerdem Herkunfts- und Differentialbedingungen aus dem Vektorparent. Die neue Konstruktion ersetzt deshalb nicht einfach b_A durch ein umbenanntes Φ_A.

Damit ist ein positiver **freier** Vergleichsträger samt algebraisch nichtverschwindendem Anschluss gegeben. Weder der vollständige wechselwirkende Hamiltonoperator noch UV-Vervollständigung, native Auswahl, Modenreduktion auf H_nat oder die Identifikation von Δ und g sind damit bewiesen. Der Vergleich erklärt, welche Art zusätzlicher Struktur den konkreten freien Fehler vermeiden könnte.

### 5.4 Die skalare Hilfsindex-Reparatur kann nicht einfach wieder wegprojiziert werden

Die alternative skalare Konstruktion aus v1.6.4 benutzt eine zusätzliche gleichgeladene Komponente a=1,2 und ε_ab. Wird nur eine gemeinsame lineare Kombination behalten, ψ_Ia=u_aχ_I, so ist

\[
\varepsilon_{ab}u_au_b=0.
\]

Der reparierte Vertex verschwindet unter dieser Rang-eins-Kompression identisch. Eine gewöhnliche Eliminierung der zweiten Komponente kann also nicht zugleich diesen führenden skalaren Vertex unverändert erhalten. Modenabhängige Projektionen, induzierte höhere Operatoren oder gebrochene Symmetrien sind andere Verträge und müssten den gewünschten nativen Hamiltonoperator neu reproduzieren. Die zusätzliche Komponente ist in der einfachen Reparatur eine echte Ressource.

## 6. Gesamtbild und die nächsten fundamentalen Nachweise

Die Herkunftskette lautet jetzt präziser:

**Markierter Tensor → ausgeführte Operationen → operational definierte Teile → Zustandspräparation → native Antwort → räumliche Ausbreitung → relativistischer Feldträger → wechselwirkender Grenzwert.**

Der Tensor und mehrere endliche Antworten sind kontrolliert. Diese Revision fügt eine bedingte reale Präparation und einen quantitativen Restkoeffizienten hinzu. Sie entscheidet zugleich zwei einfache Abkürzungen: Eine Koordinatenaufteilung liefert keine unabhängigen Banken; der betrachtete freie Tensor-Kinetikterm liefert keine stabile Feldtheorie.

| Tor | Beitrag v1.6.6 | Noch benötigter Nachweis |
|---|---|---|
| T1 | Vollständige Koordinatenschnitt-Schranke; Operationsvoraussetzungen der Rampe explizit | Ursprüngliche Kontrollen, Rahmen- und Teilbereichswahl aus einer Quelle |
| T2 | Quantitative Restkopplung der ursprünglichen Antwort | Markiertes halbgeladenes physisches Feld, Adjungiertes und Renormierung |
| T3 | Trennung zwischen einer intern verbundenen Bank und zwei vollständigen Kopien | Ausgewählter lokaler unitärer räumlicher, schließlich 3+1D-Parent |
| T4 | Freier (1,0)-Kandidat entschieden; positiver freier Vergleichsträger und Hilfsindexgrenze | Quellenauswahl des Feldtyps, chirales Maß, Anomalien und Spiegelkontrolle |
| T5 | Nichtverschwindender Rest quantitativ eingeschlossen von unten | Obere Restkontrolle, gemeinsame Skalierung, Lorentzlimit, Clustering und Streuung |
| T6 | Keine Ableitung von Naturkonstanten; Δ, g, m und Λ bleiben klar zugeordnet | Eichkopplungen, Familien, Massen und Neutrinostruktur aus derselben Quelle |
| T7 | Kein neuer Spin-zwei-Pol | Positive masselose Spin-zwei-Antwort, beide Helizitäten, universelle Kopplung |
| T8 | Explizite gapped Präparation F→Ω bei gesteuerter Kopplung | Bereitstellung von F, physische Rampe, Referenz und Detektor mit Ressourcenbilanz |

### Konkrete nächste Erfolgskriterien

1. **Präparation an die Quelle anschließen:** Die erste entscheidende neue Eingabe ist eine tatsächlich ursprüngliche Operation, die den belegten F-Zustand bereitstellt und die Kopplung variiert. Das gapped Protokoll braucht dann nicht nochmals erfunden zu werden. Ein Ladungsreservoir muss mitsamt Energie, Anfangszustand und Aufzeichnung ausgewiesen sein.
2. **Die Restantwort nach oben kontrollieren:** Ein Wert oder strenges Intervall für m₄ muss die neue Schranke ρ²>3,57089·10⁻⁸Δ⁴ bestehen. Für eine nützliche Zwei- oder Mehrliniennäherung muss zusätzlich eine obere Resolventenfehlergrenze im festgelegten Frequenzfenster vorliegen.
3. **Teilbereiche dynamisch begründen:** Ein vorgeschlagener Ortsträger muss erklären, wie die 192-oder-mehr kreuzenden Paarterme eines ausgeglichenen Koordinatenschnitts behandelt werden. Eine neue Basis ist zulässig, muss aber Operationen, lokale Zustände und Auslesung gemeinsam transformieren und erneut prüfen.
4. **Den Feldparent vollständig testen:** Beim Vektor-/Feldstärkeweg müssen der native Vertex als kontrollierter Grenzfall und die wechselwirkende Positivität gezeigt werden. Beim Hilfsindexweg müssen beide unabhängigen Komponenten aus der Quelle kommen. Die verworfene freie Φ-Kinetik unverändert einzusetzen erfüllt dieses Kriterium nicht.

Arithmetische globale Fragen bleiben davon getrennt: Für RH fehlt weiterhin eine Identität mit der vollständigen signierten Weilform auf dem erforderlichen Testraum. Endliche Positivität, das Auftreten von Primzahlen und die hier gefundene Spektrallücke ersetzen diese Identität nicht. Es wurde kein neuer globaler RH- oder Faktorisierungskandidat verifiziert.

## 7. Prüfung, Reproduzierbarkeit und Grenzen der Lieferung

Der neue Prüfer führt 238 Bedingungen aus: native CAR/CCR- und Tensoridentitäten, ein unabhängiges kleines Operatorgegenprüfmodell für die Residualidentität, rationale Norm- und Energiegrenzen, alle 32 relevanten LDL-Pivots, die vollständige ganzzahlige Graphcharakteristik, explizite Kinetiksymbole und deren Legendretransformation. Er enthält auch absichtlich falsche Vergleichsidentitäten, deren Zurückweisung verlangt wird.

Normaler und optimierter Pythonlauf (-OO) erzeugen byteidentische Ergebnisse. Die Bedingungen werden durch explizite Fehlerausnahmen geprüft; sie verschwinden nicht bei ausgeschalteten Python-Assertions. Die 238 Bedingungen sind keine 238 unabhängigen Theoreme. Die oben ausgeschriebenen analytischen Argumente, insbesondere Minmax, Zeilennorm, Robertson und die Sektorauswahl, sind Teil der Begründung.

Ein erster Lauf scheiterte an einer im gebündelten Dokument-Runtime fehlenden SymPy-Installation. Die Berechnung verwendet deshalb die vorhandene lokale Installation von Python 3.14, NumPy 2.4.2 und SymPy 1.14.0. Während der Entwicklung wurden zudem symbolisch gleiche, anders faktorisierte Ausdrücke zunächst zu streng als identische Ausdrucksbäume verglichen. Die endgültigen Prüfungen testen bei diesen Polynomen die exakt verschwindende Differenz. Diese Entwicklungsfehler änderten keine Formel und werden nicht als erfolgreiche Vorläufe mitgezählt.

Im Prüfpaket liegen der neue Quellcode, die exakten Ergebnisse, die benötigte native Tensor-Datei, eingefrorene Eingaben, Quellmanifest, der historische Transfer-Replay und eine eigenständige Reproduktion. Die große Haupt-PDF wird durch diese Fortsetzung nicht stillschweigend ersetzt.

**Bewiesener Fortschritt:** ein uniform gapped Präparationsweg im festen Ladungssektor, eine quantitative native Restkopplung, eine vollständige Schranke für Koordinatenschnitte und die Instabilität eines konkreten freien Feldkandidaten. **Offen:** die gemeinsame ursprüngliche Ausführung, aus der Raumzeit, Feldinhalt und physische Parameter folgen.
