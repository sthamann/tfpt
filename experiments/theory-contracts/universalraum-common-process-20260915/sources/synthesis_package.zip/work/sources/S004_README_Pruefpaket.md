# Universalraum Beweisversuch, 15. September 2026

Zuerst Universalraum_Ergebnis_einfach_2026-09-15.md oder den technischen Bericht lesen.
Die allgemeinen Beweise stehen im Bericht; die Computerprüfungen kontrollieren endliche und symbolische Fälle.
Kein RH-Beweis, keine vollständige TOE, kein neuer Faktorisierungsalgorithmus.

## Eigene ergänzende Prüfungen

Vom entpackten Paketverzeichnis: python3 work/replay_new_proofs.py
Benötigt Python, NumPy und SymPy. Der gepinnte Tensor liegt im mitgelieferten Arbeitsordner.

## Originalreproduktionen

Der enthaltene v1.6.4-Arbeitsordner bewahrt die Originalprüfer und die frischen Resultate.
Die vollständigen ursprünglichen Replays benötigen die in ihren Manifesten genannten ursprünglichen lokalen Quellpfade sowie SciPy und Apple clang/libdispatch.
Die eigenen ergänzenden Prüfungen haben diese externen Pfadabhängigkeiten nicht.
verification_summary.json bestätigt den Bytevergleich von neun fachlichen Ergebnisdateien mit dem zugelieferten Archiv.

Die Originaleingaben wurden nicht geändert. input_manifest.json enthält ihre Hashes.
