# TFPT: Vom geometrischen Compiler zum Prozess mit Aufzeichnung

## Eine integrierte Darstellung von Grundlagen, Clocks, Standardmodell-Zuordnungen, Vorhersagen und Universalraum

Forschungsmanuskript · Version 1.2 · 14. September 2026

Zusammenstellung für Stefan Hamann auf Grundlage des TFPT-Repositoriums und der dort dokumentierten Forschungsprüfungen. Redaktion und neue Konsistenzprüfungen: Codex. Kein begutachteter Abschlussbeweis einer Theory of Everything.

### Leseweg und Evidenzkonvention

Kapitel 1–4 erklären die Grundstruktur, Kapitel 5–7 das Standardmodell und die Zahlen, Kapitel 8–12 die Universalraum-Verbindung. Kapitel 13–15 beschreiben das Gesamtbild, die offenen Beweispflichten und konkrete Anschlussarbeiten. Die Anhänge enthalten Quellen und Reproduktionsangaben.

Vier Wörter markieren die Bedeutung einer Aussage: **gesetzt** bezeichnet eine Ausgangsannahme; **exakt** eine Identität oder einen Beweis innerhalb ausdrücklich genannter Voraussetzungen; **bedingt** eine Folgerung mit zusätzlicher physikalischer Zuordnung; **offen** eine noch nicht geschlossene Herkunfts- oder Existenzfrage. Numerische Überprüfung ist eine weitere Evidenzform, kein Ersatz für einen allgemeinen Beweis. Ein exakt ausgerechneter Modellwert kann empirisch falsch sein. Ein passend aussehender Messwert beweist die physikalische Herkunft seiner Formel nicht.

### Neu in Version 1.2

Diese Fassung vereinigt das bisherige Gesamtpaper mit dem unabhängig geprüften Sechs-Quellen-Nachtrag. Die Grundlagen, Clocks, Standardmodell-Zuordnungen und Zahlen bleiben enthalten. Der Nachtrag N1–N8 enthält den allkoppligen Zweizellensatz, die Korrektur der History-Aufzeichnung, die explizite lokale U-Regel, Gegenmodelle und die aktualisierte Zuordnung aller offenen T1–T8-Nachweise. Frühere PDFs werden nicht überschrieben. Die sechs eingesandten Texte sind unverändert archiviert; ihre Aussagen sind Forschungsinput, nicht sechs unabhängige Bestätigungen.

### Zusammenfassung

TFPT untersucht, inwieweit eine kleine geometrisch-algebraische Ausgangsstruktur die Vielfalt physikalischer Strukturen und dimensionsloser Zahlen organisieren kann. Ausgangspunkt sind ein orientierter Rand, seine Normierung und ein fünfteiliger Träger. Über Spinoren, Gitterverklebung, endliche Symmetrien und zyklische Operationen entsteht ein als Compiler bezeichnetes System. Es liefert unter festgelegten Regeln konkrete Zuordnungen zum Standardmodell und numerisch auswertbare Formeln. Die Universalraum-Forschung fragt ergänzend, welches gemeinsame Objekt diese algebraischen, geometrischen und dynamischen Ansichten tragen könnte.

Dieses Manuskript führt beide Linien zusammen, ohne ihre Voraussetzungen zu vermischen. Es unterscheidet die exakte Berechnung innerhalb eines Modells von der Herleitung des Modells aus einer physikalischen Quelle und von seinem Erfolg an Messdaten. Als besonders konkrete Verbindung wird eine Konstruktion auf den tatsächlichen 60 Quellstrahlen des endlichen Compilers dargestellt: Ein Prozess mit 15 Messkontexten besitzt sowohl einen klassischen Kontext- als auch einen quantenmechanischen Zustandsschatten. Die zugehörige Vor-Messung lässt sich mit bekannten Spiegelungen und einer einfachen Kopplung zwischen Registern schreiben. Frische gegenüber wiederverwendeten Aufzeichnungsregistern erzeugen jedoch unterschiedliche reduzierte Dynamiken. Damit wird die fehlende Zusammensetzungsregel sichtbar, statt sie als bereits hergeleitet vorauszusetzen.

Die Synthese ergibt ein kompaktes Forschungsbild: Ein beträchtlicher Teil der endlichen Algebra ist konstruiert; mehrere dimensionslose Formeln sind präzise und falsifizierbar; die gemeinsame mikroskopische 3+1-dimensionale Dynamik, ihr physikalischer Zustand und ihre vollständigen Ausleseregeln sind nicht konstruiert. Alle physikalischen Abschlussbedingungen T1–T8 bleiben offen. Der erfolgversprechende nächste Schritt ist eine quellenseitige Auswahl von Trägerkopplung, Aufzeichnung und Zustandspräparation, nicht die Einführung weiterer unverbundener Zahlenformeln.

Die Revision vom 14. September integriert einen vom Nutzer übermittelten Erweiterungsvorschlag und dessen unabhängige Nachrechnung. Neu sind die vollständige endliche Spektrallösung, die Unterscheidung dreier Präparationsprotokolle und ein ausdrücklich zusätzlich gesetztes Vierträger-Austauschmodell. Dieses besitzt einen eindeutigen antisymmetrischen Grundzustand, jedoch keine automatisch grundzustandspräparierende Dynamik. Weiterführend werden sein 70-dimensionaler Teilchensektor, eine bilineare Darstellung durch tatsächliche Quelloperatoren und eine analytische Stabilitätsgrenze für zwei gekoppelte Zellen bestimmt. Die Zusendung wird als Forschungsinput zugeschrieben, nicht als extern begutachteter Beweis behandelt. [L9, L10]

## 1. Das Gesamtbild: Bauplan, Ausführung und Schatten

Die einfachste bildliche Darstellung ist eine Spieluhr. Der Compiler entspricht dem präzise geschnittenen Zahnrad- und Nockenwerk. Seine Geometrie bestimmt, welche Bewegungen zusammenpassen und welche Muster sich wiederholen. Die Clocks sind solche Wiederholungsstrukturen. Die physikalische Dynamik ist aber nicht allein das Zahnrad: Es braucht die Kopplung der Teile, einen Zustand, eine Ausführung und eine Verbindung zu messbaren Größen. Eine Spieluhrzeichnung erzeugt noch keinen Ton.

Mit „Schatten“ ist hier etwas mathematisch Bestimmtes gemeint: Aus einem gemeinsamen Zustand oder Prozess wird durch eine Abbildung nur ein Teil der Information ausgelesen. Ein klassischer Übergang kann beispielsweise die Häufigkeiten von Kontexten sehen, während ein Dichteoperator andere Informationen über den Zustand enthält. Beide können aus demselben größeren Prozess stammen, ohne ineinander umkehrbar zu sein. Gleiche Schatten identifizieren deshalb im Allgemeinen nicht eindeutig ihr Ursprungsobjekt.

Die Integrationshypothese lautet: Geometrie, Symmetrien, Zahlen und effektive Dynamik könnten unterschiedliche Auslesungen einer einfacheren gemeinsamen Struktur sein. Die Forschung hat einige solche Auslesungen exakt verbunden. Sie hat aber nicht bewiesen, dass ein einziges bereits ausgewähltes Objekt alle physikalischen und arithmetischen Phänomene erzeugt. Die entscheidende Frage ist daher nicht nur „Welche schöne Matrix passt?“, sondern „Welche Quelle wählt ihre zulässige Zusammensetzung und ihre beobachtbare Ausführung aus?“ [L1–L7]

| Ebene | Was dort festgelegt wird | Was daraus noch nicht folgt |
| --- | --- | --- |
| Ursprung | Rand, Orientierung, Träger, Normierung | Warum die Natur gerade diese Daten wählt |
| Compiler | Darstellungen, Gitter, Projektoren, zyklische Operationen | Eine universelle physikalische Bewegungsgleichung |
| Prozess | Kopplung, Zustand, Register und Ausführungsregel | Eine eindeutige Quelle dieser Zusatzdaten |
| Schatten | Häufigkeiten, Dichteoperatoren, effektive Parameter | Rekonstruktion sämtlicher verborgener Information |
| Physik | Lokale Felder, Einheiten, Messprotokolle, Grenzwerte | Wird nicht allein durch ähnliche Dimensionszahlen bewiesen |

## 2. TFPT-Basics: Randnormierung und fünfteiliger Träger

Die historische Architektur organisiert sich um zwei Eingaben:

$$c_3=\frac{1}{8\pi},\qquad g_{\rm car}=5.$$

P1 ist nicht bloß die Dezimalzahl c₃. Es postuliert einen orientierten Rand beziehungsweise eine Naht, einen geeigneten positiven Randkern und eine Normierung. P2 setzt einen fünfteiligen Träger voraus, mit einer später als drei Farb- und zwei schwache Richtungen gelesenen Zerlegung. Die mathematischen Konsequenzen einer solchen Schnittstelle sind von ihrer physikalischen Auswahl zu unterscheiden. Ältere Aussagen, alle weiteren Ergebnisse seien allein aus „zwei Zahlen“ bewiesen, unterschlagen zusätzliche Struktur- und Auslesevoraussetzungen. [L1, L2]

Eine kompakte alternative Buchhaltung verwendet den Anker a = (1,1,2). Seine elementarsymmetrischen Größen sind 4, 5 und 2; die Potenzsummen sind pₙ = 2 + 2ⁿ. Daraus erhält man beispielsweise p₁p₂p₃ = 240 und 240 + p₄ − p₃ = 248. Diese Identitäten sind exakt. Sie erklären jedoch noch nicht, warum ein beliebiger Datensatz mit diesen Zahlen ein E₈-Wurzelsystem sein müsste. Erst die Konstruktion von Wurzeln, Skalarprodukt und zulässigen Operationen trägt diese Identifikation. Ebenso ist eine äquivalente Kodierung der Postulate keine Herleitung ihrer Auswahl.

Der fünfteilige komplexe Träger hat eine gerade äußere Algebra:

$$S^+=\Lambda^{\rm even}\mathbb{C}^5,\qquad \dim S^+=1+10+5=16.$$

Diese 16 Dimensionen passen zur chiralen Spinordarstellung von Spin(10). Der TFPT-Familienzähler liefert im gewählten Aufbau (16−1)/5 = 3 und damit 48 Familienzustände vor einer Verdopplung. Der Zähler allein beweist keine drei propagierenden Familien: Dafür sind die konkrete Darstellungszuordnung, die Auswahl der Sektoren und schließlich die chirale Dynamik notwendig.

**Einheiten bleiben eine eigene Schnittstelle.** Eine reine dimensionslose Konstruktion kann Verhältnisse liefern. Ein Wert in GeV, Sekunden oder Metern verlangt eine dimensional kalibrierte Größe oder einen separat hergeleiteten Bezug zu einer solchen. In den vorhandenen Zahlenprogrammen wird die reduzierte Planckmasse extern eingesetzt. Diese Eingabe muss auch dann sichtbar bleiben, wenn die dimensionslosen Exponenten intern berechnet werden.

## 3. Was der E₈-Compiler tatsächlich zusammenfügt

„Compiler“ bezeichnet hier keine Behauptung, das Universum sei ein gewöhnlicher Computer. Gemeint ist eine determinierte Übersetzung zwischen verschiedenen mathematischen Beschreibungen: Trägerdaten werden zu Darstellungen, diese zu Gitter- und Symmetriedaten und anschließend zu auswählbaren Ausgaben. Seine Stärke liegt darin, dass dieselben diskreten Daten an mehreren Stellen wiederkehren und damit Konsistenzbedingungen erzeugen.

Die architektonische Verklebung verbindet D₅ und A₃. Die Determinanten der Wurzelgitter sind jeweils 4; ein Index-4-Überverband des orthogonalen Produkts hat folglich Determinante 1. Mit der passenden geraden Verklebung entsteht das positive gerade unimodulare Gitter vom Rang 8, also E₈. Das sind mehr Informationen als die bloße Rangsumme 5+3=8. Die Verklebungsform und ihre Verträglichkeit sind wesentlich. [L1]

Die zugehörige komplexe Lie-Algebra besitzt die Zerlegung

$$248=(45,1)+(1,15)+(16,4)+(\overline{16},\overline{4})+(10,6).$$

Die Dimensionsprüfung lautet 45+15+64+64+60=248. Die Formel erklärt, weshalb Spinoren, ein vierteiliger Partner und weitere Tensorsektoren gemeinsam auftauchen. Sie beweist nicht, dass alle diese Komponenten unabhängige leichte Teilchen sind. Insbesondere muss eine physikalische Konstruktion erklären, welche Komponenten überleben, welche sich paaren und warum keine unerwünschten Spiegel-Fermionen bleiben.

Eine zweite, endliche Darstellung verwendet einen markierten Raum über dem Zweierkörper: V = F₂⁴ mit symplektischer Paarung, quadratischer Verfeinerung und Clock-Aktion. Die Gaußsche Darstellung des E₈-Wurzelbaus liefert in einem festgehaltenen komplexen Viererträger 60 Strahlen in 15 orthogonalen Vierergruppen. Diese sind tatsächlich Zwei-Qubit-Stabilizer-Kontexte. Die 15 Kontexte dürfen nicht stillschweigend mit den 15 einzelnen nichttrivialen Pauli-Operatoren identifiziert werden: Punkt- und Geradenansicht sind verwandte, aber verschieden wirkende Darstellungen. Genau dieser Unterschied ist für eine korrekte Prozesskonstruktion wichtig. [L6]

Das Paper verwendet die endliche und die Lie-algebraische Darstellung als verbundene Strukturebenen. Es behauptet keine automatische Gleichheit ihrer dynamischen Zustandsräume.

## 4. Clocks, Logarithmen und der Unterschied zwischen Takt und Zeit

Eine Clock ist zunächst eine ausgezeichnete Operation mit zyklischer Struktur. Im markierten endlichen Compiler erscheint eine Ordnung-3-Aktion σ; ein gebräuchlicher Lift c besitzt Ordnung 12 und erfüllt σ = c⁴. Zentralphasen eines Lifts können bei der Wirkung auf beobachtbaren Operatoren verschwinden. Deshalb sind die Ordnung einer Matrix, die Ordnung ihrer projektiven Klasse und die Periodizität ihrer Konjugationswirkung drei getrennt zu prüfende Aussagen. [L1, L5]

Für einen komplexen Lift der Form c = iσ mit σ³ = I gilt c⁴ = σ. Seine Konjugationswirkung verliert die skalare Phase i und hat höchstens Ordnung 3. Der Buchstabe „Clock“ garantiert somit weder zwölf unterscheidbare physikalische Takte noch eine Zeit in Sekunden. Das Beispiel illustriert einen Strukturunterschied, keine universelle Normalform jedes in älteren Papern verwendeten Clock-Operators.

Multiplikative Wiederholung erzeugt dagegen auf natürliche Weise logarithmische Raten. Wenn eine Mode je Schritt mit λ multipliziert wird, dann ist ihre Amplitude nach n Schritten λⁿ. Für 0<λ<1 kann man schreiben:

$$\lambda^n=e^{-n\Delta},\qquad \Delta=-\log\lambda.$$

So entstehen die im Korpus auftauchenden Größen 6 log(3/2) und 6 log 3 aus sechsfachen Faktoren (2/3)⁶ beziehungsweise (1/3)⁶. Das ist eine exakte Übersetzung zwischen Multiplikation und Addition. Erst ein festgelegter physikalischer Zeitschritt τ macht daraus eine Zerfallsrate Δ/τ. Ohne τ ist Δ dimensionslos; ohne eine Quellkopplung ist auch nicht klar, welche beobachtbare Mode gemeint ist.

Die Universalraum-Prüfungen zeigen außerdem, dass nicht jeder reduzierte Schritt eine kontinuierliche Markov-Dynamik besitzt. Für den später behandelten Kontextschritt K gibt es negative Eigenwerte. Sein Quadrat ist in eine reelle Markov-Halbgruppe einbettbar, K selbst aber nicht als Exponential einer reellen Matrix auf demselben 15-dimensionalen Zustandsraum. Ein formal eingeführtes −log K wäre deshalb keine unproblematische Definition einer physikalischen Energie.

**Zusammenhang:** Die Clock ordnet algebraische Wiederholung; der Prozess legt fest, was wiederholt wird; die physikalische Zeit verlangt zusätzlich eine operational kalibrierte Zeitstruktur. Diese drei Ebenen zusammenzubringen ist eine Forschungsaufgabe, keine Umbenennung.

## 5. Standardmodell: Ladungen, Familien und noch fehlende Dynamik

Die 3+2-Zerlegung des Fünferträgers erlaubt die Hyperladungszuordnung −1/3 auf den drei Farbplätzen und +1/2 auf den zwei schwachen Plätzen. Aus den äußeren Potenzen entstehen die bekannten Ladungsmuster einer Spin(10)-Familie. In einer Konvention ausschließlich linkshändiger Weyl-Felder lautet das physikalische Wörterbuch:

| Feld | SU(3) × SU(2) | Hyperladung Y | Anzahl komplexer Komponenten |
| --- | --- | --- | --- |
| Q | (3,2) | 1/6 | 6 |
| uᶜ | (3̄,1) | −2/3 | 3 |
| dᶜ | (3̄,1) | 1/3 | 3 |
| L | (1,2) | −1/2 | 2 |
| eᶜ | (1,1) | 1 | 1 |
| νᶜ | (1,1) | 0 | 1 |

Die Summe ist 16. Mit diesen Multiplizitäten verschwinden die lineare und kubische Hyperladungsanomalie:

$$\sum_f d_fY_f=0,\qquad \sum_f d_fY_f^3=0.$$

Auch die gemischten SU(3)²U(1)- und SU(2)²U(1)-Summen verschwinden. Der SU(3)³-Beitrag ist 2−1−1=0; vier schwache Dubletts einschließlich Farbmultiplikität ergeben eine gerade Anzahl. Die kanonische Normierung folgt aus Tr Y² = 10/3 und Tr T₃² = 2 als kY = 5/3. Diese Prüfungen werden für das neue Manuskript exakt rational wiederholt. Sie validieren die Tabelle, nicht die Existenz eines nichtperturbativen chiralen Feldmaßes. [L2; externe Konvention: E5]

Die Eichalgebra su(3) ⊕ su(2) ⊕ u(1) hat 8+3+1=12 Generatoren. Dreimal dieselbe Familienstruktur ergibt 48 Weyl-Komponenten; eine geeignete konjugierte beziehungsweise verdoppelte Darstellung kann 96 Komponenten besitzen. Diese 96 sind nicht die 16 Zustände des endlichen Vier-Qubit-Registers und nicht die 70 Zustände eines später diskutierten fermionischen Sektors. Gleiche Benennungen wie „Träger“ dürfen die Räume nicht vermischen.

Für die behauptete physikalische Ableitung fehlt insbesondere die gemeinsame Antwort auf drei Fragen: Warum ist diese chirale Familie dynamisch und nicht ihre unerwünschte Spiegelkopie? Welche quellenseitige Wirkung erzeugt ihre Eich- und Yukawa-Wechselwirkungen? Wie überlebt diese Konstruktion den wechselwirkenden 3+1D-Kontinuumsgrenzwert? Endliche Darstellungsidentitäten und Anomaliesummen beantworten diese Fragen nicht allein.

## 6. Flavor-Compiler und elektromagnetischer Fixpunkt

Der gemeinsame kleine Flavor-Seed ist im eingefrorenen Formelstand

$$\varphi_0=\frac{1}{6\pi}+48c_3^4,\qquad \lambda_Y=\sqrt{\varphi_0(1-\varphi_0)}.$$

Der gleiche Ausdruck wird als führender Cabibbo-Parameter λC verwendet. Daraus folgt φ₀ ≈ 0,05317195 und λC ≈ 0,22437624. Die Wiedernutzung desselben Seeds ist eine prüfbare Verknüpfung: Ein späteres Ändern des Seeds verändert mehrere Vorhersagen gleichzeitig. Die Herkunft des gesamten Kontaktterms und seine physikalische Auslesung sind trotzdem nicht durch das Ausrechnen des Ausdrucks erledigt.

Der Massenansatz organisiert Quellmassen mit einer Leiter aus Restklassen und Windungen:

$$\widehat m_{f,j}=\frac{v_{\rm geo}}{\sqrt{2}}\lambda_Y^{L_{f,j}}\Lambda_{f,j},\qquad L_{f,j}=r_{f,j}+6n_{f,j}.$$

Die Faktoren Λ sind sektorabhängige Amplituden, nicht automatisch 1. Zur physikalischen Masse gehören außerdem die Bedeutung von vgeo, Schwellen, Renormierung und die Überführung in ein Pol- oder laufendes Massenschema. Der Hinweis auf eine „Masterformel“ darf diese Informationen nicht verstecken. Die Restklassenmatrix R hat die Zeilen (1,3,0), (1,5,2), (2,5,3), Determinante 8 und charakteristisches Polynom x³−9x²+10x−8. Das sind exakt prüfbare interne Daten; das Polynom allein ist kein experimenteller CKM-Nachweis. [L2]

Für die elektromagnetische Kopplung legt der Korpus eine konkrete Schließungsgleichung fest. Zur Vermeidung einer Verwechslung bezeichnet α hier die kleine Kopplung, nicht ihren Kehrwert:

$$q(\alpha)=48c_3^4 e^{-2\alpha},\qquad \varphi_s(\alpha)=\frac{1}{6\pi}+q(\alpha)(1-q(\alpha))^{-5/4}.$$

$$F(\alpha)=\alpha^3-2c_3^3\alpha^2-\frac{4}{5}\,41c_3^6\log\frac{1}{\varphi_s(\alpha)}=0.$$

Die positive Zielwurzel ergibt α⁻¹ = 137,0359992168407… . Das Manuskript reproduziert diese numerische Wurzel mit hoher Präzision und prüft den Restfehler. In Version 1.1 kommt ein eigener elementarer Eindeutigkeitsbeweis für die festgelegte Gleichung hinzu, siehe Anhang C. Insbesondere ersetzt die Eindeutigkeit einer vorgegebenen Gleichung nicht den noch offenen Nachweis, dass genau diese Gleichung die physikalische Thomson-Kopplung beschreibt.

Als explizit datierter Vergleich dient CODATA 2022 mit α⁻¹ = 137,035999177(21). Die Differenz beträgt etwa 1,90 experimentelle Standardabweichungen. Das ist ein bemerkenswert naher Modellwert, aber kein exakter Treffer und ohne vollständig kontrollierte Theorieunsicherheit kein globaler Gütenachweis. [E1]

## 7. Konkrete Ausgaben und ihre empirische Bedeutung

Die folgende Auswahl enthält zentrale quantitative Aussagen, keine vollständige Liste jeder historischen TFPT-Phänomenologie. Zahlen sind gerundet; reproduzierbare Werte stehen im begleitenden JSON. „Formelwert“ bedeutet: aus der angezeigten Formel berechnet. Die physikalische Identifikation bleibt in jeder Zeile eine weitere Behauptung.

| Größe | Formel oder Modellzweig | Ausgabe | Grenze der Aussage |
| --- | --- | --- | --- |
| α⁻¹ | positive Zielwurzel F=0 | 137,0359992168 | Ursprung der Schließung und Thomson-Übertragung offen |
| λC | √[φ₀(1−φ₀)] | 0,22437624 | Führender Flavor-Ansatz; vollständiger CKM-Vergleich nötig |
| s₂₃ CKM | φ₀/(1+λC) | 0,0434278 | Nicht stillschweigend mit jedem Vcb-Fit identisch setzen |
| s₁₃ CKM | λC³/3 | 0,00376538 | Standardparametrisierung ausdrücklich vorausgesetzt |
| δ CKM | π/3+3λC² | 68,6536° | Nicht derselbe Winkel wie γ des Unitaritätsdreiecks |
| mμ/mτ | (8/7)φ₀ | 0,0607679 | Quellverhältnis; Polwert ungefähr 0,05946 |
| me/mμ | (12/7)φ₀² | 0,00484673 | Quellverhältnis; Polwert ungefähr 0,004836 |
| mu/md | 55/117 | 0,470085 | Vergleich nur in gemeinsamem Massenschema |
| mc/ms | (34/47)/φ₀ | 13,6050 | Schemakontrollierte Übertragung nötig; historische Spannung |
| mt/mb | (3/26)/φ₀² | 40,8115 | Keine Mischung von Pol- und laufenden Massen |
| sin²θ₁₂ PMNS | 1/3−φ₀/2 | 0,30674736 | Günstige Nähe zum datierten Neutrinofit |
| sin²θ₁₃ PMNS | φ₀ exp(−5/6) | 0,02310844 | Nicht alle Mischungswinkel sind gleich gut getroffen |
| sin²θ₂₃ PMNS | symmetrischer Zweig | 0,5 | Maximalitätsansatz, empirisch zu prüfen |
| δ PMNS | ausgewählter Phasenzweig | 240° | Zusätzliche Phasen- und Sektorzuordnung |
| β | φ₀/(4π) Radiant | 0,242435° | Birefringenz-Lesart und Transferfunktion erforderlich |
| Ωb | (1−1/(4π))φ₀ | 0,04894066 | Ωb ist nicht Ωb h² |
| ns | 1−2/N, N=50…60 | 0,9600…0,9667 | Führende Inflation, N/reheating nicht beseitigt |
| r | 12/N², N=50…60 | 0,00333…0,00480 | Derselbe bedingte Inflationszweig |
| As | N²c₃⁷/(24π²), N=51,4 | 1,76 × 10⁻⁹ | Unter Planck-Referenz etwa 2,10 × 10⁻⁹ |
| Mscalar/M̄ | c₃^(7/2) | 1,256 × 10⁻⁵ | Dimensionale Ausgabe braucht externe Planckmasse |
| ρΛ/M̄⁴ | 3 exp(−2/α)/(4π²) | 7,125 × 10⁻¹²¹ | Vakuum-Ausleseregel nicht aus vollem Ursprung bewiesen |

**Ein notwendiger CKM-Korrekturschritt.** Manche ältere Vergleiche stellen δ unmittelbar neben einen experimentellen Wert von γ. Korrekt ist, aus allen Modellwinkeln zunächst die CKM-Matrix V aufzubauen und dann

$$\gamma=\arg\left(-\frac{V_{ud}V_{ub}^{*}}{V_{cd}V_{cb}^{*}}\right)$$

zu berechnen. Der begleitende Prüfer tut dies und kontrolliert Unitarität: δ = 68,653616°, γ = 68,615690°, also δ−γ = 0,037926°. Die Differenz ist in diesem Ansatz klein, aber nicht null. Dass zwei Winkel nahe beieinander liegen, rechtfertigt nicht ihre begriffliche Gleichsetzung.

Für Neutrinos verwenden wir zur Orientierung NuFIT 6.0, Datenstand September 2024, mit ausdrücklich gewählter Normalordnungsvariante „IC24 with SK-atm“. Die Referenzwerte sin²θ₁₂ ≈ 0,308 und sin²θ₁₃ ≈ 0,02215 unterscheiden sich von manchen älteren Zahlen im lokalen Vorhersageverzeichnis. Das Paper verwendet daher keine übernommenen, scheinbar universellen Sigma-Zahlen für PMNS. Variantenwahl und Korrelationen müssen in einem vollständigen Fit gemeinsam behandelt werden. [E2]

Die kosmologischen Referenzen sind ausdrücklich Planck 2018 im Basis-ΛCDM-Modell, nicht eine Behauptung über den neuesten gesamten Datenstand: ns = 0,9649 ± 0,0042, Ωb h² = 0,02237 ± 0,00015 und H₀ = 67,4 ± 0,5 km/s/Mpc. Bei vorgegebenem h wird aus der TFPT-Ωb-Ausgabe erst Ωb h²; diese Umrechnung ist keine zusätzliche unabhängige Vorhersage. Ebenso ist ηB ≈ 273,9 × 10⁻¹⁰ Ωb h² eine Umrechnung mit kosmologischen Eingaben und kein eigenständiger Nachweis von Baryogenese. [E3]

Weitere bedingte Richtungen des Korpus sind eine minimale Neutrinosumme um 0,059 eV bei eingesetzten Oszillationssplittings, ein Majorana-Auslesewert mββ im meV-Bereich bei gewählten Phasen, axionartige Skalen aus Mscalar/128 und eine dunkle-Energie-Lesart w=−1. Solche Werte bleiben von absoluten Skalen, QCD-Relationen, Zustandswahl oder Übertragungsannahmen abhängig. Der Proton/Elektron-Massenquotient ist im konsolidierten Stand ausdrücklich keine abgeschlossene TFPT-Vorhersage. [L3]

**Negative Befunde gehören zur Theorie.** Die Quell-Leptonverhältnisse stimmen nicht exakt mit Polmassen überein. Ein älterer Higgs-Kritikalitätszweig mit ungefähr 129–134 GeV trifft den beobachteten Wert nahe 125 GeV nicht. Die einfache As-Normierung bleibt bei N=51,4 zu klein. Die bekannte Lithium-Spannung verschwindet nicht durch Standard-BBN-Ausgaben. Diese Befunde dürfen weder durch nachträgliche Auswahl günstiger Zeilen noch durch unbestimmte „Transferkorrekturen“ neutralisiert werden. Eine zulässige Korrektur braucht eine vorab definierte Formel und unabhängige Prüfung. [L3]

### 7.1 Gravitation, große Hierarchien und die Reichweite des Ansatzes

Der kleine Flavor-Seed organisiert nahe beieinanderliegende dimensionslose Ausgaben. Sehr große Hierarchien werden im historischen TFPT dagegen durch exponentielle Wirkungsansätze organisiert. Schematisch lautet die Auslesung x = R exp(−A), wobei R ein Vorfaktor und A eine dimensionslose Wirkung ist. Die führenden vorgeschlagenen Wirkungsanteile für elektroschwache Skala, Hubble-Skala und Vakuumenergiedichte stehen im Verhältnis 1:5:10: Sie verwenden α⁻¹/5, α⁻¹ und 2α⁻¹. Dieses Verhältnis betrifft die führenden Wirkungsanteile, nicht die vollständigen Logarithmen der beobachteten Größen. Vorfaktoren und sektorspezifische Korrekturen bleiben ausdrücklich sichtbar. [L1]

Hierin liegt eine mögliche Erklärung für scheinbar geheimnisvolle große Zahlen: Wiederholte multiplikative Unterdrückung wird exponentiell groß oder klein, obwohl die zugrunde liegenden Regeln kurz sind. Die beobachteten Hierarchien allein wählen aber nicht eindeutig eine solche Regel aus. Ohne hergeleitete Vorfaktoren und Transferkorrekturen ist der Wirkungsansatz ein strukturiertes Forschungsmodell, kein fertiger Ersatz für eine mikroskopische Rechnung.

Der physikalische Zielausdruck für Gravitation ist in natürlichen Einheiten beispielsweise

$$S_{\rm EH}=\frac{\overline{M}^2}{2}\int d^4x\,\sqrt{-g}\,(R-2\Lambda),\qquad \overline{M}^2=\frac{1}{8\pi G_N}.$$

Diese Gleichung erklärt die Rolle der reduzierten Planckmasse und des Faktors 8π. Sie ist hier eine Zielstruktur beziehungsweise konventionelle Normalisierung, keine aus dem endlichen Compiler bewiesene Wirkung. Eine Übereinstimmung mit c₃⁻¹ = 8π identifiziert einen Koeffizienten, aber nicht das Feld g, seine Quantenfluktuationen oder universelle Kopplung an sämtliche Materie.

Die im Korpus untersuchten Entropie-/Jacobson-Routen benutzen zusätzliche Voraussetzungen über lokale Vakuumzustände, kleine Raumzeitgebiete und Materie-Entropie. Sie dürfen nicht zunächst eine geeignete 4D-Feldtheorie voraussetzen und anschließend als deren unabhängige Herleitung ausgegeben werden. Ebenso ist ein positiver quadratischer Gitter-Hamiltonoperator mit zwei transversalen Moden nicht schon eine nichtlineare, universell gekoppelte Quantengravitation. Das Paper integriert diese Resultate deshalb als bedingte Rekonstruktionswege hinter T3, T5 und T7. [L4]

### 7.2 Weitere historische Vorhersagezweige

Damit die Auswahl der Haupttabelle nicht als vollständige Erfolgsauswahl missverstanden wird, sind weitere wichtige Zweige des lokalen Katalogs aufgeführt. Diese Zeilen wurden in dieser Arbeit nicht unabhängig nachgerechnet; sie geben den dort dokumentierten Vorschlag samt seiner Beweisgrenze wieder.

| Zweig | Im Korpus genannte Ausgabe | Erforderliche zusätzliche Kontrolle |
| --- | --- | --- |
| Starke CP-Phase | θeff = 0 im gewählten Pfaffian-Zweig | Quellmaß und nichtperturbative physikalische Übertragung |
| Elektrische Dipolmomente | Führende Null-/stark unterdrückte Ausgaben | Nicht mit exakt verschwindenden sämtlichen SM-Beiträgen verwechseln |
| Axion | fa ungefähr 2,39 × 10¹¹ GeV, Masse ungefähr 23,8 μeV | Externe Planckskala und QCD-Massenrelation |
| Neutrinomassen | Minimale Summe ungefähr 0,059 eV; mββ etwa 1,5 meV | Oszillationssplittings, leichteste Masse und Majoranaphasen |
| Spektrale CMB-Verzerrung | μ ungefähr 1,5–2,3 × 10⁻⁸ | Kalibriertes Dissipationsfenster und thermische Geschichte |
| Seltene Kaonzerfälle | BR(K⁺) ungefähr 9,45 × 10⁻¹¹; BR(KL) ungefähr 3,33 × 10⁻¹¹ | Schleifenfunktionen, hadronische Inputs und vollständiger Flavor-Transfer |
| Neutronlebensdauer | ungefähr 877,53 s in einer Input-Rechnung | Vud, axiale Kopplung und radiative Korrekturen sind Inputs |
| Hubble-Ausgabe | ungefähr 67,15 km/s/Mpc in einem Budgetzweig | Gemeinsames kosmologisches Budget statt unabhängiger Einzelvorhersage |
| Hochfrequente QPO-Linien | Spezifische Clock-Zielmuster | Archivprüfungen bisher keine bestätigte universelle Linie |
| Proton/Elektron-Verhältnis | Keine abgeschlossene Vorhersage | QCD- und Massenskalen-Brücke bleibt offen |

### 7.3 Korrigierte Reichweite des Inflationstests

Die zugesandte Analyse weist zu Recht darauf hin, dass die zu kleine Amplitude bei genau N=51,4 nicht den gesamten in der Haupttabelle angegebenen Bereich N=50…60 widerlegt. Elimination von N liefert zwei gemeinsame Relationen:

$$r=3(1-n_s)^2,\qquad A_s(1-n_s)^2=\frac{c_3^7}{6\pi^2}.$$

Diese Relationen werden im neuen Prüfer symbolisch bestätigt. Setzt man zur Illustration As=2,10×10⁻⁹ ein, ergibt sich N≈56,13124 und daraus ns≈0,96436922 sowie r≈0,00380866. Das liegt innerhalb des vorgeschlagenen N-Intervalls. Die eingesetzte Amplitude ist dann aber eine Kalibrierung, keine weitere unabhängige Vorhersage. Ein vollständiger empirischer Test muss dieselbe Modellordnung, den Reheating-Vertrag und die korrelierten Daten gemeinsam verwenden. Die ältere negative Aussage über den festgehaltenen N=51,4-Zweig bleibt gültig; eine Widerlegung aller N-Werte wurde nicht gezeigt. [L9, L10]

## 8. Universalraum: Welche Objekte tatsächlich vorliegen

Die Suche nach einem Universalraum hat mehrere verschiedene Objekte isoliert. Sie gehören nicht automatisch zu einem einzigen bereits validierten Zustandsraum. Eine markierte Kommutantenalgebra kann auf M₂(Q(i)) führen, mit verschiedenen integralen Ordnungen. Ihre reelle hermitesche Erweiterung enthält einen besonders einfachen geometrischen Zusammenhang:

$$H=tI+x\sigma_x+y\sigma_y+z\sigma_z,\qquad \det H=t^2-x^2-y^2-z^2.$$

Positivität von H bedeutet t ≥ √(x²+y²+z²). Die Wirkung H ↦ AHA† mit A ∈ SL(2,C) erhält die Determinante und realisiert die bekannte Spinor/Lorentz-Verbindung. Das ist eine echte gemeinsame algebraische Struktur von Positivität und Minkowski-Kegel. Eine vierdimensionale Menge hermitescher Matrizen ist jedoch noch keine Raumzeit mit lokalen Feldern, gekrümmter Metrik oder Einstein-Gleichung. [L5; E6]

Ebenso muss man drei fermionische Größen auseinanderhalten: 16 Majorana-Generatoren entsprechen acht komplexen Moden mit Fockdimension 256; der Vier-Teilchen-Sektor dieser acht Moden hat Dimension 70; eine 96-dimensionale verdoppelte Familienbeschreibung gehört zu einem anderen Aufbau. Eine Isomorphie ausgewählter Algebren identifiziert nicht ohne Weiteres diese Zustandsräume und ihre Observablen.

Die bisherigen inversen Tests sprechen gegen vorschnelle Eindeutigkeit. Mehrere Generatorfamilien können gleiche eingeschränkte Ausgaben besitzen. Zusätzliche Positivität und Symmetrie reduzieren die Auswahl, legen aber nicht in jedem geprüften Fall genau einen Hamiltonoperator oder Grundzustand fest. Einzelne Berichte fanden unzugängliche Richtungen in endlichen Rekonstruktionsproblemen; andere zeigten, dass eine größere Familie von Zweiteilchen-Ausgaben einen ausgewählten Zustand identifizieren kann. Diese Aussagen haben unterschiedliche Eingaben und dürfen nicht als widersprüchliche globale Universalraum-Theoreme gelesen werden. [L5]

Ein anderer früherer Strang untersuchte den Zugang vom ursprünglichen Rand zu inneren Moden. Im festgelegten Majorana-Modell zerfällt der Raum in zehn zugängliche und sechs verborgene reelle Richtungen. Auf Fock-Ebene entspricht das einer 32×8-Zerlegung. Ein verborgener Zustand wird nicht allein dadurch am Rand messbar, dass er mit etwas anderem verschränkt ist; benötigt wird eine geeignete Kopplung oder eine erweiterte erlaubte Messung. Aus vorhandenen Kanten konstruierte Ereigniskanäle können unter zusätzlichen Ausführungsannahmen Besetzung übertragen. Im geprüften Beispiel bleibt aber eine nichttriviale Fixalgebra bestehen: Übertragung ist gelungen, eindeutige Zustandsauswahl nicht. [L5]

Auch die frühe Minimalitätsprüfung ist wichtig: Unter den dort gewählten lokalen Symmetrien bleiben im Viererbaustein sieben Kanalparameter, von denen vier durch lokale Antworten und drei erst durch gemeinsame Antworten bestimmt werden. Zwei identische lokale Beschreibungen können also verschiedene gemeinsame Dynamiken besitzen. Eine spätere, stärkere Symmetrieforderung führt zum in Kapitel 10 beschriebenen kleineren Kanaldreieck. Die unterschiedlichen Parameterzahlen gehören zu unterschiedlichen Voraussetzungen. Eine nochmals engere Vier-Generatoren-Ereignishypothese liefert bei gleichen Raten das binomiale Operatormuster 1–4–6–4–1; die Wahl dieser Ereignisse und Raten ist damit noch nicht physikalisch hergeleitet. [L8]

Der gemeinsame Erkenntnisgewinn ist präziser: **Eindeutigkeit ist relativ zu einer vollständigen Liste erlaubter Zustände, Operationen und Ausgaben.** Ohne diese Liste kann ein besonders einfaches Objekt ein überzeugender Kandidat sein, aber kein eindeutig rekonstruierter Ursprung.

## 9. Der konkrete gemeinsame Prozess auf 60 Quellstrahlen

Die neueste positive Konstruktion benutzt keine nachträglich ausgesuchte beliebige Matrix. Aus dem eingefrorenen E₈-Quellcode werden 60 normierte Rang-1-Projektoren ΠC,s in 15 vollständigen Viererkontexten rekonstruiert. C bezeichnet den Kontext, s sein Ergebnis. Zusätzlich setzen wir die üblichen Born-Wahrscheinlichkeiten und eine scharfe, wiederholbare Messung voraus. Dann ist das Instrument für einen Rang-1-Ausgang eindeutig:

$$\mathcal I_{C,s}(\rho)=\Pi_{C,s}\rho\Pi_{C,s}=\mathrm{Tr}(\Pi_{C,s}\rho)\Pi_{C,s}.$$

Die Begründung ist kurz. Die Effektbedingung zwingt jeden Krausoperator eines Ausgangs auf dessen eindimensionalen Eingangsraum. Wiederholbarkeit zwingt das Bild in denselben eindimensionalen Raum. Der Krausoperator ist daher ein skalares Vielfaches des Projektors; die Effekt-Normierung bestimmt die Summe der Betragsquadrate. Das leitet nicht die Born-Regel her, sondern die Form des Instruments unter dieser Regel.

Nun wird die klassische Kontextwahl K = B/7 angenommen. B ist die exakte symplektische Inzidenzmatrix mit sieben erlaubten nächsten Kontexten einschließlich des aktuellen. Ein gemeinsamer Übergang auf Kontext und Ergebnis lautet:

$$T_{(D,t),(C,s)}=\frac{B_{DC}}{7}\,\mathrm{Tr}(\Pi_{D,t}\Pi_{C,s}).$$

Für jeden Ausgangsstrahl gibt es einen Selbstübergang mit Wahrscheinlichkeit 1/7 und zwölf weitere Übergänge mit jeweils 1/14. Die übrigen 47 Einträge verschwinden. T ist symmetrisch, zusammenhängend und besitzt Selbstschleifen. Deshalb ist die Gleichverteilung auf den 60 Strahlen der eindeutige stationäre Zustand dieser endlichen Kette. Ihr mittlerer Dichteoperator ist I₄/4, nicht ein physikalisch hergeleitetes Vakuum.

Sei C die Summierung der vier Ergebniswahrscheinlichkeiten je Kontext und E die Dekodierung einer Strahlverteilung p zu ΣpC,sΠC,s. Dann gelten die exakten Verträglichkeitsidentitäten:

$$CT=KC,\qquad ET=\mathcal D E,\qquad \mathcal D(\rho)=\frac{3}{7}\rho+\frac{4}{7}\frac{I_4}{4}.$$

Dasselbe T besitzt also einen klassischen und einen quantenmechanischen Schatten. Die Identitäten gelten für alle Iterationen, weil man die Ein-Schritt-Identitäten induktiv multiplizieren kann. Die Zahl 3/7 entsteht hier kombinatorisch: Drei der sieben erlaubten nächsten Kontexte erhalten jeweils eine relevante Pauli-Richtung. Sie wird nicht an ein Zerfallsexperiment angepasst. [L6]

Die Einschränkungen sind genauso konkret. Eine gleichmäßige Wahl über alle 15 Kontexte statt über sieben ergibt den Faktor 1/5. Die Quelle der Regel K ist somit entscheidend. Außerdem spannen die Projektoren zwar den gesamten 16-dimensionalen Operatorraum auf; ihre konvexe Hülle ist aber nur das Stabilizer-Polytop und nicht die gesamte Menge der Quantenzustände. „Spannen“ darf nicht mit „jeden Zustand als positive Mischung darstellen“ verwechselt werden.

### 9.1 Vollständige Spektrallösung auf den tatsächlichen Quellstrahlen

Die Zusendung schlägt eine wesentlich stärkere Aussage als die bisherigen zwei Schattenidentitäten vor. Sie ist an den originalen Quellprojektoren bestätigt. Sei F die 15×60-Matrix der Erwartungswerte aller nichttrivialen hermiteschen Pauli-Operatoren auf den 60 Strahlen. Mit der Kontextauslesung C gilt exakt:

$$CC^{\mathsf T}=4I_{15},\qquad FF^{\mathsf T}=12I_{15},\qquad CF^{\mathsf T}=0.$$

$$T=\frac{C^{\mathsf T}BC+F^{\mathsf T}F}{28}.$$

Definiere die orthogonalen Projektoren PC=CᵀC/4, PF=FᵀF/12 und P∅=I−PC−PF. Ihre Ränge sind 15, 15 und 30. Die erste Komponente entwickelt sich nach K, die zweite wird mit 3/7 multipliziert, die dritte verschwindet nach einem Schritt. Damit folgt für jede reelle Anfangsverteilung und insbesondere jede Wahrscheinlichkeitsverteilung:

$$T^n=\frac{1}{4}C^{\mathsf T}K^nC+\left(\frac{3}{7}\right)^nP_F,\qquad n\geq1.$$

| Eigenwert von T | Vielfachheit | Art der Richtung |
| --- | --- | --- |
| 1 | 1 | Stationäre Gleichverteilung |
| 3/7 | 15 | Nichttriviale quantenmechanische Ausgaben |
| 2/7 | 9 | Kontextkontraste |
| −2/7 | 5 | Alternierende Kontextkontraste |
| 0 | 30 | Gleichzeitig für C und F unsichtbare Richtungen |

Die Ein-Schritt-Faktorisierung und Orthogonalität beweisen die Potenzformel durch Induktion. Zusätzlich werden ein ganzzahliges annihilierendes Polynom von 14T und exakte Spurmomente geprüft; daraus folgen die Vielfachheiten ohne numerischen Eigenwertfit. Die Symmetrie von T schließt nichttriviale Jordanblöcke aus. Weil K invertierbar ist und 3/7 nicht verschwindet, gilt ker T = ker(C,F).

Die 30 Nullrichtungen sind folglich kein in T weiterlebendes verstecktes Gedächtnis. Innerhalb dieser reduzierten Kette sind sie nach einem Schritt fort. Erhaltene Information aus dem Registerexperiment liegt in der größeren kohärenten Ausführung und muss dort nachgewiesen werden. Damit ist die endliche Kette vollständig gelöst, nicht die Herkunft ihrer physikalischen Ausführung. [L9, L10]

## 10. Warum dieselben Schatten den Ursprung nicht eindeutig festlegen

Die Kontextmatrix erfüllt

$$B^2=4I+3J,\qquad \mathrm{spec}(K)=\{1,(2/7)^{[9]},(-2/7)^{[5]}\}.$$

Weil ihre Determinante negativ ist, kann K nicht exp(L) für eine reelle Matrix L sein: Jede reelle Matrixexponential-Determinante ist exp(Tr L)>0. Das ist eine exakte Schranke auf demselben endlichen klassischen Raum, kein Verbot einer größeren reversiblen Realisierung. Mit Π als Gleichverteilungsprojektor gilt dagegen

$$K^2=\frac{4}{49}I+\frac{45}{49}\Pi=\exp\left[\log(49/4)(\Pi-I)\right].$$

Ein Zweischritt-Schatten kann folglich eine einfache kontinuierliche Einbettung besitzen, obwohl der Einzelschritt sie nicht besitzt. Eine positive Quadratwurzel kann die fünf alternierenden Kontraste verlieren. Das zeigt bildlich: Wer immer nur jedes zweite Bild eines Films sieht, kann eine wichtige Wechselbewegung übersehen.

Ein separater Test auf einem hinzugefügten 15-dimensionalen kohärenten Labelregister konstruiert zwei quantenmechanische Lifts derselben klassischen Kette. Einer misst und präpariert; der andere mischt geeignete Permutationen. Ihre klassischen Geschichten stimmen überein, aber eine Interferenzmessung am gleichförmigen reinen Eingang ergibt 1/15 beziehungsweise 1. Diese beiden Lifts sind keine zwei vollständigen Realisierungen aller TFPT-Quellbedingungen. Sie widerlegen die engere Behauptung, allein der klassische Ausschnitt lege bereits den kohärenten Ursprung fest. [L6]

Auch volle endliche Symmetrie kann eine Familie von Kanälen statt eines einzelnen Kanals zulassen. Im geprüften Viererträger verbleibt unter den genannten Pauli- und Stabilisator-Kovarianzannahmen ein konvexes Dreieck aus Identität und zwei Orbitmitteln. Ein gemeinsamer stationärer Spurzustand beweist keine eindeutige Dynamik. Diese Resultate motivieren die Suche nach einer zusätzlichen quellenseitigen Kompositionsregel, nicht nach einer möglichst großen Sammlung gleicher Fixpunkte.

### 10.1 Die vollständige symmetrische Familie der Kontextregeln

Hier geht es um ein anderes Dreieck als das zuletzt genannte: um klassische Regeln auf 15 Kontexten. Unter voller symplektischer Kontextsymmetrie gibt es drei Paarorbits. Zwei Kontexte sind identisch, besitzen genau einen gemeinsamen nichttrivialen Pauli oder sind disjunkt. Pro Ausgangskontext sind das 1, 6 und 8 Möglichkeiten. Mit Gesamtwahrscheinlichkeiten a,b,c≥0 und a+b+c=1 lautet die Regel

$$K_{abc}=aI+\frac{b}{6}(B-I)+\frac{c}{8}(J-B).$$

Die entsprechende Strahlkette zerfällt auf denselben orthogonalen Sektoren:

$$T_{abc}=\frac{1}{4}C^{\mathsf T}K_{abc}C+\left(a+\frac{b}{3}\right)P_F+\left(a-\frac{b}{6}\right)P_{\emptyset}.$$

Auf dem Quantenteil liegt also der Faktor a+b/3, auf dem 30-dimensionalen unsichtbaren Teil a−b/6. Die beiden nichttrivialen Kontextbänder besitzen a+b/6−c/4 mit Vielfachheit 9 und a−b/2+c/4 mit Vielfachheit 5. Diese vollständige Familie wird über die drei Extrempunkte exakt kontrolliert; der allgemeine Fall folgt durch Linearität. Die Orbitklassifikation folgt aus den möglichen Schnittdimensionen maximal isotroper Ebenen und der Erweiterbarkeit angepasster symplektischer Basen.

Der ursprüngliche Schritt liegt bei (a,b,c)=(1/7,6/7,0). Volle Symmetrie allein wählt ihn nicht aus. Die zusätzlichen Forderungen c=0 und a−b/6=0 tun dies eindeutig. Auch maximale Shannon-Entropie der sieben einzelnen zulässigen Folgemöglichkeiten liefert denselben Punkt. Entscheidend ist hier die Entropie der einzelnen Übergänge, nicht bloß die Entropie der drei Orbitmassen. Beide Auswahlprinzipien sind Kandidaten; ihre physikalische Gültigkeit ist nicht bewiesen. [L9, L10]

### 10.2 Drei Präparationsprotokolle, drei Verläufe

Der Zustand des Systems allein enthält nicht notwendigerweise die Information, mit welchem Kontext es gemeinsam präpariert wurde. Die allgemeinere klassisch-quantenmechanische Beschreibung besteht aus 15 positiven unnormierten Blöcken σC mit ΣTr σC=1. Ihre reelle hermitesche lineare Hülle besitzt 240 Koordinaten vor der Normierung. Das sind keine 240 Teilchen und keine Hilbertraumdimension. Eine konkrete erweiterte Ausführung lautet

$$\sigma_D'=\sum_C K_{DC}\Delta_D(\sigma_C).$$

Nach dem ersten Schritt ist jeder Block im neuen Kontext diagonal und lässt sich durch dessen vier Strahlen beschreiben. In Pauli-Koordinaten wirkt auf die Identitätskomponente K, auf jede andere Pauli-Komponente DvK. Dabei projiziert Dv auf die drei Kontexte, die diesen Pauli enthalten. Direkt an der Quellinzidenz wird bewiesen:

$$\operatorname{rank}(I,M,M^2,M^3)=(240,60,30,30),\qquad (D_vK)^3=\frac{3}{7}(D_vK)^2.$$

Die Rangnotation meint die Liste der vier Einzelränge. Neu daraus folgt für den Nullanteil der größeren Abbildung M: 30 Jordanblöcke der Größe 2 und 150 der Größe 1. Er enthält zweischrittige transiente Richtungen, während der symmetrische 60-Strahlen-Schritt keine solchen Jordanblöcke besitzt. Ein Nullraum muss deshalb immer zusammen mit seiner konkreten Zustandsbeschreibung benannt werden.

Für einen anfänglichen Systemzustand ρ sind drei Experimente zu unterscheiden. Angegeben ist jeweils der Faktor vor dem tracelosen Anteil ρ−I₄/4:

| Präparations- und Fortsetzungsregel | Faktor nach n Schritten | Faktor nach zwei Schritten |
| --- | --- | --- |
| Bereits passende Kontext/Strahl-Verteilung; K wird fortgesetzt | (3/7)ⁿ | 9/49 |
| Anfangs σC=ρ/15; danach Kontext erhalten und K fortgesetzt | (1/5)(3/7)ⁿ⁻¹, n≥1 | 3/35 |
| Vor jedem Schritt Kontext neu unabhängig gleichverteilt | (1/5)ⁿ | 1/25 |

Die erste Zeile betrifft Zustände in der Strahlmischungsbeschreibung. Die letzten beiden erlauben einen beliebigen anfänglichen Quantenzustand. Im zweiten Experiment entsteht die 1/5-Abschwächung nur beim ersten Schritt; anschließend bleibt die erzeugte Kontext/System-Beziehung erhalten. Die dritte Zeile setzt diese Beziehung vor jedem Schritt aktiv zurück. Ein kontinuierlich wiederholter 1/5-Kanal folgt daher nicht allein aus einmaliger unabhängiger Präparation. Diese Mehrschritt-Präzisierung geht über den zugesandten Ein-Schritt-Vergleich hinaus. [L10]

### 10.3 Warum keine positive affine Rückübersetzung genügt

Der Einwand des Zusenders lässt sich streng begründen. Jeder reine Strahl ist ein Extrempunkt des Stabilizer-Polytops. Eine positive affine Rechtsinverse der Dekodierung E müsste ihn auf sein eindeutiges Delta-Maß im Strahlsimplex abbilden. Nun besitzt I₄/4 für jeden der 15 Kontexte eine Vierer-Gleichverteilung als Darstellung. Affinität würde verlangen, dass derselbe Zustand gleichzeitig auf alle diese verschiedenen Kontextverteilungen zurückgeführt wird. Das ist unmöglich.

Die bloße Existenz mehrerer Darstellungen von I₄/4 wäre allein noch kein Beweis gegen jede Auswahlfunktion. Der zusätzliche Extrempunkt- und Affinitätsschritt schließt genau die positive affine Rechtsinverse aus. Nichtaffine Auswahlkonventionen könnten einen Repräsentanten wählen, würden aber weder die ursprüngliche Präparation rekonstruieren noch einen universellen linearen Prozessübergang begründen.

## 11. Der einfache Messbaustein: Spiegeln, koppeln, aufzeichnen

Für jeden vollständigen Viererkontext sind die Spiegelungen RC,j = I−2ΠC,j bereits im Quellbaukasten vorhanden. Ihr gleichmäßiges Kanalmittel ist exakt die nichtselektive Kontextmessung:

$$\frac{1}{4}\sum_j R_{C,j}\rho R_{C,j}^{\dagger}=\sum_j\Pi_{C,j}\rho\Pi_{C,j}=\Delta_C(\rho).$$

Die Auslöschung des unveränderten ρ-Terms ist speziell für Dimension vier. In allgemeiner Dimension d erhält man (1−4/d)ρ+(4/d)Δ(ρ). Dass die Viererstruktur diese kurze Identität besitzt, ist ein konkreter Vorteil des vorliegenden Bausteins; es beweist nicht, dass jede physikalische Raumdimension vier sein müsse.

Um Ergebnisse wirklich aufzuzeichnen, braucht man einen gemeinsamen System-Register-Prozess. Die relevante Kopplung ist

$$Q_C=\sum_j |j\rangle\langle j|\otimes R_{C,j}=I-2\sum_j |j\rangle\langle j|\otimes\Pi_{C,j}.$$

Sie gibt den zusammenpassenden Register/System-Kombinationen ein Minuszeichen. Im rechnerischen Kontext hat Q Operator-Schmidt-Rang vier. Ausschließlich getrennte Operationen auf beiden Registern besitzen Rang eins und bleiben bei Komposition getrennt. Deshalb entsteht Q nicht aus bloßem wiederholtem Umbenennen registerlokaler Spiegelungen.

Die positive Nachricht ist seine kurze Zerlegung: Zwei registerübergreifende Controlled-Z-Gates plus lokale Z- und Controlled-Z-Phasen genügen. Der Gate-Typ Controlled-Z ist selbst schon eine Koordinaten-Wurzelspiegelung des Viererträgers. Zusätzlich vorausgesetzt wird seine Anwendung zwischen Qubits verschiedener Träger. Die Herkunftslücke betrifft also die erlaubte Verbindung der Bausteine, nicht eine notwendigerweise komplizierte neue Einzelmatrix.

Der ergänzende Herkunftsabgleich für dieses Manuskript bestätigt die engere Reichweite der eingefrorenen Datei v783: Ihre expliziten Tensorprodukte, Pauli-Wörter, Hadamard- und CNOT-Operationen beschreiben zwei Qubits innerhalb des komplexen Viererträgers. Diese Stellen sind kein Nachweis einer ausgewählten Kopplungsregel für beliebig viele verschiedene Viererträger. Das ist eine Aussage über die geprüfte Quelle, kein behaupteter Abwesenheitsbeweis für das gesamte Repository.

Mit dem Registerbasiswechsel W=J₄/2−I, der Präparation A=(I−2|0⟩⟨0|)W und einem leeren Register entsteht die unitäre Vor-Messung

$$U_C=(W\otimes I)Q_C(A\otimes I),\qquad U_C(|0\rangle\otimes\psi)=\sum_j|j\rangle\otimes\Pi_{C,j}\psi.$$

Die Einzelmatrizen und die Kontexte sind quellenseitig rekonstruiert. Die physikalische Verfügbarkeit der Kreuzkopplung, des präparierten Registers und seiner Auslesung ist noch eine Zusatzannahme. In der geprüften Konstruktion gilt sogar U² = I für jeden dieser Kontexte. Das ist eine exakte Eigenschaft dieses Ausbaus, keine allgemeine Behauptung über alle Messgeräte. [L7]

## 12. Aufzeichnungen erklären den Unterschied zwischen Umkehrbarkeit und Mischung

Starte mit einem leeren Register und dem gleichförmigen reinen Systemzustand. Eine Anwendung von U erzeugt einen maximal verschränkten Zustand. Wer das Register nicht mitliest, sieht im System den gemischten Zustand I₄/4. Die globale Information ist trotzdem nicht verschwunden.

| Experiment im endlichen Modell | Sichtbarer Systemzustand | Reinheit Tr ρ² |
| --- | --- | --- |
| Ein Schritt, Register nicht betrachtet | I₄/4 | 1/4 |
| Zweiter Schritt mit demselben noch kohärenten Register | Ursprünglicher reiner Zustand | 1 |
| Zwei Schritte mit je einem frischen Register | I₄/4 | 1/4 |

Der Unterschied ist keine Interpretationsfrage, sondern wird durch die exakten Matrizen berechnet. Beim Wiederverwenden des kohärenten Registers macht U²=I die erste Operation rückgängig. Bei frischen Registern bleiben zwei Aufzeichnungen bestehen; die reduzierte Beschreibung iteriert den dephasierenden Kanal. Zurücksetzen oder Weggeben von Registern darf daher nicht als kostenloser, automatisch vorhandener Ursprung eines Zeitpfeils vorausgesetzt werden.

Für beliebig viele vorgegebene Kontexte und frische Register lautet der kohärente Verlauf:

$$\sum_{j_1,\ldots,j_n}|j_1,\ldots,j_n\rangle\otimes\Pi_{C_n,j_n}\cdots\Pi_{C_1,j_1}\psi.$$

Das Weglassen des Registers summiert Dichteoperator-Beiträge verschiedener Geschichten. Eine kohärente Projektion des Registers auf eine Superposition summiert dagegen Amplituden und ist ein anderes, gegebenenfalls nachselektiertes Experiment. Die beiden Vorgänge gleichzusetzen würde Interferenz und Wahrscheinlichkeit vermischen.

Eine weitere Warnung: Die nichtselektiven Dephasierungskanäle der geprüften Pauli-Kontexte kommutieren, während ausgewählte Ergebnisgeschichten reihenfolgeabhängig sind. Für zwei passende Rang-1-Projektoren mit Tr(PQ)=1/2 und Eingang P erhält man für „P, dann Q“ die Wahrscheinlichkeit 1/2, für „Q, dann P“ dagegen 1/4. Ein Test nur der gemittelten Kanäle übersieht diesen Unterschied. Der neue Prüfer enthält deshalb einen absichtlich vertauschten selektiven Ablauf als Negativkontrolle.

Damit entsteht eine klare informationsbezogene Deutung: Der sichtbare Zustand ist eine Auslesung eines größeren Prozesses einschließlich seiner Aufzeichnungen. Irreversibilität in dieser Auslesung kann mit globaler Umkehrbarkeit vereinbar sein. Daraus folgt weder die Auswahl eines kosmischen Anfangszustands noch ein thermodynamischer Zeitpfeil ohne weitere Umwelt- und Zustandsannahmen.

### 12.1 Vier gekoppelte Viererträger: ein ausdrücklich zusätzliches Modell

Der zugesandte Ansatz erweitert den Raum auf vier Kopien des Quellträgers und setzt eine positive Austauschwechselwirkung an:

$$\mathcal H=(\mathbb C^4)^{\otimes4},\qquad H_{\rm tet}=J\sum_{i<j}\frac{I+S_{ij}}{2},\qquad J>0.$$

Sij vertauscht die Träger i und j. J, sein Vorzeichen, die vollständige Kopplung der vier Träger und die physische Realisierung dieser Hamiltonwirkung sind zusätzliche Annahmen. SU(4)-Singulett- und Tetramermodelle besitzen einen etablierten wissenschaftlichen Hintergrund; hier wird ihre konkrete Anschlussfähigkeit geprüft, nicht ein neuer Typ von Singulett beansprucht. [L9, L10, E7]

Jeder Summand ist ein positiver Projektor. Nullenergie verlangt Antisymmetrie unter allen Transpositionen. Der gemeinsame Nullraum ist die eindimensionale vierte äußere Potenz von C⁴. Daher ist der Grundzustand bis auf eine globale Phase eindeutig:

$$|\Omega\rangle=\frac{1}{\sqrt{24}}\sum_{\pi\in S_4}\operatorname{sgn}(\pi)|\pi(0),\pi(1),\pi(2),\pi(3)\rangle.$$

Die unabhängige ganzzahlige Rechnung bestätigt das gesamte Spektrum:

| Energie in Einheiten J | Vielfachheit im 256-dimensionalen Raum | Vielfachheit im Vier-Teilchen-Sektor |
| --- | --- | --- |
| 0 | 1 | 1 |
| 2 | 45 | 15 |
| 3 | 40 | 12 |
| 4 | 135 | 33 |
| 6 | 35 | 9 |

Der Gap beträgt 2J. Die Spektralprojektoren lassen sich als Lagrange-Polynome von H/J schreiben, und die unitäre Dynamik ist deren Summe mit Phasen exp(−iJEt/ℏ). Sie ist im gesetzten Modell vollständig bestimmt. Die Zeitskala J/ℏ wurde dadurch aber nicht aus TFPT abgeleitet.

### 12.2 Lokale Mischung, globale Reinheit und ein messbares Zertifikat

Für jeden einzelnen Träger gilt ρi=I₄/4; für jedes Paar gilt ρij=(I−Sij)/12. Der reine globale Zustand und die maximal gemischten lokalen Schatten widersprechen sich somit nicht. Alle sechs Paarmarginalen werden exakt aus der signierten Zustandsamplitude berechnet.

Bereits die gemeinsamen Energietests können den Zustand zertifizieren. Mit pᵢⱼ=Tr[ρ(I+Sij)/2] folgt aus dem Gap:

$$1-\langle\Omega|\rho|\Omega\rangle\leq\frac{\operatorname{Tr}(\rho H_{\rm tet})}{2J}=\frac{1}{2}\sum_{i<j}p_{ij}.$$

Null bei allen sechs Tests erzwingt genau den Grundzustand; kleine Gesamtenergie begrenzt den Fehler. Dieses robuste Zertifikat ist ein sinnvoller experimenteller beziehungsweise numerischer Folgeauftrag. Es legt fest, was gemessen werden müsste, ohne eine erfolgreiche Präparation vorzutäuschen.

**Grundzustands-Eindeutigkeit ist keine Attraktor-Eindeutigkeit.** Jede Dichtematrix, die mit H kommutiert, bleibt unter seiner unitären Entwicklung stationär. Die stationäre komplexe Operatoralgebra hat hier Dimension 1²+45²+40²+135²+35²=23.076. Das Modell hat also einen eindeutigen Zustand minimaler Energie, aber nicht nur einen stationären Zustand und kein unitäres Abkühlen aus beliebigem Eingang. Ein Präparations- oder Relaxationsmechanismus bleibt eine eigene Aufgabe.

### 12.3 Explizite Verbindung zum Compiler und zum 70-dimensionalen Sektor

An den tatsächlichen 16 Pauli-Matrizen des Quellträgers lässt sich die Austauschoperation schreiben als

$$S_{ij}=\frac{1}{4}\sum_{v=0}^{15}P_v^{(i)}\otimes P_v^{(j)}.$$

Damit ist der Austausch-Hamiltonoperator eine kurze bilineare Kombination bereits vorhandener Einzeloperatoren. Das ist stärker als eine Dimensionsähnlichkeit. Es ist aber nicht gleichbedeutend mit der Herkunft einer gemeinsamen Hamiltonkopplung: Eine zufällige Mischung derselben Operationen ist ein anderer dynamischer Gegenstand. Kopplungsstärke und physische Ausführung bleiben offen.

Unter der festgelegten Kodierung 0↔00, 1↔01, 2↔10, 3↔11 entsprechen die vier Träger acht Qubits. Eine ausdrücklich geordnete Jordan-Wigner-Konstruktion liefert acht Fermionenmoden und 16 Majorana-Generatoren. Jeder der 24 Summanden von Ω enthält die vier Muster genau einmal und hat deshalb Besetzung 0+1+1+2=4. Ω liegt tatsächlich im 70-dimensionalen Vier-Teilchen-Sektor, nicht nur in einem ebenfalls 256-dimensionalen Raum.

Neu geprüft ist außerdem: H erhält diese Gesamtteilchenzahl. Sein eingeschränktes Spektrum steht in der dritten Spalte der obigen Tabelle. Die Fermionen-Antikommutatorrelationen werden exakt kontrolliert; die Einteilchendichte ist I₈/2 und kein Projektor. Der reine Zustand ist somit kein einzelner Slaterdeterminant. Seine genau 24 besetzten Qubit-Amplituden schließen einen reinen Stabilizerzustand in dieser Kodierung aus, denn dessen Unterstützung hat Zweierpotenz-Größe.

Die Einschränkung ist doppelt: Dieser H₇₀ ist ein neu konstruierter Operator und noch nicht der in früheren TFPT-Experimenten gleich benannte Quelloperator. Dafür braucht es einen markierungstreuen Operatortransport. Außerdem ist ein gewöhnlicher Qubit-Blocktausch nicht ohne Beachtung fermionischer Vorzeichen mit dem Tausch von Fermionenmoden identisch. Die explizite Kodierung ersetzt diese Prüfung nicht.

### 12.4 Warum der kollektive Clock-Lift noch keine beobachtbare Zeit erzeugt

Für jede Vierermatrix A gilt auf dem antisymmetrischen Zustand A⊗⁴Ω=det(A)Ω. Jede kollektiv auf die vier Träger angewandte unitäre Operation verändert Ω daher nur um eine globale Phase. Das gilt auch für einen solchen kollektiven Compiler-Clock-Lift; der Grundzustands-Dichteoperator bleibt unverändert.

Ein Taktsignal müsste deshalb aus relativen Operationen, Anregungen, einer Messkopplung oder einem anderen ausdrücklich definierten Protokoll kommen. Die Einfügung des Singuletts schließt die Clock-Herkunftsfrage nicht automatisch. Ebenso ist die Verfügbarkeit eines diskreten SWAP-Gatters nicht die Verfügbarkeit jedes kontinuierlichen Partial-SWAP-Hamiltonflusses oder einer Präparation des nicht-Stabilizer-Grundzustands.

### 12.5 Zwei gekoppelte Zellen: der stärkere Satz

Für zwei vollständige Vierträgerzellen mit einer einzelnen Brücke H = H_A + H_B + λ P⁺_ab gilt bei J > 0 und jeder endlichen Kopplung λ ≥ 0 ein eindeutiger Grundzustand. Die Lücke über diesem Zustand ist strikt größer als J/2 und nähert sich bei wachsender Kopplung J/2. Der in Version 1.1 dargestellte Bereich λ < 16J/5 war nur eine konservative Beweisgrenze, keine physikalische Instabilität. Der unabhängig geprüfte Sektorbeweis und die exakten Energien stehen in Nachtrag N2.2.

Dieser Satz betrifft genau zwei vollständige Tetramer mit einer Brücke. Er beweist weder die Skalierbarkeit eines beliebigen Zellnetzes noch eine masselose Raumzeitphase. Insbesondere darf das Resultat nicht auf den dreiecksfreien Clebsch-Graphen übertragen werden.

## 13. Was zusammenpasst — und was nicht gleichgesetzt werden darf

Die tragfähigste Zusammenführung ist derzeit eine Kette mit markierten Voraussetzungen: Der TFPT-Träger liefert endliche Darstellungen und Projektoren. Eine explizite Quanten-Ausführungsregel macht daraus Instrumente. Eine Kopplung an Aufzeichnungen macht Instrumente zu gemeinsamen Prozessen. Unterschiedliche Auslesungen dieses Prozesses liefern verschiedene Schatten. Das ist eine konkrete Realisierung des Grundgedankens, nicht bloß eine Metapher.

Die Verbindung zur Physik bleibt gestuft. Noethers Zusammenhang benötigt eine Wirkung und deren Symmetrie; eine endliche Symmetriegruppe allein liefert keinen physikalischen Energie-Impuls-Tensor. Eine Dirac-Algebra benötigt für eine Feldgleichung zusätzlich Raumzeit, Ableitungen und einen dynamischen Operator. Der Lorentz-Kegel liefert kinematische Struktur, aber nicht Einsteins nichtlineare Gravitation. Ein Rand-Ausleseverfahren kann holografisch motiviert sein, ohne bereits eine rekonstruktive Bulk/Rand-Dualität mit kontrollierten Entropien und Lokalität zu beweisen.

Die mathematische Verwandtschaft von Ikosaeder, binärer Ikosaedergruppe und affinem E₈ über McKay ist ein weiterer Strukturhinweis. Eine gewöhnliche A₅-Darstellung bleibt beim Hochziehen nach 2I zentral trivial. Der zweidimensionale Spinorsektor, in dem das zentrale Element als −I wirkt, entsteht dadurch nicht automatisch. Deshalb kann eine andere Theorie mit Ikosaeder-Geometrie nicht allein über die gleiche Symmetrie den fehlenden spinoriellen Quellsektor liefern. Dieses Manuskript führt keine neue OPH- oder McKay-Prüfung aus; es übernimmt nur die entsprechend begrenzte Vergleichsfrage des Korpus.

Auch Primzahlen und Nullstellen dürfen hier nicht zu Beweisen umgedeutet werden. Die bloße Darstellung diskreter Spektren, multiplikativer Zerlegungen oder logarithmischer Raten identifiziert noch keinen Operator mit dem benötigten arithmetischen Spektrum. Dieses Manuskript entwickelt keinen neuen RH-Mechanismus und behauptet keine Lösung von RH, Faktorisierung oder P versus NP. Die endlichen Clifford-Prozesse sind bei Stabilizer-Präparationen und den hier erlaubten Messungen klassisch effizient simulierbar; eine neue universelle Rechenfähigkeit folgt daraus gerade nicht. [E4]

Für Hylæan ergibt sich eine methodische, keine kosmologische Übertragung: Gleichheit einer momentanen Antwort genügt nicht zur Gleichheit zweier Gedächtnisprozesse. Man muss die Aufzeichnungen, nachfolgende Auslesungen und Eingriffsreihenfolgen kontrollieren. Das vorliegende Paper enthält keinen neuen Lauf und keine Änderung des Hylæan-Systems.

Der vom Zusender vorgeschlagene Prozesstensor ist dafür ein etablierter Rahmen: Er beschreibt die Antworten auf zeitlich geordnete Eingriffe einschließlich zeitlicher Korrelationen. Operational sollten zwei Realisierungen dann gleichgesetzt werden, wenn keine erlaubte zukünftige Eingriffsfolge sie unterscheidet, nicht erst wenn jede unzugängliche Umweltmatrix buchstäblich gleich ist. Welche Eingriffe erlaubt sind, gehört zwingend zur Definition. Die vorliegenden Register-Gegenproben passen zu dieser Fragestellung; eine vollständige TFPT-Prozesstensor-Rekonstruktion wird hier nicht behauptet. [E8]

## 14. T1–T8: Der tatsächliche Abschlussvertrag

Die folgende Karte ist der konsolidierte physikalische Vertrag, nicht ein Prozentbalken. Ein erledigter endlicher Teiltest schließt seine übergeordnete Existenz- oder Herkunftsforderung nicht. [L4]

| Tor | Noch zu zeigende Aussage | Beitrag dieser Synthese |
| --- | --- | --- |
| T1 | Quelle von P1/P2, Dimensionen und Compiler-Auswahl | Zusätzliche Ausführungs- und Kompositionsannahmen explizit |
| T2 | Tatsächliche half-charge-markierte E₈-Nahtalgebra samt Skalierungslimes | Endliche Kontexte vorhanden; renormiertes Feld mit Energie- und Adjungiertenkontrolle fehlt |
| T3 | Ein ausgewählter lokaler/quasilokaler unitärer 3+1D-Ursprung | Kreuzkopplung als konkrete, aber nicht ausgewählte Mikrooperation |
| T4 | Chirales Standardmodellmaß, Anomalien/Index und Spiegelentkopplung | Exakte Ladungstabelle, noch kein kontrolliertes Feldmaß |
| T5 | Wechselwirkender Kontinuumsgrenzwert und physikalische Streu-/Clusterstruktur | Keine Schließung durch endliche Kanäle oder einen endlichen Spektralgap |
| T6 | Alle drei Eichkopplungen und vollständige Neutrinotextur/-skala intern | α-Formel und Flavor-Ausgaben, Quellen- und Transferlücken bleiben |
| T7 | Masseloser quantisierter Spin 2, zwei Helizitäten, universelle Kopplung | Lorentz- und Normierungsidentitäten ersetzen den gemeinsamen Ursprung nicht |
| T8 | Physikalischer Anfangszustand und ein Quellfunktional für alle Ausgaben | Registerabhängigkeit präzisiert; eindeutiger Grundzustand eines Zusatzmodells, noch keine physische Präparation |

Besonders scharf ist T2: Ein endlicher half-charge-Transport oder eine Gitteridentität ist nicht das renormierte, verschmierte intersektorielle Feld. Gebraucht werden definierte Domänen, Energieabschätzungen, beide Adjungierten und verträglicher Ladungs-/Cocycle-Transport. Erst danach folgt die noch gesonderte Zuordnung zu E₈-Kanälen und Clocks. Für T3–T8 muss derselbe Ursprung alle Sektoren tragen; mehrere Rekonstruktionen, die einander fehlende Voraussetzungen leihen, schließen den Kreis nicht.

„Alle T1–T8 offen“ heißt nicht, dass nichts vorhanden ist. Es heißt, dass der vollständige physikalische Satz wesentlich stärker ist als die bereits erreichten exakten endlichen Sätze. Eine belastbare Gesamtbewertung benennt beides gleichzeitig.

## 15. Die nächsten Arbeiten: einfacher und entscheidbarer

**Erstens: die Herkunft der Verbindung prüfen.** In der tatsächlichen Quellbeschreibung ist zu suchen, ob es ein Tensorprodukt-/Lokalitätsprinzip gibt, das Controlled-Z zwischen unterschiedlichen Trägern erlaubt und auswählt. Ein positiver Nachweis muss eine explizite Abbildung von Quellobjekten auf die gekoppelten Register mitsamt den Operatoren liefern. Das Vorhandensein derselben Einzelmatrix in einem isolierten Viererträger reicht nicht. Ein negativer Ausgang benennt genau die zusätzlich benötigte Kompositionsannahme.

**Zweitens: Registerversorgung und Kontextwahl gemeinsam ableiten.** Nicht nur Q, sondern auch der Zustand des Registers, seine Wiederverwendung beziehungsweise Frische und die Wahl der nächsten Kontexte müssen aus derselben Quelle folgen. Als entscheidender Test dienen zwei Realisierungen mit gleichen Ein-Schritt-Schatten: Sie müssen durch erlaubte Mehrschritt-Experimente entweder unterschieden werden oder hinsichtlich der gesamten zugelassenen Ausgaben äquivalent sein. Der bloße stationäre Zustand ist kein hinreichendes Auswahlkriterium.

**Drittens: eine einzige physikalische Brücke wählen.** Statt alle Phänomene parallel durch flexible Auslesungen anzupassen, sollte zunächst eine vollständig definierte Messgröße aus einem ausgewählten Ursprung abgeleitet werden. Für Flavor bedeutet das einen festgelegten Renormierungspfad und eine noch nicht zum Einstellen benutzte Messgröße. Für Dynamik bedeutet es eine abgeleitete Zeit-/Energieskala. Für T2 bedeutet es das konkrete half-charge-Feld mit den genannten Abschätzungen. Erfolg ist die geschlossene Brücke, nicht eine neue ähnliche Zahl.

**Viertens: die empirische Rechnung einfrieren.** Jede Hauptvorhersage erhält vorab Inputs, Formel, Schema, Unsicherheit, verwendeten Datensatz und Stop-Kriterium. Schlechte Zeilen bleiben sichtbar. Ein nachträglich eingeführter Parameter wird als neuer Parameter gezählt. Ein externer Skalenanker darf nicht anschließend als unabhängig vorhergesagte Größe ausgegeben werden.

Die minimale Arbeitsfrage lautet damit: **Kann die Quelle nicht nur den Baustein, sondern auch seine zulässige Verbindung und die Art seiner Aufzeichnung bestimmen?** Diese Frage respektiert die gewünschte Einfachheit. Sie ist zugleich präziser als die Forderung, eine einzelne Matrix müsse ohne weitere Angaben alle offenen Probleme lösen.

Die Revision ergänzt dafür drei engere Akzeptanztests. Erstens muss eine behauptete Kontext-Ausführung die drei Mehrschrittverläufe aus Kapitel 10 unterscheiden und die tatsächlich realisierte Präparation benennen. Zweitens kann ein Vierträger-Präparationsverfahren mit den sechs positiven Paar-Energietests aus Kapitel 12 statt nur mit lokalen I₄/4-Schatten geprüft werden. Drittens muss eine skalierte Zellenkonstruktion einen gemeinsamen, markierungstreuen Quelloperator und einen mit der Systemgröße kontrollierten Gap liefern; der hier bewiesene Zweizellenbereich dient als Ausgangspunkt, nicht als fertiger thermodynamischer Satz.

## Schluss

TFPT besitzt eine reichhaltige, vielfach exakt überprüfbare innere Organisation: fünfteiliger Träger, Spinorstruktur, E₈-Verklebung, Clocks, wiederverwendete Flavor-Daten und konkrete Formelwerte. Die Universalraum-Arbeit ergänzt diese Organisation am stärksten dort, wo sie Operationen und Ausgaben explizit miteinander verbindet. Der Prozess auf 60 Quellstrahlen und sein reversibler Ausbau mit Aufzeichnungen sind ein solches Bindeglied.

Das bisher fehlende Stück erscheint dadurch weniger als eine riesige unbekannte Formel und mehr als eine Auswahlregel für das Zusammensetzen und Ausführen vorhandener einfacher Bausteine. Das ist eine begründete Forschungsdiagnose, keine bereits bewiesene universelle Lösung. Das neue Paper hält deshalb den positiven Kern, die widersprechenden Befunde und die erste noch fehlende Herkunftsaussage in derselben Darstellung fest.

## Anhang A. Quellen und Herkunft

Die Basisdarstellung bezieht sich auf den Arbeitsstand vom 13. September 2026 im Repository tfpt-theoryv4; die gekennzeichnete Erweiterung wurde am 14. September 2026 geprüft. Basis-Commit: 66b91e40e245569f06ab440ead80f446c9be0ee5. Der Checkout enthält darüber hinaus nicht eingecheckte Forschungsdateien und Änderungen. Das Begleitmanifest pinnt die tatsächlich benutzten Dateien per SHA-256; es behauptet nicht, der gesamte Checkout entspreche unverändert dem Basis-Commit.

- [L1] tfpt_1_architecture_e8.tex; origin_theory.tex. Architektur, Postulate, E₈-Verklebung, Clocks und elektromagnetische Formel. Historische physikalische Abschlussformulierungen werden hier nicht unkritisch übernommen.
- [L2] tfpt_2_standard_model.tex; verification/tfpt_constants.py. Ladungsstruktur, Flavor-Ansatz, gemeinsame Konstanten und explizite dimensionale Eingabe.
- [L3] predictions.txt; verification/status_ledger.csv. Historische Vorhersageoberfläche. Nicht alle dortigen Datenvergleiche wurden neu auditiert; bedingte Sekundärphänomenologie wird als solche bezeichnet.
- [L4] docs/OPEN_PROBLEMS.md; experiments/theory-contracts/RESEARCH_2026-09-09.md. Verbindliche offene physikalische T1–T8-Forderungen.
- [L5] docs/TFPT_UNIVERSALRAUM_SYNTHESIS_2026-09-12.md und die darin referenzierten vier Session-Berichte unter experiments/theory-contracts/primitive-transfer-selection-20260912/synthesis-20260912/. Attribution älterer endlicher Rekonstruktionsbefunde; kein neuer unabhängiger Replay aller Sessions.
- [L6] experiments/theory-contracts/compiler-origin-audit-20260913/{label_lift.py,spinor_symmetry.py,context_instrument.py,CONTEXT_INSTRUMENT.md}. Quellpins: verification/v783_two_qubit_clifford.py und verification/v752_projective_hamming_incidence.py. Die ausgeführten Quellpräfixe P0/P1 sind nicht mit einem vollständigen Neubau aller Gruppenprüfungen gleichzusetzen.
- [L7] experiments/theory-contracts/compiler-origin-audit-20260913/{record_composition.py,RECORD_COMPOSITION.md,run_checks.py,verification.json}. Vier Audits, 11 gezielte Negativkontrollen und Vergleich normaler mit optimierter Python-Ausführung. Die neuen Zahlenprüfungen des Papers ersetzen diese Audits nicht.
- [L8] docs/TFPT_DREI_FEHLENDE_BEZIEHUNGEN_2026-09-12.md. Frühere Klassifikation lokaler und gemeinsamer Kanäle, Raten-Gegenproben und Vier-Generatoren-Hypothese; hier als datierte Vorbefunde eingeordnet, nicht erneut vollständig ausgeführt.
- [L9] Vom Nutzer am 14. September 2026 übermittelter Text „Mein Ergebnis: Der endliche Prozess auf 60 Strahlen lässt sich vollständig lösen …“, archiviert als experiments/theory-contracts/compiler-extension-audit-20260914/USER_SUBMISSION.md. Urheberschaft der dort berichteten Untersuchung nicht unabhängig geprüft. Die abschließend genannten ChatGPT-Anhangsverweise liefern hier keine erreichbaren Beweis-/Code-Dateien; diese wurden nicht eingesehen oder ausgeführt.
- [L10] Eigene unabhängige Nachrechnung und Fortsetzung: experiments/theory-contracts/compiler-extension-audit-20260914/{README.md,check_extension.py,verification.json,run_checks.py,replay.json}. Tatsächliche Quellprojektoren, exakte endliche Rechnungen, gesonderte analytische Sätze und ausdrücklich zusätzliche Tetramer-Annahmen.
- [E1] NIST/CODATA: 2022 recommended values, Übersicht der Konstanten. https://physics.nist.gov/cuu/Constants/Table/allascii.txt . Fest datierter Referenzwert, keine behauptete Neumessung von 2026.
- [E2] I. Esteban et al., NuFit-6.0: Updated global analysis of three-flavor neutrino oscillations, arXiv:2410.05380v2. https://arxiv.org/abs/2410.05380v2 . Daten bis September 2024; Varianten nicht vermischen.
- [E3] Planck Collaboration, Planck 2018 results. VI. Cosmological parameters, arXiv:1807.06209v4. https://arxiv.org/abs/1807.06209v4 . Referenz unter Basis-ΛCDM, nicht modellfreie Naturkonstanten.
- [E4] S. Aaronson und D. Gottesman, Improved Simulation of Stabilizer Circuits, Phys. Rev. A 70, 052328 (2004), arXiv:quant-ph/0406196. https://arxiv.org/abs/quant-ph/0406196 . Grundlage der begrenzten klassischen Simulierbarkeitsaussage.
- [E5] Particle Data Group, Review of Particle Physics, CKM Quark-Mixing Matrix (2024). https://pdg.lbl.gov/2024/reviews/rpp2024-rev-ckm-matrix.pdf . Standardkonventionen, nicht externe Bestätigung der TFPT-Herkunft.
- [E6] R. Penrose und W. Rindler, Spinors and Space-Time, Band 1, Cambridge University Press (1984). Standardhintergrund der Hermitesche-Matrix/Spinor/Lorentz-Verbindung; keine neue TFPT-spezifische Herleitung aus dieser Referenz.
- [E7] Y. Miyazaki et al., Linear Flavor-Wave Analysis of SU(4)-Symmetric Tetramer Model with Population Imbalance, J. Phys. Soc. Jpn. 91, 073702 (2022). https://arxiv.org/abs/2205.11155 . Hintergrund zu SU(4)-Zellen; kein Beleg für eine TFPT-Quellauswahl der hier gesetzten Austauschmatrix.
- [E8] F. A. Pollock et al., Operational Markov condition for quantum processes, Phys. Rev. Lett. 120, 040405 (2018). https://arxiv.org/abs/1801.09811 . Operationaler Rahmen für zeitliche Eingriffe und Gedächtnis.

## Anhang B. Reproduktion und Reichweite der Prüfung

Die bearbeitbare Quelle dieses Manuskripts ist diese Markdown-Datei. Das zugehörige Build-Skript erzeugt ein gesetztes PDF, eine maschinenlesbare Zahlentabelle und ein Herkunftsmanifest. Die neuen Prüfungen berechnen den elektromagnetischen Formelwert, Flavor-/Kosmologie-Ausgaben, die CKM-Matrix samt γ und die rationalen Anomaliesummen unabhängig von den gerundeten Tabellenwerten. Die Zahlen werden mit expliziten Fehlerschranken beziehungsweise exakten Vergleichen geprüft; erfolgreiche Ausführung ist keine Begutachtung der physikalischen Theorie.

Der Papierbau verändert keine ältere Theoriequelle, keinen Ledger und keinen T1–T8-Status. Für Version 1.0 am 13. September wurden die vier endlichen Ursprungsaudits erneut mit run_checks.py ausgeführt: 11.214 eigene Prüfbedingungen je Ausführungsmodus sowie elf zurückgewiesene fehlerhafte Varianten. Version 1.1 ergänzt einen separaten Replay mit 519 eigenen Prüfbedingungen pro Modus und sechs erkannten Mutanten; der Quellpräfixadapter führt zusätzlich 1.073 übernommene Kontrollen aus. Normale und optimierte Ausgaben stimmen überein. Die Zahlentabelle und der PDF-Satz werden für die Revision neu erzeugt. Keine dieser Testzahlen ist eine Zahl unabhängiger physikalischer Entdeckungen.

Die mathematischen Beweise für alle Iterationen, die positive Alpha-Nullstelle, die robuste Grundzustandsidentifikation und die Zweizellen-Grenze stehen im Text und technischen Bericht. Ihre allgemeinen Aussagen werden nicht durch eine bloße Stichprobe behauptet. Ein vollständiger Lean-Neubau, ein kompletter RH-Lauf, eine neue globale Datenanpassung und eine unabhängige Replikation sämtlicher älterer Session-Experimente gehören nicht zum Umfang dieses Manuskripts. Die ursprüngliche PDF- und Markdown-Version bleibt erhalten; die Revision besitzt einen neuen Datumsnamen.

## Anhang C. Elementarer Eindeutigkeitsbeweis der festgelegten Alpha-Gleichung

Schreibe d=48c₃⁴, C₀=(4/5)41c₃⁶, q(α)=d exp(−2α), f(q)=q(1−q)^(−5/4) und g(α)=−log[1/(6π)+f(q(α))]. Die gesuchte Funktion ist F(α)=α³−2c₃³α²−C₀g(α). Für α>0 betrachten wir den Quotienten:

$$\frac{d}{d\alpha}\left(\frac{F(\alpha)}{\alpha^2}\right)=1+\frac{C_0}{\alpha^3}\left(2g(\alpha)-\alpha g'(\alpha)\right).$$

Es genügt, den Klammerausdruck positiv zu halten. Aus 3<π<10/3 folgt d<1/6000. Für 0<q<1/6000 gelten f(q)<2q und f′(q)=(1+q/4)(1−q)^(−9/4)<4. Damit ist 1/20<φs<1/18+2/6000<1/16, also g>log16>2. Weiter gilt g′=2qf′/φs<160q. Wegen α exp(−2α)≤1/(2e)<1/2 folgt αg′<80d<1/50. Somit ist 2g−αg′>4−1/50>0.

Der Quotient F(α)/α² wächst also strikt. Für α→0⁺ geht er gegen −∞, weil g(0)>0; für α→∞ geht er gegen +∞, weil g durch log20 beschränkt bleibt. Der Zwischenwertsatz liefert genau eine positive Nullstelle. Sie ist einfach, denn an der Nullstelle ist F′=α²·(F/α²)′>0. Die groben rationalen Schranken werden im neuen Prüfer zusätzlich kontrolliert. Dies beweist die Eindeutigkeit der angegebenen mathematischen Gleichung und ausdrücklich nicht ihre Identifikation mit der physikalischen Thomson-Kopplung. [L10]


## Nachtrag N: Die sechs neuen Quellen und ihre unabhängige Prüfung

Die neuen Arbeiten enthalten echte Fortschritte. Das klar definierte Modell aus
zwei Vierträgerzellen ist stärker gelöst als zuvor: Sein Grundzustand bleibt bei
jeder endlichen positiven Brückenkopplung eindeutig. Die bessere Präparation auf
einem Viererstern ist ebenfalls mathematisch ausführbar. Mehrere scheinbare
Widersprüche zwischen den Texten betreffen verschiedene Messzugriffe oder
unterschiedliche Subtraktionen derselben Energie.

Die vorgeschlagene gemeinsame U-Regel enthält aber einen bisher nicht sauber
aufgelösten Konflikt: Sie soll alles über die Eingangsfarben aufzeichnen und
zugleich die ursprüngliche Quanteninterferenz unverändert bewahren. In der
ausgeschriebenen Form geht beides nicht. Speichert das Register, ob der Weg
„ab“ oder „ba“ war, entsteht ein anderer Austauschoperator. Die gewünschte
eindeutige Vierträgerzelle wird dann durch 24 gleichberechtigte Grundzustände
ersetzt.

Eine konkrete sparsamere Reparatur funktioniert: **Die Aufzeichnung darf
verschiedene Kanten unterscheiden, muss aber die intern interferierenden Wege
einer Kante zusammenlassen.** Das lässt sich als exakte Bedingung an
Record-Überlappungen formulieren und mit einer vollständig unitären lokalen
Operation verbinden. Diese lokale Reparatur ist nun konstruiert. Sie bestimmt
noch keine einzige globale Physik, denn selbst minimale reversible
Fortsetzungen desselben Kanals besitzen unterscheidbare Mehrzeitantworten.

Unser fehlendes Bindeglied ist damit präziser: Nicht ein noch größerer Raum,
sondern eine **ausgewählte Regel, welche Alternativen kohärent zusammenwirken,
welche Vorgänge getrennt bleiben und wie diese Regel fortgesetzt wird**.
Dass dies allein Raumzeit, Standardmodell und Gravitation bestimmt, ist eine
noch zu prüfende Hypothese.

## N1. Quellen und Reichweite

Alle sechs Texte wurden vollständig gelesen. Ihre Aussagen wurden aufgeteilt in
exakte Modellidentitäten, numerische Befunde, Herkunftshypothesen und nicht
reproduzierte externe Prüfberichte. Eingebettete Arbeitsanweisungen wurden nicht
als neue Nutzeraufträge ausgeführt. Maßgeblich ist der Nachweis mit seinen
Voraussetzungen, nicht das jüngere Datum oder die Anzahl zustimmender Sessions.

| Kürzel | Eingesandter Text | Hauptrolle in dieser Prüfung |
|---|---|---|
| S1 | `TFPT_UNIVERSALRAUM_KONSOLIDIERUNG_2026-09-14_fable.md` | Vergleich vieler Vorstufen; stärkere Behauptungen über die U-Regel geprüft |
| S2 | `TFPT_Universalraum_Rekonstruktion_2026-09-14_sol.md` | Zugriffsklassen, klare Quellenverträge und T1–T8-Grenzen |
| S3 | `TFPT_Universalraum_Konsolidierung_2026-09-14.md` | Kurzfassung; mehrere Gleichsetzungen und der vorgeschlagene nächste Kanal korrigiert |
| S4 | `TFPT_UNIVERSALRAUM_Q_AUDIT_UND_U_REGEL_2026-09-14.md` | Globaler/lokaler Kernel, vorgeschlagenes History-Label, Relaxation und Raumzeitansätze |
| S5 | `TFPT_Rekonstruktion_2026-09-14.md` | Allkoppliger Zweizellenbeweis, Belegungskonflikt und zusätzliche Herkunftsgrenzen |
| S6 | `TFPT_Sechs_Pruefpunkte_Analyse.md` | Mikrokandidat, Sternfilter, Vierkörperterm und Dimensionsgegenmodelle |

Die Originale und ihre Prüfsummen liegen im
[Quellenarchiv](../experiments/theory-contracts/universalraum-six-source-audit-20260914/source_manifest.json).
Die vollständigen Herleitungen dieses Nachtrags stehen im
[technischen Audit](../experiments/theory-contracts/universalraum-six-source-audit-20260914/README.md).

## N2. Was nach unabhängiger Prüfung trägt

### N2.1 Die endliche Struktur

Die tatsächlichen 60 Quellprojektoren in 15 Kontexten bleiben der Anker. Die
passive Marginalbeschreibung besitzt 45 lineare beziehungsweise 44 normierte
affine Dimensionen. Das gilt für feste Ausführung und getrennte System-/Kontext-
Marginalien aller Horizonte, nicht für beliebige Eingriffe in Register. Die
240 CQ-Koordinaten sind ein größerer Eingangsraum, keine universelle
Minimaldimension und keine natürliche Identifikation mit 240 E8-Wurzeln.

Die erneute Wurzelenumeration bestätigt 960 gleichgradige Kanäle nach (10,6).
Die gemischte Klammer landet dagegen in (45,1)⊕(1,15), einschließlich der
entsprechenden Cartanbeiträge, niemals in (10,6). Die am Ende von S3
vorgeschlagene gemischte Superaustauschklammer ist daher zu verwerfen. Ein
korrekt gerechneter endlicher Klammerkoeffizient wäre ohnehin noch keine
Schließung der nativen chiralen Naht T2.

### N2.2 Zwei Zellen: stärker als im bisherigen Paper

Für zwei vollständige Tetramer mit einer Brücke, H=HA+HB+λP^+_ab,
J>0 und λ≥0, gilt

$$R=\sqrt{16J^2-2J\lambda+\lambda^2},\qquad Q=\sqrt{4J^2+\lambda^2},$$
$$E_0=\frac{4J+\lambda-R}{2},\qquad E_1=3J+\frac{\lambda}{2}-\frac{Q}{2},\qquad \Delta_{\rm gap}>\frac{J}{2}.$$

Der Grundzustand ist für jede endliche Kopplung eindeutig. Der ausgeschriebene
Sektorbeweis wurde überprüft und seine entscheidenden Tensor- und
Kompressionsidentitäten exakt rekonstruiert. Alle 15 zulässigen Youngsektoren
wurden zusätzlich an zehn Kopplungswerten numerisch verglichen. Die frühere
8J-Grenze und unsere konservative 16J/5-Schranke sind damit als bloße
Beweisgrenzen einzuordnen. Der Satz gilt nicht automatisch für den
dreiecksfreien Clebsch-Graphen oder beliebig viele Zellen.

### N2.3 Präparation und Anregungen

Der Viererstern besitzt ebenfalls genau Ω als Nullzustand. Sein vollständiges
Spektrum und das exakte Filterpolynom wurden rekonstruiert. Am festgelegten
Eingang gelingt die ideale Projektion mit Wahrscheinlichkeit 1/6 statt 3/32.
Alle acht Registerausgänge einschließlich der Fehlschläge wurden geprüft.
Gesteuerte Zeitentwicklung, Registerinitialisierung und Messung bleiben
zusätzliche Ressourcen. Ein besseres ideales Filter ist kein Beweis für
kosmologische Kühlung oder günstigere Hardwarekosten.

Die neuen Clebsch-Läufe finden bei der ersten angeregten Singulettenergie
vier orthogonale Eigenvektoren. Das alte Dublett ist damit numerisch
widerlegt. Präzise bleibt die Aussage „mindestens vier“; ein exaktes
Multiplizitätszertifikat und ein neuer vollständiger Nichtsingulettvergleich
wurden hier nicht erbracht.

### N2.4 Vermittlung: lokale Erfolge, erhaltene Zusatzdaten

Die Belegung erklärt die Orthogonalität verschiedener virtueller Lochmuster
in zweiter Ordnung. Im ausdrücklich festgelegten Modell entsteht deshalb
der positive relative Austausch 2t²/Δ. Die vierte Ordnung bleibt relevant.

Die Formeln -8t^4 S6/Δ³ und +16t^4 P_-/Δ³ lassen sich im angegebenen
harmonischen Zweibondmodell zusammenbringen: Die erste ist der verbundene
Rest nach Abzug beider Einzelbondkorrekturen, die zweite der betreffende
gesamte vierte Ordnungsanteil im aktiven 6⊗6-Sektor. Unterschiedliche
Subtraktionen sind nicht ohne Weiteres unterschiedliche physikalische Modelle.
Die gesamte C16-Vermittlung in vierter Ordnung wurde nicht berechnet.

Das exakte isolierte j=(√(Δ²+4g²)-Δ)/2 ist nicht identisch mit seinem
führenden Ausdruck g²/Δ=2t²/Δ bei endlicher Kopplung. Auch der starke
exakte Swap-Puls ist nicht derselbe Betriebsmodus wie die schwache Elimination.

## N3. Die entscheidende Korrektur an der gemeinsamen U-Regel

### N3.1 Welche Information muss erhalten, welche Interferenz muss möglich bleiben?

Für den lokalen antisymmetrischen Kanal gilt K†K=I-S. Die beiden Eingänge
|ab> und |ba> treffen denselben Vermittlerzustand mit entgegengesetztem
Vorzeichen. Darin liegt die notwendige Interferenz.

S4 Teil II §2 und S1 §5.2 schreiben zusätzlich ein History-Label
`|s,t,a,b,mu>` an den Ausgang. Wenn diese Labels orthogonal sind, trifft
|ab> einen anderen Gesamtzustand als |ba>. Der neue Gramoperator ist

$$\widetilde K^\dagger\widetilde K =I-\sum_a|aa\rangle\langle aa|\ne I-S.$$

Das zerstört nicht Information im globalen System. Es beseitigt gerade die
Interferenz zwischen diesen beiden Wegen in der behaupteten lokalen
Elimination. Die zweite Ordnung und sogar die kollektive SU(4)-Symmetrie
ändern sich. Im vollständig farbmarkierten Vierermodell bleibt eine
24-dimensionale Grundzustandsmenge statt CΩ.

Die lokale Reparatur ist einfach und exakt:

Verschiedene Kanten müssen beim Rückweg unterscheidbar bleiben. Die
vertauschten Farbwege derselben Kante müssen dagegen denselben
History-Zustand besitzen.

Für normierte Records heißt das: h_e,ab=h_e,ba; zwischen verschiedenen Kanten
können die Records orthogonal sein. Die Löcher reichen bereits als Kantenlabel.
Die Nullrichtungen des Kanals werden in einem erhaltenen Nicht-Ereigniszweig
mitgeführt. So verschwindet kein Zustand aus einer behaupteten unitären Regel.

### N3.2 Aus einer Idee wird eine konkrete lokale Operation

Mit W=K/√2 und P=P_+ lautet eine vollständige lokale Ausführung auf dem 22-dimensionalen Raum (C⁴ ⊗ C⁴) ⊕ C⁶, mit ψ im Paar- und ξ im Vermittlersektor:

$$U_\theta(\psi,\xi)=(e^{i\theta}P\psi+W^\dagger\xi,\;W\psi).$$

Sie ist für jedes θ unitär und bewahrt die kollektive SU(4)-Symmetrie.
θ=0 erhält den Nicht-Ereigniszweig unverändert. Damit ist eine elementare
Ausführung tatsächlich hingeschrieben und geprüft, nicht nur U†U=I verlangt.

**Was damit noch nicht gelöst ist:** θ=0 und θ=π/2 besitzen denselben ersten
blockdephasierten Schatten, liefern nach kohärenter Wiederholung aber
orthogonale Rückkehrzustände. Minimaler Hilbertraum und Unitarität allein
wählen somit keine eindeutige Mehrzeitdynamik.

Ein besonders sparsamer zusätzlicher Ansatz wäre das Prinzip
**„Kein Ereignis bedeutet unveränderter Zustand“**: U wirkt auf ker K als
Identität. Innerhalb der oben festgelegten Blockklasse mit vollständig
fixiertem W und Rückkanal W† wählt das θ=0 eindeutig. Es ist ein klarer
Zusatz zum Quellenvertrag, noch kein aus E8 bewiesenes Naturgesetz. Die
Auswahl von Netzwerk, Ereignisreihenfolge, Energien, Zustand und Auslesung
bleibt separat zu leisten.

### N3.3 Der Einfluss der History lässt sich sogar quantitativ bestimmen

Bei einem reellen Überlapp η zwischen den beiden Farbrecords entsteht im
deklarierten Eliminationsmodell die verschobene Energie

$$\overline{H}_\eta=2\eta H_{\rm tet}/J+(1-\eta)D_{\rm coll}.$$

Für 0<η≤1 ist Ω eindeutig und die Energielücke exakt 4η in diesen Einheiten.
Bei η=0 werden die 24 Farbanordnungen gleichberechtigt. Dies ist eine
berechenbare Verbindung zwischen Aufzeichnung und Zellstabilität.
Sie betrifft die effektive Gramenergie; die andere Regel H=P_ker(K_eta)
ist damit nicht gleichzusetzen.

## N4. Weitere Abkürzungen, die nicht tragen

**Eine einzige dunkle Mode garantiert keine Präparation.** L=I-PΩ besitzt
genau CΩ als dunklen Raum. Der entsprechende Lindblad-Dissipator lässt
trotzdem jeden Zustand im orthogonalen Komplement stationär. Eine
Relaxationserklärung muss alle stationären Zustände und invarianten
Unterräume prüfen. Das Wort „Reservoir“ genügt dafür nicht.

**Maximale Entropie braucht eine festgelegte Ereignisart.** Über sieben
Kontexte ergibt sie a=1/7, über die 13 erreichbaren Strahlen a=1/13.
Der zweite Prozess hat Rang 60. Der Rang-30-Selektor gilt nur unter der
festgehaltenen inzidenten Kontextfamilie. Bei symmetrieverträglich erweiterter
Nachfolgerklasse existieren Ränge 15 und 16. Die Beobachtungsebene ist Teil
des Prinzips, keine kostenlose Konvention.

**Eine Kommutante ist noch keine physikalische Symmetriegruppe.** Die volle
Kommutante eines Hamiltonoperators umfasst insbesondere seine ganzen
entarteten Energieräume. Schon beim Tetramer ist ihre Dimension 23.076.
Die Erwartung „volle Kommutante gleich SU(4)×W(D5)“ ist nicht die richtige
Prüffrage. Zu testen sind lokalitäts- und quelltreue Transformationen einer
festgelegten Operatorfamilie. Die behauptete gewöhnliche Spin(10)-Wirkung
scheitert im festen Gewichtsplatz-Belegungssektor bereits an einem explizit
geprüften Zweiplatz-Transfer.

**Grad fünf wählt keine drei Raumrichtungen.** Exakte Überlagerungsdaten
d=1,2,3,4 erhalten die lokale Clebsch-Inzidenz und besitzen jeweils eine
positive akustische quadratische Form. Globale Verklebung ist also ein
fehlendes Datum. Eine generische Weyl-Zweibandberührung hat Kodimension drei,
setzt aber den geeigneten Impulsraum und die betreffende Poleigenschaft
voraus. Für G^-1=ωI-Σv_iq_iσ_i gilt ω²-Σv_i²q_i², nicht die in S4
geschriebene Form mit ungewollten Kreuztermen.

**Ein einheitlicher Kegel ist noch kein Graviton.** Lokale Basiswechsel und
Frame-Variablen definieren mögliche Eich- und Geometriebeschreibungen. Sie
beweisen weder einen masselosen Spin-2-Pol noch dessen positive physische
Helizitäten oder einen wechselwirkenden Einstein-Grenzwert. Auch ein Index
3 wäre nur dann eine Familienherleitung, wenn derselbe physikalische
Diracoperator, seine Darstellung und sein Maß die richtige Deutung tragen.

## N5. Der konsolidierte TOE-Vertrag

Die Einteilung in drei große Unbekannte A/B/C ist als Organisation brauchbar,
aber kein Satz, dass nur drei kurze Rechnungen fehlen. Die folgenden acht
Anforderungen müssen aus derselben Quelle erfüllt werden.

| Tor | Was jetzt belastbar vorliegt | Konkreter noch fehlender Nachweis |
|---|---|---|
| T1 Quelle | Explizite lokale unitäre Reparatur und Gegenmodelle zu ihrer Eindeutigkeit | Zulässige Aufzeichnung, Kernelphase, Besetzung, globale Zusammensetzung und Zustandswahl ohne nachträgliche Anpassung |
| T2 Naht | Endliche E8-Typen; abstrakte Gitter-/Vertexstruktur aus den markierten Voraussetzungen | Nativer phasentreuer Half-Charge-Adapter mit Energie-/Adjungiertenkontrolle und demselben chiralen Grenzwert; eine andere CFT nur hinzusetzen reicht nicht |
| T3 Raumzeit | Bedingte Lorentzstruktur; explizite Dimensionsalternativen | Ausgewählte globale Familie, tatsächlich kohärente Pole und gemeinsamer Kegel aller relevanten Sektoren |
| T4 Standardmodell | Endliche Darstellungen und historische Anomaliesummen; Typkonflikt der Ortslesart geklärt | Physikalischer chiraler Operator, Familienzahl, Spiegelentkopplung und konsistentes Maß |
| T5 Kontinuum | Allkoppliger Zweizellensatz; lokaler Vierkörperbeitrag | Größenuniforme lokale Fehlerkontrolle und ein geeigneter wechselwirkender Grenzwert; eine überall gapped Produktphase trägt keine masselosen Photon-/Gravitonmoden |
| T6 Parameter | Formelwerte und ihre Eingaben nachvollziehbar | Gemeinsamer Transfer zu Eichkopplungen, Yukawas, Neutrinos und Skala mit kontrollierter Theorieunsicherheit |
| T7 Gravitation | Konkrete Zieltests statt reiner Zahlengleichheiten | Positiver masseloser Spin-2-Pol, zwei Helizitäten, Ward-Identitäten und universelle dynamische Kopplung |
| T8 Zustand | Ideale Filter, Aufzeichnungs-Kompatibilität und Mehrzeit-Gegenbelege | Einziges physikalisches Funktional beziehungsweise begründete Randbedingung; echter Attraktor statt nur dunkler Vektor |

Der Repo-Status [OPEN_PROBLEMS](OPEN_PROBLEMS.md) wird damit nicht auf
„geschlossen“ gesetzt. Ebenso folgen keine RH-, Faktorisierungs- oder
P-vs-NP-Beweise. Diese separaten mathematischen Probleme müssen auch nicht
automatisch durch eine physikalische TOE gelöst werden.

## N6. Zahlen dürfen nicht zwischen den Modellen wandern

Die Alpha-Gleichung liefert erneut
137.0359992168407125035378603038038803711 für α^-1. Gegen die ausdrücklich
datierte CODATA-2022-Referenz sind dies etwa 1,897 experimentelle
Standardabweichungen. Das ist kein Theoriefehler und kein neuer
Thomson-Transfer. Die offizielle Tabelle wurde in dieser Prüfung abgerufen.
[NIST/CODATA](https://physics.nist.gov/cuu/Constants/Table/allascii.txt)

Die wiederholte pauschale Inflationskritik muss präzisiert werden:
N≈56,13124 trifft im angegebenen Formelzweig As=2,10·10^-9. Dann sind
ns≈0,964369 und r≈0,00380866 bedingte Ausgaben, As selbst aber eine
Kalibrierungsgröße. Der negative Vergleich bei N=51,4 bleibt erhalten.
Die alten Lepton-, Higgs- und Protonspannungen wurden nicht durch neue
Transferrechnungen beseitigt; sie werden hier auch nicht als vollständig
neu gegen aktuelle Daten geprüft ausgegeben.

## N7. Priorisierte Fortsetzung mit entscheidenden Tests

1. **Ein lokaler kohärenter Quellenvertrag:** Die korrigierte Record-Grammatrix
   und gegebenenfalls das Nicht-Ereignisprinzip festlegen. Alle Eingänge,
   einschließlich ker K, müssen normerhaltend behandelt werden. Der unmittelbare
   Test ist K_e†K_e=I-S_e bei gleichzeitig verschwindenden fremden Kantenwegen.
   Der bisherige farbmarkierte Entwurf scheitert daran; die Kanten-only-Reparatur
   besteht den lokalen Test bereits.
2. **Ein gemeinsames Mehrzeitexperiment:** Mit dieser einen Regel, festem
   Anfangszustand und vorab benannten Zugriffen die nächsten zwei bis vier
   Schritte berechnen. Nicht nur die erste reduzierte Ausgabe vergleichen.
   Die hier konstruierte θ-Familie liefert einen vollständigen Diskriminator.
   Ein Erfolg verlangt zusätzlich Anschluss an die tatsächlichen Compiler-
   und Registeroperationen; bloße abstrakte lokale Ausführbarkeit genügt nicht.
3. **Native Präparation prüfen:** Einen wirklich aus derselben Kopplung gewonnenen
   Reservoir-/Registermechanismus angeben und dessen gesamtes stationäres
   Zustandsproblem lösen. Der explizite unique-dark-Gegenbeleg ist als
   Negativkontrolle beizubehalten. Keine schon präparierte Ω-Umgebung verstecken.
4. **Erst dann eine skalierende Familie:** Zwischen endlichem Clebsch-Labor und
   innerem Spin(10)-Materieindex unterscheiden. Auf einer deklarierten
   Größenfolge lokale zweite/vierte Ordnung, Propagatoren und Fehler gemeinsam
   untersuchen. Eine global kleine Operatornorm nicht durch kleines t/Δ pro
   Kante ersetzen; eine endliche Lücke nicht als Kontinuumsbeweis ausgeben.
5. **Physikalischer Abschluss:** Den chiral markierten Nahtadapter, das Maß,
   Familien, Kopplungen und Spin-2-Korrelatoren aus dieser Familie ableiten.
   Die langfristigen Anforderungen bleiben hart; ihre Auflistung ist noch
   keine Konstruktion. Erst ein vorab eingefrorener neuer physikalischer
   Ausgabevertrag kann die Herkunftsfrage empirisch weiter entscheiden.

Die Methoden der kontrollierten effektiven Theorie und der Mehrzeitprozesse
sind etabliert; ihr Einsatz ersetzt nicht die TFPT-Quellwahl.
[Schrieffer-Wolff](https://arxiv.org/abs/1105.0675),
[operationelle Mehrzeitprozesse](https://arxiv.org/abs/1801.09811).

## N8. Was in dieser Runde tatsächlich ausgeführt wurde

Der eigene finale Prüfer besitzt **100 benannte Bedingungen pro Modus**:
78 exakte/Integritätsbedingungen und 22 numerische Bedingungen. Normaler und
optimierter Lauf sind bytegleich. Fünf gezielte Fehleränderungen werden jeweils
vom vorgesehenen Test erkannt. Zusätzlich liefen 1.073 Quell-Prefixprüfungen
und 238 Helper-Bedingungen; dies sind keine unabhängigen physikalischen Tests.

Die sechs Originaldateien sind bytegleich archiviert. Geprüft wurden unter
anderem 65.536-komponentige exakte Zweizellentensoren, alle 15
Achtträger-Youngsektoren an zehn Kopplungen, zwei neue Clebsch-Singulettläufe,
sämtliche Sternfilterausgänge und die oben angegebenen neuen Gegenmodelle.
Keine Dokumentbehauptung wurde allein wegen einer großen fremden Checkzahl
übernommen. Die fehlenden Originalpakete und nicht erneut gelaufenen
Großprüfungen sind im technischen Audit einzeln ausgewiesen.

Die Ergebnisdateien liegen im
[Prüfbericht](../experiments/theory-contracts/universalraum-six-source-audit-20260914/verification.json)
und [Replay-Nachweis](../experiments/theory-contracts/universalraum-six-source-audit-20260914/replay.json).
Die ältere Paper-PDF bleibt unverändert. Dieser Nachtrag ist in Version 1.2 in die Gesamt-PDF integriert. Der Beweisstatus der zugrunde liegenden Prüfung wird dadurch nicht erweitert.
