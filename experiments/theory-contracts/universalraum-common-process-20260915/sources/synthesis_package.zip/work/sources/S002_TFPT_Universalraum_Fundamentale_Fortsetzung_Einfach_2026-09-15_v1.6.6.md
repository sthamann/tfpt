# TFPT / Universalraum: Was die intensive Fortsetzung gebracht hat

## Einfach erklärt · v1.6.6 · 15. September 2026

**Wir haben jetzt einen kontrollierten Weg in den nativen Grundzustand, eine Mindeststärke seiner unvermeidlichen Restantwort und eine genauere Entscheidung darüber, welche einfachen Wege zu Raum und Feldern funktionieren können.** Die vollständige gemeinsame Quelle unserer Physik bleibt offen.

## 1. Das Instrument lässt sich gezielt einstimmen

Das Bild aus v1.6.5 war ein Instrument mit einem bevorzugten Ruhezustand. Bisher war bekannt: Lässt man irgendeinen Anfangszustand einfach unter derselben unveränderten Dynamik laufen, wird daraus nicht von selbst dieser Ruhezustand.

Nun gibt es einen konkreten anderen Ablauf. Wir beginnen mit allen 64 Fermionplätzen besetzt und ohne Bosonen. Dann schalten wir die bereits vorhandene Paarumwandlung langsam ein. Ich habe bewiesen, dass der gewünschte Zustand unterwegs im selben Ladungssektor immer von den anderen Energien getrennt bleibt. Diese Trennung beträgt durchgehend mindestens rund **0,082 der Energieskala Δ**.

Das ist die mathematische Voraussetzung dafür, dass das System beim langsamen Einschalten dem gewünschten Zustand folgt. Eine ausdrücklich angegebene, sehr konservative Dauer ergibt eine Grundzustandswahrscheinlichkeit von **mehr als 99,9999726 %**.

Diese Zahl gilt unter Voraussetzungen: Der voll besetzte Anfangszustand muss verfügbar sein, die Kopplung muss steuerbar sein, und die Ladung muss erhalten bleiben. Die Dauer ist in Modelleinheiten angegeben; wir kennen keine dazugehörige Sekundenzahl. Der Satz löst die Frage nach einem geeigneten Ablauf. Er leitet die nötigen Bedienelemente noch nicht aus dem ursprünglichen Compiler ab.

## 2. Die Nebentöne haben eine messbare Mindeststärke im Modell

Entfernt man aus dem nativen Grundzustand ein Fermion, dominiert ein einzelner tiefer Ton. Schon vorher war klar, dass die vollständige Antwort trotzdem nicht aus nur zwei idealen Tönen bestehen kann.

Jetzt ist diese Aussage stärker. Die Bosonenzahl schwankt im Grundzustand um ihren Mittelwert; ihre Varianz ist **größer als 0,1193989**. Ich habe eine Identität hergeleitet, die diese Schwankungen an die Kopplung zum restlichen Antwortsystem bindet.

Dadurch bekommt die bisher nur als „nicht null“ bekannte Restkopplung eine strenge positive Untergrenze. Ihr quadrierter Koeffizient ist größer als

**0,0000009640875 × Δ².**

Das ist keine Prozentangabe für Nebentöne. Es ist ein genau definierter Koeffizient der Spektralrechnung. Wir kennen damit eine Mindeststärke, noch nicht die vollständige Form oder maximale Größe des Rests. Eine nächste Rechnung darf diesen Koeffizienten nicht einfach auf null setzen.

## 3. Zwei unabhängige Instrumente entstehen nicht durch einen Strich in der Mitte

Der ursprüngliche Tensor verbindet 64 Fermionmoden durch 480 Paarterme. Diese Verbindungen sind nicht in zwei getrennte Gruppen zerlegbar, wenn wir bei den ursprünglichen Moden bleiben.

Die neue Rechnung ist sogar quantitativ: Teilen wir die 64 Moden in zwei Gruppen zu je 32 auf, kreuzen **mindestens 192 der 480 Paarterme** die Grenze. Das gilt für jede solche Auswahl, nicht nur für eine getestete Aufteilung.

Die beiden Hälften sind also nicht automatisch zwei eigenständige native Banken. Der ältere Transferbeweis arbeitete dagegen mit zwei vollständigen Kopien der Bank, jeweils mit eigenen Fermion- und Bosonmoden. Beide Aussagen passen zusammen.

Das macht die Raumfrage konkreter: Wir benötigen eine ursprüngliche Vorschrift, die aus dem intern verbundenen System tatsächlich erkennbare Teile macht. Diese Vorschrift muss gleichzeitig sagen, welche Operationen lokal sind, welche Zustände dort stabil bleiben und wie wir sie auslesen. Eine Umbenennung innerer Moden in Orte reicht dafür nicht.

## 4. Ein vorgeschlagener Feldtyp ist frei nicht stabil

Für den relativistischen Spinortensor war zuletzt ein erlaubter kinetischer Term gefunden worden. Bei rein zeitlicher Veränderung sah er positiv aus.

Ich habe zusätzlich räumliche Veränderungen untersucht. Dabei entstehen zulässige Zustände mit negativer Energie, die beliebig weit nach unten gehen kann. Außerdem gibt es Lösungen, deren Amplitude mit der Zeit linear wächst.

Damit ist dieser konkrete freie Ansatz entschieden: **Als eigenständiges Feld ohne weitere Bedingungen ist er kein stabiler physikalischer Träger.** Das schließt nicht jede Tensorfeldtheorie aus. Zusätzliche Constraints, ein anderer zugrunde liegender Träger oder eine nachgewiesene Stabilisierung durch Wechselwirkungen ändern die Frage.

Ein konstruktiver Vergleich ist möglich: Der Tensor könnte aus der Feldstärke eines massiven Vektorfelds stammen. Dessen freie Energie ist positiv, und der gewünschte Paar-Tensor kann algebraisch daran koppeln. Dieser Weg benötigt aber zusätzliche Struktur, eine Massenskala und einen Wechselwirkungsterm höherer Dimension. Er ist daher ein prüfbarer Modellvorschlag, noch keine native Ableitung.

Auch die frühere skalare Alternative hat einen klaren Preis: Sie benötigt eine zweite unabhängige Komponente. Behält man durch eine einfache gemeinsame Projektion nur eine davon, verschwindet gerade der reparierte Wechselwirkungsterm wieder.

## 5. Wo wir dadurch stehen

| Baustein | Stand nach dieser Fortsetzung |
|---|---|
| Nativer Grundzustand und dominante Lochantwort | Aus dem bisherigen Stand übernommen; für die Fortsetzung benötigte Identitäten frisch geprüft |
| Langsames Einstimmen in den Grundzustand | Mit durchgehender Sektorlücke und Fehlergrenze hergeleitet; Anfangszustand und Steuerung vorausgesetzt |
| Rest der Antwort | Neue positive Mindeststärke; vollständige Funktion und brauchbare Obergrenze fehlen |
| Aufteilung in räumliche Teile | Einfache unabhängige Koordinatenaufteilung ausgeschlossen; dynamische Ortsdefinition fehlt |
| Freier Spinortensor | Konkreter Kandidat instabil; andere vollständige Träger bleiben zu prüfen |
| Raumzeit, chirale Materie, Gravitation und Naturkonstanten | Weiterhin offen |

**Der wichtigste nächste Nachweis ist die gemeinsame Ausführung:** Woher kommen die Ladung, die Steuerung, die erkennbaren Teilbereiche und das Messinstrument? Für einen Teil dieser Ausführung liegt nun ein fertiger mathematischer Ablauf vor. Für andere Teile haben wir genauere Tests, an denen ein Vorschlag bestehen oder scheitern kann.

Die neue Fortsetzung wurde mit 238 exakten beziehungsweise rationalen Prüfbedingungen kontrolliert, normal und optimiert mit identischen Ergebnissen. Zusätzlich wurde der frühere Transferprüfer mit seinen 4.516 Bedingungen unverändert reproduziert. Das ist ein analytischer Forschungsstand mit Rechenzertifikaten, kein formaler Gesamtbeweis der Theorie. Alle acht großen Ziele T1–T8 bleiben offen; ein RH-, Faktorisierungs- oder P-versus-NP-Abschluss ist daraus nicht entstanden.
