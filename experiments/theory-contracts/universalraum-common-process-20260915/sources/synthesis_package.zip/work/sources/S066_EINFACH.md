# TFPT / Universalraum: Wo wir wirklich stehen

## Einfach erklärt - v1.6.7, 15. September 2026

**Wir haben eine einfache Grundregel und inzwischen gut verstandene erste
Bewegungen dieses Modells. Wir haben noch nicht gezeigt, dass daraus unsere
gesamte physikalische Welt folgt.** Diese Runde macht den Weg übersichtlicher:
Zwei bisher offene Strukturfragen sind gelöst, und für die Dynamik gibt es
jetzt eine kleine, korrekte Rechenkette.

## Stell dir ein Instrument vor

Der **TFPT-Compiler ist der Bauplan**: Er legt fest, welche Bauteile
zusammenpassen und welche Symmetrien sie haben.

Die **native Paarregel ist der Mechanismus**: Zwei markierte Fermionen können
zu einem Vermittler werden und zurück. Das ist weiterhin die einfache
Grundidee. Die vielen Zustände entstehen durch Wiederholung derselben Regel,
nicht durch Tausende zusätzlich erfundene Gesetze.

Der **Grundzustand ist die Ruhegestalt des Instruments**. Für den festgelegten
Modellvertrag wissen wir, dass es einen eindeutigen energetisch günstigsten
Zustand gibt. Noch offen ist, warum die Natur gerade diesen Vertrag benutzt
und wie der Zustand durch ursprüngliche Operationen hergestellt wird.

Die **geladene Anregung ist ein klarer Ton**. Entfernt man ein ursprüngliches
Fermion, trägt eine einzelne niedrige Energielinie mehr als 88 Prozent des
gesamten normierten Fermion-Spektralgewichts pro Mode. Ein klarer Ton im
Instrument ist aber noch keine Schallwelle, die sich im Raum ausbreitet.

Der **fehlende nächste Schritt ist die Übertragung**: Dieselbe Anregung muss
auf derselben Grundlage zwischen unterscheidbaren Teilen laufen. Ein
nachträglich eingebautes Verbindungskabel kann das schon in unseren
Testmodellen. Noch nicht bewiesen ist, dass das Instrument selbst genau
dieses Kabel und seine Bedienung erzeugt.

Erst danach können wir belastbar fragen, ob viele solcher Vorgänge eine
dreidimensionale Welt, relativistische Materie und Gravitation ergeben.
Der innere Clock ist dabei ein festes Symmetriemuster, nicht bereits eine
vollständige physikalische Uhr.

## Was wir diesmal tatsächlich gelöst haben

**Erstens: Die erste Verzweigung ist vollständig verstanden.**
Wir hatten gehofft, auf jeder Bosonstufe genüge genau ein Zustand. Das stimmt
nicht: Schon auf der zweiten Stufe gibt es vier symmetrische Richtungen.
Jetzt wissen wir nicht nur, dass sie existieren, sondern haben alle vier
aus der ursprünglichen Regel berechnet, einschließlich ihrer Kopplungen.
Bis zu dieser Stufe genügen insgesamt sechs Zustände für den gesamten
symmetrischen Ausschnitt. Die höheren Stufen bleiben allerdings angekoppelt.

**Zweitens: Die einfache Rechenkette bleibt möglich.**
Wir müssen ihre Schritte nach der wirklichen Entwicklung ordnen und nicht
nach der Zahl der Bosonen. Ein späterer Schritt kann mehrere Bosonzahlen
enthalten. Die ersten fünf Glieder dieser richtigen Kette sind jetzt exakt
bestimmt. Sie liefern zehn überprüfbare Energiemomente und eine kleine
Verbesserung der Grundzustandsgrenze. Die ganze Kette ist noch nicht gelöst.

**Drittens: Der scheinbar formlose Rest ist geordnet.**
Die 4035 bislang unbestimmten bilinearen Komponenten fallen in drei
Symmetrieklassen. Das ist wie das Sortieren aller zulässigen Zweierbauteile
in drei klar bezeichnete Schubladen. Es bedeutet nicht, dass wir damit
4035 neue Teilchen oder die fehlende Gravitation gefunden hätten.

## Warum die fundamentale Auswahlfrage trotzdem bleibt

Ein Bauplan allein sagt noch nicht, wie fest eine Saite gespannt ist.
Wir können denselben Tensor, dieselben Symmetrien und denselben Clock
beibehalten und dennoch verschiedene messbare Dynamiken erhalten.
Das ist jetzt nicht nur ein Einwand, sondern durch eine einfache
dimensionslose Antwortgröße nachgerechnet.

**Gesucht ist deshalb keine möglichst große Zusatzmaschine, sondern eine
begründete Ursprungsregel, die den Prozess auswählt und ausführbar macht.**
Sie muss beantworten: Welche Eingriffe sind wirklich vorhanden? Warum dieser
Zustand und diese Kopplung? Wie entsteht daraus die Übertragung? Die Antwort
darf weiterhin extrem einfach sein. Aus den bisher geprüften Daten folgt
sie aber noch nicht eindeutig.

## Was als Nächstes den größten Unterschied macht

1. **Die kleine richtige Rechenkette weiter schließen.** Nicht nur mehr
   Näherungszahlen erzeugen, sondern den Einfluss der noch fehlenden Stufen
   begrenzen. Das würde die genaue Antwort des Modells berechenbarer machen.
2. **Die Bewegung ohne eingeschmuggeltes Kabel erzeugen.** Eine konkrete
   Operation aus der ursprünglichen Quelle muss die vorhandene Anregung
   übertragen. Bloßes Umbenennen oder Überlappen von Zuständen reicht nicht.
3. **Denselben Mechanismus als konsistentes relativistisches Feld verstehen.**
   Der richtige Feldtyp, seine Bewegungsgleichung und seine Ladung müssen
   zusammenpassen, bevor wir Raumzeit und Gravitation daraus ableiten.

Die beiden neuen Untersuchungen wurden integriert, widersprüchliche Aussagen
korrigiert und die zentralen neuen Ergebnisse unabhängig geprüft. Alle acht
großen TOE-Tore bleiben offen. **Wir kennen jetzt mehr vom tatsächlichen
Mechanismus und weniger Scheinabkürzungen - aber eine vollständige
Fundamentallösung wäre eine falsche Erfolgsmeldung.**
