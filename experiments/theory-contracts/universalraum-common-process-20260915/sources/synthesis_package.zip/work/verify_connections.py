"""Exact finite witnesses for the synthesis; no physical TFPT closure claim."""
from pathlib import Path
import hashlib, json, itertools
import sympy as s
import numpy as np

checks=[]
def eq(name,a,b):
    d=a-b
    def zero(x): return s.simplify(s.expand_trig(x))==0 or s.trigsimp(s.expand_trig(x),method='fu')==0
    ok=all(zero(x) for x in d) if isinstance(d,s.MatrixBase) else zero(d)
    if not ok: raise ValueError(name+': '+str(d))
    checks.append(name)
def need(name,ok):
    if not ok: raise ValueError(name)
    checks.append(name)
I=s.I; R=s.Rational
g,D,J,k=s.symbols('g D J k',real=True)
H0=s.Matrix([[0,g,0,0],[g,D,0,0],[0,0,D,g],[0,0,g,0]])
q=s.diag(7,7,9,9); qr=s.diag(1,-1)
M=s.zeros(4);M[2,1]=1
lower=s.Matrix([[0,0],[1,0]])
eq('system_charge_of_mixer',q*M-M*q,2*M)
eq('reference_charge',qr*lower-lower*qr,-2*lower)
V=J*(s.kronecker_product(M,lower)+s.kronecker_product(M.H,lower.H))
Qt=s.kronecker_product(q,s.eye(2))+s.kronecker_product(s.eye(4),qr)
Ht=s.kronecker_product(H0,s.eye(2))+V+k*s.kronecker_product(s.eye(4),qr**2)
eq('total_charge_conserved',Qt*Ht-Ht*Qt,s.zeros(8))
E=s.zeros(8,4)
for col,row in enumerate([0,2,5,7]):E[row,col]=1
eq('embedding_isometry',E.H*E,s.eye(4))
eq('fixed_total_charge_eight',Qt*E,8*E)
H4=s.Matrix([[0,g,0,0],[g,D,J,0],[0,J,D,g],[0,0,g,0]])
eq('exact_invariant_relational_block',Ht*E,E*(H4+k*s.eye(4)))
eq('no_mixer_no_transfer_blocks',(H4.subs(J,0))[:2,2:],s.zeros(2))
need('reference_initial_final_orthogonal',(s.Matrix([1,0]).H*s.Matrix([0,1]))[0]==0)
# Symmetric/antisymmetric diagonalization and exact timing for H4.
B=s.Matrix([[1,0,1,0],[0,1,0,1],[0,1,0,-1],[1,0,-1,0]])/s.sqrt(2)
eq('parity_block_rotation',B.H*H4*B,s.diag(s.Matrix([[0,g],[g,D+J]]),s.Matrix([[0,g],[g,D-J]])))
Jstar=1-1/(10*s.sqrt(3)); tstar=20*s.pi*s.sqrt(3)
Om=s.sqrt((1-Jstar)**2+4*R(1,20)**2)
eq('resonant_branch_angle',Om*tstar/2,2*s.pi)
transfer_lower=R(2009992727,2022609600)
need('quoted_bound_above_993_percent',transfer_lower>R(993,1000))
# A full-frame pure gauge loop telescopes; subspace overlaps need not.
u0=s.Matrix([1,0]);u1=s.Matrix([1,1])/s.sqrt(2);u2=s.Matrix([1,I])/s.sqrt(2)
z=(u0.H*u1)[0]*(u1.H*u2)[0]*(u2.H*u0)[0]
eq('bargmann_triangle',z,(1+I)/4)
eq('postselection_probability',s.conjugate(z)*z,R(1,8))
Ps=[u*u.H for u in [u0,u1,u2]]
eq('projected_cycle_amplitude',(u0.H*Ps[2]*Ps[1]*u0)[0],(1-I)/4)
for n,P in enumerate(Ps):eq(f'projector_{n}',P*P,P)
th,ph=s.symbols('theta phi',real=True)
u=s.Matrix([s.cos(th/2),s.exp(I*ph)*s.sin(th/2)])
P=u*u.H
At=s.simplify(I*(u.H*u.diff(th))[0]);Ap=s.simplify(I*(u.H*u.diff(ph))[0])
eq('berry_A_theta',At,0);eq('berry_A_phi',Ap,-s.sin(th/2)**2)
F=s.diff(Ap,th)-s.diff(At,ph)
eq('berry_curvature',F,-s.sin(th)/2)
eq('projector_curvature',I*(u.diff(th).H*(s.eye(2)-P)*u.diff(ph)-u.diff(ph).H*(s.eye(2)-P)*u.diff(th))[0],F)
eq('quantum_metric_theta',(u.diff(th).H*(s.eye(2)-P)*u.diff(th))[0],R(1,4))
eq('quantum_metric_phi',(u.diff(ph).H*(s.eye(2)-P)*u.diff(ph))[0],s.sin(th)**2/4)
# Record Gram comparison and gauge-correct compression.
K=s.Matrix([[0,1,-1,0]])
swap=s.Matrix([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]])
eq('antisymmetric_exchange_gram',K.H*K,s.eye(4)-swap)
L=s.Matrix([[0,1,0,0],[0,0,-1,0]])
need('orthogonal_records_change_gram',L.H*L!=K.H*K)
T=s.Matrix.hstack(u0,u1);S=T.H*T
eq('overlap_fake_hop',T.H*(D*s.eye(2))*T,D*S)
U=s.Matrix([[1,1],[1,-1]])/s.sqrt(2)
eq('gram_equivalence_isometry',(U*T).H*(U*T),S)
# Finite GNS: every reachable word Gram is preserved by a fixed unitary.
X=s.Matrix([[0,1],[1,0]]); Z=s.diag(1,-1)
words=[s.eye(2),X,Z,X*Z,Z*X];A=s.Matrix.hstack(*(w*u0 for w in words))
eq('all_word_gram_witness',(U*A).H*(U*A),A.H*A)
need('word_space_rank_two',A.rank()==2)
# Exact moment and source-prefix cross-checks, using rational nonsymmetric Jacobi similarity.
diag=[0,1,2,3,R(105168998,26292551)]
beta=[480,916,R(299520,229),R(78877653,47632)]
x=s.symbols('x',real=True); JJ=s.diag(*diag)
for i,b in enumerate(beta):JJ[i,i+1]=1;JJ[i+1,i]=b*x*x
v=s.eye(5)[:,0];mus=[]
for n in range(10):mus.append(s.expand(v[0]));v=JJ*v
eq('F_moment_two',mus[2],480*x*x)
eq('F_moment_three',mus[3],480*x*x)
eq('F_moment_four',mus[4],480*x*x+670080*x**4)
eq('dimensionless_selection_witness',s.cancel(mus[4]*mus[2]/mus[3]**2),1+1396*x*x)
eq('selection_x_1_20',(1+1396*x*x).subs(x,R(1,20)),R(449,100))
eq('selection_x_1_40',(1+1396*x*x).subs(x,R(1,40)),R(749,400))
eq('singlet_coupling_sum',36+16+504+360,s.Integer(916))
eq('bilinear_dimension',1+45+210+15+675+3150,s.Integer(4096))
zz=s.symbols('z');pol=(zz*s.eye(5)-JJ.subs(x,R(1,20))).det()
lo=R(-112963813,100000000);hi=R(-112963811,100000000)
poly=s.Poly(pol,zz)
need('ritz_interval_exact_one_root',poly.count_roots(lo,hi)==1)
need('ritz_no_smaller_root',poly.count_roots(-s.oo,lo)==0)
need('updated_removal_floor',R(-1121899,1000000)-hi==R(773911,100000000))
# Actual W checks and an exact characteristic polynomial for its support graph.
tensor=Path(__file__).parent/'native_tensor.npz'
need('tensor_pin',hashlib.sha256(tensor.read_bytes()).hexdigest()=='3f00a0892157a691e4ef26920c3702772c7bf76a250fad98ff04a079bb64b763')
W=np.load(tensor)['W']
need('tensor_imaginary_zero',bool(np.all(W.imag==0)))
need('tensor_integer',bool(np.all(W.real==np.rint(W.real))))
W=W.real.astype(np.int64)
need('tensor_480_signed_entries',np.count_nonzero(W)==480 and set(np.unique(W))=={-1,0,1})
need('tensor_gram',bool(np.array_equal(W@W.T,8*np.eye(60,dtype=np.int64))))
edges=list(itertools.combinations(range(64),2));Adj=s.zeros(64)
for c in np.flatnonzero(np.any(W!=0,axis=0)):
 a,b=edges[c];Adj[a,b]=Adj[b,a]=1
need('degree_15',all(sum(Adj.row(i))==15 for i in range(64)))
lam=s.symbols('lambda');char=Adj.charpoly(lam).as_expr();factors=s.factor(char)
need('connected_via_simple_degree_eigenvalue',s.Poly(char,lam).exquo(s.Poly(lam-15,lam)).eval(15)!=0)
# Exact minimal polynomial demonstrates spectrum subset; multiplicities from characteristic polynomial.
expected=(lam-15)*(lam-3)**25*(lam+1)**30*(lam+5)**3*(lam+9)**5
eq('support_graph_characteristic',char,expected)
eq('balanced_cut_floor',s.Rational(12)*32*32/64,s.Integer(192))
erasure=[]
for r in range(64):
 cols=[j for j,(a,b) in enumerate(edges) if r in (a,b)]
 C=W[:,cols]@W[:,cols].T
 erasure.append(bool(np.array_equal(C,np.diag(np.diag(C)))) and int(np.sum(np.diag(C)==1))==15 and int(np.sum(np.diag(C)==0))==45)
need('native_code_single_mode_erasure_all_64',all(erasure))
eq('native_code_dimension',s.Integer(2016-60),s.Integer(1956))
Qlift=s.Matrix([[2,-1,0],[1,0,1],[0,-1,2]])
need('no_nonzero_grade_constant_integer_lift',Qlift.det()!=0)
# Exact stationary correlation without causal coupling.
t=s.symbols('t',real=True)
YY=s.Matrix([[0,-I],[I,0]])
Hqq=(s.kronecker_product(Z,s.eye(2))+s.kronecker_product(s.eye(2),Z))/2
bell=s.Matrix([0,1,1,0])/s.sqrt(2)
Aq=s.kronecker_product(X,s.eye(2));Bq=s.kronecker_product(s.eye(2),YY)
Ut=s.diag(s.exp(-I*t),1,1,s.exp(I*t))
eq('stationary_bell',Hqq*bell,s.zeros(4,1))
eq('cross_correlation_without_signal',s.expand_complex((bell.H*Bq*Ut*Aq*bell)[0]),s.sin(t))
eq('retarded_commutator_zero',Aq*(Ut.H*Bq*Ut)-(Ut.H*Bq*Ut)*Aq,s.zeros(4))
# Block resolvent and non-invariant compression control.
zeta=s.symbols('zeta');hh=s.Matrix([[0,1,0],[1,2,1],[0,1,4]])
aa=hh[:2,:2];bb=hh[2:,:2];dd=hh[2:,2:]
eq('block_resolvent_identity',(zeta*s.eye(3)-hh).inv()[:2,:2],(zeta*s.eye(2)-aa-bb.H*(zeta*s.eye(1)-dd).inv()*bb).inv())
need('noninvariant_compression_detected',bb!=s.zeros(1,2))
out={'status':'PASS','exact_conditions':len(checks),'checks':checks,'new_relational_model_dimension':8,'fixed_charge_block_dimension':4,'transfer_probability_bound_inherited_from_H4':str(transfer_lower),'tensor_graph_characteristic':str(factors),'F_moments_0_9':[str(a) for a in mus],'berry_curvature':str(F),'triangle_bargmann':str(z),'triangle_postselection_probability':'1/8','ritz_interval':[str(lo),str(hi)],'scope':'Exact finite checks and symbolic identities. Does not derive the reference, spatial structure, original instrument availability, or any T1-T8 closure. The H4 transfer bound and native ground theorem are inherited premises.','T1_T8_closed':[]}
print(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True))
