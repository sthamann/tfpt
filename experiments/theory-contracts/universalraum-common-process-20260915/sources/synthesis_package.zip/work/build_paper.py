from pathlib import Path
import subprocess,pypandoc,shutil
root=Path(__file__).resolve().parent.parent
out=root/'outputs'
name='TFPT_Universalraum_Forschungspaper_2026-09-15'
args=[pypandoc.get_pandoc_path(),str(out/(name+'.md')),'--standalone','--from=markdown+tex_math_dollars','--to=latex','--table-of-contents','--toc-depth=2','--resource-path='+str(out),'-V','documentclass=article','-V','fontsize=11pt','-V','papersize=a4','-V','geometry:margin=23mm','-V','colorlinks=true','-V','link-citations=true','--include-in-header='+str(root/'work/paper_header.tex'),'-o',str(out/(name+'.tex'))]
subprocess.run(args,check=True,cwd=out)
xelatex=shutil.which("xelatex") or "/Library/TeX/texbin/xelatex"
for _ in range(3):
 p=subprocess.run([xelatex,'-interaction=nonstopmode','-halt-on-error','-output-directory='+str(root/'work'),str(out/(name+'.tex'))],cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (root/'work/latex_console.txt').write_text(p.stdout)
 if p.returncode: print(p.stdout[-7000:]);raise SystemExit(p.returncode)
(out/(name+'.pdf')).write_bytes((root/'work'/(name+'.pdf')).read_bytes())
print('PDF built:',out/(name+'.pdf'))
