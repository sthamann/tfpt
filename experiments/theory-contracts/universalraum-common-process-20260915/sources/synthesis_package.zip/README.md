# TFPT und Universalraum — Forschungspaper, 15.09.2026

## Lesen

- `outputs/TFPT_Universalraum_Forschungspaper_2026-09-15.pdf`: gesetzte Hauptfassung, 33 Seiten.
- Gleichnamiges Markdown: bearbeitbarer vollständiger Text.
- Gleichnamiges LaTeX: druckfähige Zwischenquelle; Abbildungen unter `outputs/figures`.
- `outputs/Quellenmanifest.json`: alle 74 eingefrorenen Dokumente mit ursprünglichem Pfad, Paketpfad und SHA-256.
- `outputs/Pruefprotokoll.json`: Umfang und Grenzen der tatsächlichen Prüfung.

Besonders relevant: §5.5 Kodierung und Modenverlust; §5.6 Z4-Erweiterung und kanonische Reduktion; §6.4 Abgleich des nachgereichten Textes und Matrixmomente; §§8–10 eigene verbindende Herleitungen; §16 offene T1–T8-Aufgaben.

## Was neu erarbeitet wurde

Ein gemeinsamer positiver Wortkern verbindet kohärente Operationsgeschichten. Ein expliziter acht-dimensionaler Referenzträger gleicht die zuvor blockierende einzelne Cartanladung beim bekannten Transfer aus. Die Projektorkonstruktion verbindet geometrische Krümmung, Metrik und reale Erfolgswahrscheinlichkeit. Die Blockresolvente gibt einen Fehlervertrag für die vorgeschlagene Matrixmomentenfortsetzung. Diese Anwendungen sind ausgerechnet; sie beanspruchen keine allgemeine wissenschaftliche Erstentdeckung der verwendeten Standardmethoden.

## Quellenstand

Die später hinzugekommene Quelle S074 ist eingeschlossen. S066–S070 wurden während der Arbeit in ihrem Ursprungsordner weiterentwickelt; ihre frühen Momentaufnahmen bleiben absichtlich erhalten. Der nachgereichte Text S073 ist byteidentisch mit dem zuvor gelesenen Repositorybericht `universalraum-native-operations-ground-response-20260915/RESULTS.md`.

Der Repositorycommit bei der Bestandsaufnahme war `66b91e40e245569f06ab440ead80f446c9be0ee5`. Neuere, nicht eingecheckte Forschungsdateien gehören ausdrücklich zum Quellenstand. Es gab keinen Commit, Push oder Eingriff in fremde laufende Forschung.

## Reproduktion der endlichen Rechnungen

Benötigt werden Python 3, NumPy und SymPy. Aus dem entpackten Paketverzeichnis:

```sh
python3 work/verify_connections.py
python3 -OO work/verify_connections.py
python3 work/v167_replay/verify_hamilton_chain.py
python3 -OO work/v167_replay/verify_hamilton_chain.py
```

Der eigene Prüfer muss `PASS` mit 57 Bedingungen liefern. Der isolierte Prüfer der Hamilton-Kette muss `PASS` mit 20 Bedingungen liefern. Die Vergleichsergebnisse liegen in `work/connections_*.json` und `work/v167_replay/replayed*.json`. Die Tensorprüfung sichert auch reelle ganzzahlige Einträge vor der Umwandlung. Fehlgeschlagene Prüfungen brechen mit einem Fehler ab; Python-Optimierung entfernt die Bedingungen nicht.

Der isolierte Prüfer übernimmt historische Kontraktionszahlen und die Norm der vierten Bosonstufe. Er rechnet die große Fock-Enumeration nicht erneut. Auch die 822 Bedingungen der letzten fremden Quellensuite und der große native Grundzustandsbeweis wurden nicht vollständig erneut ausgeführt.

## Dokument und Abbildungen neu erzeugen

Zusätzlich benötigt: Matplotlib, Pandoc (über `pypandoc` oder `pypandoc-binary`), XeLaTeX mit deutschem Babel, Unicode-Math, Fancyhdr, Titlesec und FVextra. Die hier verwendeten Paketversionen stehen in `work/runtime_versions.json`.

```sh
python3 work/make_figures.py
python3 work/build_paper.py
```

Die PDF-Inspektion benötigt zusätzlich PyMuPDF und Pillow. Nicht jeder spätere Satzlauf erzeugt byteidentische PDFs; Zeitstempel und installierte Fonts können sich ändern. Die mathematischen JSON-Ergebnisse müssen dagegen mit den gespeicherten Ergebnissen übereinstimmen.

## Wissenschaftlicher Status

Dies ist eine nachvollziehbare Forschungssynthese mit eigenen Herleitungen und endlichen Prüfungen. Die physikalische Auswahl des Hamiltonoperators, die Herkunft der Referenz, vollständige innere Symmetrie der Referenzerweiterung, Raumzeit, Kontinuum, Chiralität und Gravitation bleiben offen. Keine T1–T8-Aufgabe wird als vollständig geschlossen markiert. Es wird kein RH-, P-vs-NP- oder TOE-Beweis behauptet.
